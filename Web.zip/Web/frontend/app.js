import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  signOut,
  sendEmailVerification,
  reload
} from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";

// --------------------------------------------------
// Config
// --------------------------------------------------
const firebaseConfig = {
  apiKey: "AIzaSyA43QgLUIiEzW_vyz9iggmmDTDyIMFVuBU",
  authDomain: "fyp-54.firebaseapp.com",
  projectId: "fyp-54",
  storageBucket: "fyp-54.firebasestorage.app",
  messagingSenderId: "560377742692",
  appId: "1:560377742692:web:1140c5d1b82c8b187b6671",
  measurementId: "G-9DLL7CKC1Z"
};

const API_BASE_URL = "https://localhost:8000";
const WS_BASE_URL  = "wss://localhost:8000";

// --------------------------------------------------
// Firebase init
// --------------------------------------------------
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

// --------------------------------------------------
// DOM — Auth page
// --------------------------------------------------
const authPage                = document.getElementById("auth-page");
const appPage                 = document.getElementById("app-page");
const authChoiceSection       = document.getElementById("auth-choice-section");
const emailFormSection        = document.getElementById("email-form-section");
const recoveryChoiceSection   = document.getElementById("recovery-choice-section");
const recoverySuccessSection  = document.getElementById("recovery-success-section");
const verificationSentSection = document.getElementById("verification-sent-section");

const showSignupBtn   = document.getElementById("show-signup-btn");
const showLoginBtn    = document.getElementById("show-login-btn");
const showRecoveryBtn = document.getElementById("show-recovery-btn");
const googleBtn       = document.getElementById("google-btn");

const formTitle     = document.getElementById("form-title");
const submitAuthBtn = document.getElementById("submit-auth-btn");
const backBtn       = document.getElementById("back-btn");
const emailInput    = document.getElementById("email");
const passwordInput = document.getElementById("password");
const authStatus    = document.getElementById("auth-status");
const formStatus    = document.getElementById("form-status");

const togglePasswordBtn = document.getElementById("toggle-password");
const eyeIcon           = document.getElementById("eye-icon");
const eyeOffIcon        = document.getElementById("eye-off-icon");

const confirmPasswordGroup     = document.getElementById("confirm-password-group");
const confirmPasswordInput     = document.getElementById("confirm-password");
const confirmMatchIcon         = document.getElementById("confirm-match-icon");
const confirmPasswordHint      = document.getElementById("confirm-password-hint");
const toggleConfirmPasswordBtn = document.getElementById("toggle-confirm-password");
const eyeIconConfirm           = document.getElementById("eye-icon-confirm");
const eyeOffIconConfirm        = document.getElementById("eye-off-icon-confirm");

const recoverPasswordBtn      = document.getElementById("recover-password-btn");
const recoverGoogleBtn        = document.getElementById("recover-google-btn");
const recoveryBackBtn         = document.getElementById("recovery-back-btn");
const recoveryGoogleBackBtn   = document.getElementById("recovery-google-back-btn");
const recoveryStatus          = document.getElementById("recovery-status");
const tabEmailBtn             = document.getElementById("tab-email-btn");
const tabGoogleBtn            = document.getElementById("tab-google-btn");
const recoveryEmailTab        = document.getElementById("recovery-email-tab");
const recoveryGoogleTab       = document.getElementById("recovery-google-tab");
const recoveryEmailInput      = document.getElementById("recovery-email");
const recoveryPasswordInput   = document.getElementById("recovery-password");
const recoveryBackupKeyEmail  = document.getElementById("recovery-backup-key-email");
const recoveryBackupKeyGoogle = document.getElementById("recovery-backup-key-google");

const forgotPasswordSection  = document.getElementById("forgot-password-section");
const forgotPasswordBtn      = document.getElementById("forgot-password-btn");
const forgotEmail            = document.getElementById("forgot-email");
const forgotBackupKey        = document.getElementById("forgot-backup-key");
const forgotNewPassword      = document.getElementById("forgot-new-password");
const forgotConfirmPassword  = document.getElementById("forgot-confirm-password");
const forgotPasswordHint     = document.getElementById("forgot-password-hint");
const forgotSubmitBtn        = document.getElementById("forgot-submit-btn");
const forgotBackBtn          = document.getElementById("forgot-back-btn");
const forgotStatus           = document.getElementById("forgot-status");

const backupCodesSection       = document.getElementById("backup-codes-section");
const backupCodesGrid          = document.getElementById("backup-codes-grid");
const backupConfirmCheckbox    = document.getElementById("backup-confirm-checkbox");
const backupCodesContinueBtn   = document.getElementById("backup-codes-continue-btn");

const goSignupBtn       = document.getElementById("go-signup-btn");
const verificationEmail = document.getElementById("verification-email");
const goLoginBtn        = document.getElementById("go-login-btn");

// --------------------------------------------------
// DOM — App page
// --------------------------------------------------
const avatar           = document.getElementById("avatar");
const profileUsername  = document.getElementById("profile-username");
const profileEmail     = document.getElementById("profile-email");
const profileProvider  = document.getElementById("profile-provider");
const profileBlacklist = document.getElementById("profile-blacklist");

const requestContent      = document.getElementById("request-content");
const submitRequestBtn    = document.getElementById("submit-request-btn");
const generateStandardBtn = document.getElementById("generate-standard-btn");
const requestStatus    = document.getElementById("request-status");
const requestsList     = document.getElementById("requests-list");

const lostPhoneBtn = document.getElementById("lost-phone-btn");
const logoutBtn    = document.getElementById("logout-btn");

// Hide everything on load — Firebase resolves which page to show
authPage.classList.add("hidden");
appPage.classList.add("hidden");

// --------------------------------------------------
// State
// --------------------------------------------------
let currentMode          = null;
let isRecovering         = false;
let isHandlingUnverified = false;
let isSigningUp          = false;
let authResolved         = false;

// No session token in JS — the HttpOnly cookie is handled entirely by the browser.
// We only need to know if a session *should* exist (user was previously logged in)
// to avoid flashing the login page on refresh.
// We use a simple non-sensitive flag in localStorage for this — NOT the token itself.
const SESSION_EXISTS_KEY = "ssp_has_session";

// Local cache of all requests
let localRequests = [];

// --------------------------------------------------
// Session flag helpers (non-sensitive — just a boolean)
// --------------------------------------------------
function markSessionExists()  { localStorage.setItem(SESSION_EXISTS_KEY, "1"); }
function clearSessionFlag()   { localStorage.removeItem(SESSION_EXISTS_KEY); }
function sessionMayExist()    { return !!localStorage.getItem(SESSION_EXISTS_KEY); }

// --------------------------------------------------
// Force logout — show auth page with an error message
// --------------------------------------------------
// pendingLogoutMessage is set before signOut so onAuthStateChanged can show it
// after it resets the UI — otherwise showChoiceScreen() wipes it.
let pendingLogoutMessage = null;

function forceLogout(message) {
  clearSessionFlag();
  disconnectWebSocket();
  requestContent.value = "";  // clear unsent text
  pendingLogoutMessage = message || null;

  // Best-effort: delete the session row on the server
  const user = auth.currentUser;
  if (user) {
    user.getIdToken(true).then(idToken => {
      fetch(`${API_BASE_URL}/logout`, {
        method: "POST",
        headers: {
          "Content-Type":  "application/json",
          "Authorization": `Bearer ${idToken}`,
          "X-Platform":    "web"
        },
        credentials: "include"
      }).catch(() => {});
    }).catch(() => {});
  }

  signOut(auth).catch(() => {});
  // UI update is handled by onAuthStateChanged firing with null
}

// --------------------------------------------------
// API helpers
// All fetch calls use credentials: "include" so the browser sends
// the HttpOnly cookie automatically. No token handling in JS.
// --------------------------------------------------
async function getAuthHeaders() {
  const user = auth.currentUser;
  if (!user) throw new Error("No authenticated user.");
  const token = await user.getIdToken(true);
  return {
    "Content-Type":  "application/json",
    "Authorization": `Bearer ${token}`,
    "X-Platform":    "web"
  };
}

// Central 401 handler — called after every non-2xx response.
// Detects session errors and calls forceLogout with a clear message
// so the user always lands on the login page cleanly, never stuck on a broken error.
function handleSessionError(status, detail) {
  if (status !== 401) return false;
  const m = (detail || "").toLowerCase();
  if (m.includes("ip mismatch") || m.includes("session ip")) {
    forceLogout("Your network changed. Please log in again.");
    return true;
  }
  if (m.includes("session expired")) {
    forceLogout("Your session expired due to inactivity. Please log in again.");
    return true;
  }
  if (m.includes("session not found") || m.includes("missing session token")) {
    forceLogout("Your session is no longer valid. Please log in again.");
    return true;
  }
  // Generic 401 (e.g. bad Firebase token)
  forceLogout("Authentication failed. Please log in again.");
  return true;
}

async function apiGet(path) {
  const headers = await getAuthHeaders();
  const res = await fetch(`${API_BASE_URL}${path}`, {
    method: "GET",
    headers,
    credentials: "include"
  });
  const result = await res.json();
  if (!res.ok) {
    if (!handleSessionError(res.status, result.detail)) {
      throw new Error(result.detail || "Request failed");
    }
    return;
  }
  return result;
}

async function apiPost(path, body = {}) {
  const headers = await getAuthHeaders();
  const res = await fetch(`${API_BASE_URL}${path}`, {
    method: "POST",
    headers,
    credentials: "include",
    body: JSON.stringify(body)
  });
  const result = await res.json();
  if (!res.ok) {
    if (!handleSessionError(res.status, result.detail)) {
      throw new Error(result.detail || "Request failed");
    }
    return;
  }
  return result;
}

// --------------------------------------------------
// Signature helpers
// --------------------------------------------------

// Cache of fetched signatures to avoid repeated calls
const signatureCache = {};

async function fetchAndRenderSignature(requestId, cardEl) {
  // Return cached if available
  if (signatureCache[requestId]) {
    renderSignatureDetails(signatureCache[requestId], cardEl);
    return;
  }
  try {
    const data = await apiGet(`/signature/${requestId}`);
    if (!data || data.status === "none") return;
    signatureCache[requestId] = data;
    renderSignatureDetails(data, cardEl);
  } catch (err) {
    console.warn("[Signature] Could not fetch signature for request", requestId, err);
  }
}

function renderSignatureDetails(sigData, cardEl) {
  // Remove existing signature panel if any
  const existing = cardEl.querySelector(".signature-panel");
  if (existing) existing.remove();

  if (!sigData || sigData.status === "none") return;

  const panel = document.createElement("div");
  panel.className = "signature-panel";

  const signedAt  = sigData.signed_at  ? formatDate(sigData.signed_at)  : "—";
  const expiresAt = sigData.expires_at ? formatDate(sigData.expires_at) : "—";
  const serial    = sigData.serial_number
    ? sigData.serial_number.match(/.{1,4}/g).join("-")
    : "—";

  const format       = sigData.signature_format || "pkcs7";
  const formatLabel  = format === "raw"
    ? "Raw ECDSA Signature"
    : "PKCS#7 / CMS (.p7m)";
  const formatBadge  = format === "raw"
    ? `<span style="font-size:11px;background:#f59e0b;color:white;padding:2px 7px;border-radius:999px;font-weight:700;">RAW</span>`
    : `<span style="font-size:11px;background:#1f6feb;color:white;padding:2px 7px;border-radius:999px;font-weight:700;">PKCS#7</span>`;

  panel.innerHTML = `
    <div class="sig-header">
      <span class="sig-title">Cryptographically Signed</span>
      <span class="sig-verified">${sigData.verified ? "VERIFIED" : "UNVERIFIED"}</span>
    </div>
    <div class="sig-details">
      <div class="sig-row"><span class="sig-label">Signed at</span><span class="sig-value">${signedAt}</span></div>
      <div class="sig-row"><span class="sig-label">Issued by</span><span class="sig-value">Fyp54-CA</span></div>
      <div class="sig-row"><span class="sig-label">Cert serial</span><span class="sig-value sig-mono">${serial}</span></div>
      <div class="sig-row"><span class="sig-label">Cert expires</span><span class="sig-value">${expiresAt}</span></div>
      <div class="sig-row"><span class="sig-label">Format</span><span class="sig-value">${formatBadge} ${formatLabel}</span></div>
    </div>
    ${format !== "raw" ? `<button class="download-p7m-btn" data-request-id="${sigData.request_id || ''}">⬇ Download .p7m</button>` : ""}
  `;

  if (format !== "raw") {
    const dlBtn = panel.querySelector(".download-p7m-btn");
    dlBtn.addEventListener("click", () => downloadP7m(sigData));
  }

  cardEl.appendChild(panel);
}

function downloadP7m(sigData) {
  if (!sigData.pkcs7_b64) return;
  try {
    // Decode base64 to binary
    const binary = atob(sigData.pkcs7_b64);
    const bytes  = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);

    const blob = new Blob([bytes], { type: "application/pkcs7-mime" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href     = url;
    a.download = `signed_request_${Date.now()}.p7m`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  } catch (err) {
    alert("Failed to download .p7m file.");
  }
}

// --------------------------------------------------
// WebSocket manager
// --------------------------------------------------
let ws = null;
let wsReconnectTimer = null;
let wsReconnectDelay = 2000;
let wsCurrentUser    = null;

function connectWebSocket(user) {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;

  wsCurrentUser = user;
  ws = new WebSocket(`${WS_BASE_URL}/ws`);

  ws.onopen = () => {
    console.log("[WS] Connected");
    wsReconnectDelay = 2000;
  };

  ws.onmessage = async (event) => {
    let msg;
    try { msg = JSON.parse(event.data); } catch { return; }

    switch (msg.type) {

      case "auth_required":
        try {
          const token = await user.getIdToken(true);
          // WS auth still uses token — WS can't send cookies.
          // The backend allows web WS without session token validation
          // (same as before the HttpOnly change for WS).
          ws.send(JSON.stringify({ type: "auth", token, platform: "web" }));
        } catch (e) {
          console.error("[WS] Could not get token:", e);
          ws.close();
        }
        break;

      case "auth_ok":
        console.log("[WS] Authenticated");
        break;

      case "auth_error":
        console.error("[WS] Auth error:", msg.message);
        ws.close();
        break;

      case "session_invalid":
        wsCurrentUser = null;
        forceLogout("Your session was terminated. Please log in again.");
        break;

      case "new_request":
        localRequests = [msg.request, ...localRequests];
        renderRequests(localRequests);
        break;

      case "status_update":
        localRequests = localRequests.map(r =>
          r.id === msg.request.id ? msg.request : r
        );
        renderRequests(localRequests);
        break;

      case "ping":
        ws.send(JSON.stringify({ type: "pong" }));
        break;
    }
  };

  ws.onerror  = (err) => { console.warn("[WS] Error:", err); };

  ws.onclose = () => {
    console.warn("[WS] Closed. Reconnecting in", wsReconnectDelay, "ms");
    if (wsCurrentUser) {
      wsReconnectTimer = setTimeout(() => {
        wsCurrentUser.getIdToken(true)
          .then(() => connectWebSocket(wsCurrentUser))
          .catch(() => {});
        wsReconnectDelay = Math.min(wsReconnectDelay * 2, 30000);
      }, wsReconnectDelay);
    }
  };
}

function disconnectWebSocket() {
  wsCurrentUser = null;
  clearTimeout(wsReconnectTimer);
  if (ws) {
    ws.onclose = null;
    ws.close();
    ws = null;
  }
}

// --------------------------------------------------
// Auth page helpers
// --------------------------------------------------
function hideAllAuthSections() {
  authChoiceSection.classList.add("hidden");
  emailFormSection.classList.add("hidden");
  recoveryChoiceSection.classList.add("hidden");
  recoverySuccessSection.classList.add("hidden");
  verificationSentSection.classList.add("hidden");
  forgotPasswordSection.classList.add("hidden");
  backupCodesSection.classList.add("hidden");
  authStatus.textContent = "";
  formStatus.textContent = "";
  if (recoveryStatus) recoveryStatus.textContent = "";
  if (forgotStatus)   forgotStatus.textContent = "";
}

function showChoiceScreen() {
  hideAllAuthSections();
  authChoiceSection.classList.remove("hidden");
}

function showEmailForm(mode) {
  currentMode = mode;
  hideAllAuthSections();
  emailFormSection.classList.remove("hidden");
  emailInput.value = "";
  passwordInput.value = "";
  confirmPasswordInput.value = "";

  passwordInput.type = "password";
  eyeIcon.classList.remove("hidden");
  eyeOffIcon.classList.add("hidden");
  confirmPasswordInput.type = "password";
  eyeIconConfirm.classList.remove("hidden");
  eyeOffIconConfirm.classList.add("hidden");
  confirmMatchIcon.classList.add("hidden");
  confirmPasswordHint.textContent = "";
  confirmPasswordHint.className = "password-hint hidden";

  forgotPasswordBtn.classList.add("hidden");

  if (mode === "signup") {
    formTitle.textContent = "Create Account";
    submitAuthBtn.textContent = "Register";
    confirmPasswordGroup.classList.remove("hidden");
    confirmPasswordHint.classList.remove("hidden");
  } else {
    confirmPasswordGroup.classList.add("hidden");
    confirmPasswordHint.classList.add("hidden");
    if (mode === "login") {
      formTitle.textContent = "Login";
      submitAuthBtn.textContent = "Login";
      forgotPasswordBtn.classList.remove("hidden");
}
  }
}

function showBackupCodes(codes, onContinue) {
  hideAllAuthSections();
  backupCodesSection.classList.remove("hidden");

  // Render the grid
  backupCodesGrid.innerHTML = "";
  codes.forEach((code, i) => {
    const cell = document.createElement("div");
    cell.className = "backup-code-cell";
    cell.innerHTML = `
      <div class="backup-code-index">#${i + 1}</div>
      <div class="backup-code-value">${code}</div>
    `;
    backupCodesGrid.appendChild(cell);
  });

  // Reset checkbox and button
  backupConfirmCheckbox.checked = false;
  backupCodesContinueBtn.disabled = true;
  backupCodesContinueBtn.onclick = onContinue;

  backupConfirmCheckbox.onchange = () => {
    backupCodesContinueBtn.disabled = !backupConfirmCheckbox.checked;
  };
}

function showRecoveryChoice() {
  hideAllAuthSections();
  recoveryChoiceSection.classList.remove("hidden");
  // Reset to email tab
  tabEmailBtn.classList.add("active");
  tabGoogleBtn.classList.remove("active");
  recoveryEmailTab.classList.remove("hidden");
  recoveryGoogleTab.classList.add("hidden");
  recoveryEmailInput.value = "";
  recoveryPasswordInput.value = "";
  recoveryBackupKeyEmail.value = "";
  recoveryBackupKeyGoogle.value = "";
}

function showForgotPassword() {
  hideAllAuthSections();
  forgotPasswordSection.classList.remove("hidden");
  forgotEmail.value = "";
  forgotBackupKey.value = "";
  forgotNewPassword.value = "";
  forgotConfirmPassword.value = "";
  forgotPasswordHint.textContent = "";
  forgotPasswordHint.className = "password-hint";
}
function showRecoverySuccess()       { hideAllAuthSections(); recoverySuccessSection.classList.remove("hidden"); }
function showVerificationSent(email) {
  hideAllAuthSections();
  verificationEmail.textContent = email;
  verificationSentSection.classList.remove("hidden");
}

// --------------------------------------------------
// Formatting helpers
// --------------------------------------------------
function formatDate(raw) {
  if (!raw) return "";
  const normalized = raw.replace(" ", "T").replace(/\.\d+$/, "");
  const d = new Date(normalized);
  if (isNaN(d.getTime())) return raw;
  return d.toLocaleString(undefined, {
    year: "numeric", month: "short", day: "numeric",
    hour: "2-digit", minute: "2-digit", second: "2-digit",
    hour12: false
  });
}

function statusBadgeClass(status) {
  const s = (status || "").toLowerCase();
  if (s === "accepted") return "accepted";
  if (s === "rejected") return "rejected";
  if (s === "error")    return "error";
  return "pending";
}

function formatProvider(raw) {
  if (raw === "google.com") return "Google";
  if (raw === "password")   return "System";
  return raw || "Unknown";
}

function setStatus(el, message, type = "success") {
  el.textContent = message;
  el.className = "status " + (type === "error" ? "status-error" : "status-success");
}

function renderProfile(profile) {
  const username = profile.username || "User";
  const email    = profile.email    || "No email";
  const provider = profile.provider || "unknown";
  avatar.textContent          = username.charAt(0).toUpperCase();
  profileUsername.textContent = username;
  profileEmail.textContent    = email;
  profileProvider.textContent = `Provider: ${formatProvider(provider)}`;
  if (profile.is_blacklisted) {
    profileBlacklist.classList.remove("hidden");
  } else {
    profileBlacklist.classList.add("hidden");
  }
}

function renderRequests(requests) {
  requestsList.innerHTML = "";
  if (!requests.length) {
    requestsList.innerHTML = `<div class="empty-state">No requests yet.</div>`;
    return;
  }
  requests.forEach((request) => {
    const badgeClass = statusBadgeClass(request.status);
    const card = document.createElement("div");
    card.className = "request-item";
    card.dataset.id = request.id;
    card.innerHTML = `
      <div class="request-item-top">
        <span class="request-id">Request #${request.id}</span>
        <span class="badge ${badgeClass}">${request.status.toUpperCase()}</span>
      </div>
      <p class="request-body">${request.content}</p>
      <div class="request-meta">
        <span>Submitted: ${formatDate(request.created_at)}</span>
        <span>Decision: ${formatDate(request.updated_at)}</span>
      </div>
    `;
    requestsList.appendChild(card);

    // For accepted requests, fetch and display signature details
    if (request.status === "accepted") {
      fetchAndRenderSignature(request.id, card);
    }
  });
}

// --------------------------------------------------
// Create web session — calls /register, backend sets HttpOnly cookie
// --------------------------------------------------
async function createWebSession(user) {
  try {
    const idToken = await user.getIdToken(true);
    const res = await fetch(`${API_BASE_URL}/register`, {
      method: "POST",
      headers: {
        "Content-Type":  "application/json",
        "Authorization": `Bearer ${idToken}`,
        "X-Platform":    "web"
      },
      credentials: "include"
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Registration failed.");
    markSessionExists();
    // Return backup codes if this is the first login, empty array otherwise
    return { ok: true, backupCodes: data.backup_codes || [] };
  } catch (err) {
    console.error("[Session] createWebSession failed:", err.message);
    return { ok: false, backupCodes: [] };
  }
}

// --------------------------------------------------
// Load dashboard
// --------------------------------------------------
async function loadDashboard(user) {
  try {
    // On fresh login: create a new session (backend sets HttpOnly cookie)
    // On refresh/new tab: cookie already exists, go straight to loading data
    if (!sessionMayExist()) {
      const { ok, backupCodes } = await createWebSession(user);
      if (!ok) {
        setStatus(authStatus, "Could not establish a session. Please try again.", "error");
        await signOut(auth);
        return;
      }
      // First login — show backup codes before entering the app
      if (backupCodes.length > 0) {
        showBackupCodes(backupCodes, async () => {
          // User confirmed they saved the codes — now load the dashboard
          hideAllAuthSections();
          await loadDashboardData(user);
        });
        return;
      }
    }

    await loadDashboardData(user);
  } catch (error) {
    const msg = error.message.toLowerCase();
    if (msg.includes("blacklisted")) {
      clearSessionFlag();
      setStatus(authStatus, "This account has been blacklisted. Use your backup keys to recover access.", "error");
      await signOut(auth);
      return;
    }
    if (msg.includes("ip mismatch") || msg.includes("session ip")) {
      forceLogout("Your network changed. Please log in again.");
      return;
    }
    if (msg.includes("session expired")) {
      forceLogout("Your session expired due to inactivity. Please log in again.");
      return;
    }
    if (msg.includes("session not found") || msg.includes("missing session token")) {
      forceLogout("Your session is no longer valid. Please log in again.");
      return;
    }
    if (msg.includes("invalid token") || msg.includes("unauthorized")) {
      forceLogout("Authentication failed. Please log in again.");
      return;
    }
    setStatus(requestStatus, "Failed to load data. Please refresh the page.", "error");
  }
}

// Separated so it can be called both on normal load and after backup codes confirmed
async function loadDashboardData(user) {
  try {

    // Load profile + requests — browser sends cookie automatically
    let profileResponse, requestsResponse;
    try {
      [profileResponse, requestsResponse] = await Promise.all([
        apiGet("/profile"),
        apiGet("/requests")
      ]);
    } catch (firstErr) {
      const m = firstErr.message.toLowerCase();
      // Cookie expired or server restarted — create a new session and retry once
      if (m.includes("session not found") || m.includes("session expired") || m.includes("missing session token")) {
        console.log("[Session] Cookie rejected — creating new session and retrying.");
        const ok = await createWebSession(user);
        if (!ok) {
          setStatus(authStatus, "Could not establish a session. Please try again.", "error");
          await signOut(auth);
          return;
        }
        [profileResponse, requestsResponse] = await Promise.all([
          apiGet("/profile"),
          apiGet("/requests")
        ]);
      } else {
        throw firstErr;
      }
    }

    renderProfile(profileResponse.profile);
    localRequests = requestsResponse.requests;
    renderRequests(localRequests);
    setStatus(requestStatus, "");

    authPage.classList.add("hidden");
    appPage.classList.remove("hidden");

    connectWebSocket(user);

  } catch (error) {
    const msg = error.message.toLowerCase();
    // Session errors (IP mismatch, expiry, etc.) are handled centrally by
    // handleSessionError inside apiGet/apiPost — they call forceLogout directly.
    // Only non-session errors reach here.
    if (msg.includes("blacklisted")) {
      clearSessionFlag();
      setStatus(authStatus, "This account has been blacklisted. Use your backup keys to recover access.", "error");
      await signOut(auth);
      return;
    }
    setStatus(requestStatus, "Failed to load data. Please refresh the page.", "error");
  }
}

// --------------------------------------------------
// Auth state observer
// --------------------------------------------------
onAuthStateChanged(auth, async (user) => {
  if (isRecovering || isHandlingUnverified || isSigningUp) return;

  if (!user) {
    disconnectWebSocket();
    appPage.classList.add("hidden");
    if (authResolved || !sessionMayExist()) {
      authPage.classList.remove("hidden");
      showChoiceScreen();
      // Show pending message AFTER showChoiceScreen (which clears statuses)
      if (pendingLogoutMessage) {
        setStatus(authStatus, pendingLogoutMessage, "error");
        pendingLogoutMessage = null;
      }
    }
    authResolved = true;
    return;
  }

  authResolved = true;

  await reload(user);
  const providerId = user.providerData[0]?.providerId || "";

  if (providerId === "password" && !user.emailVerified) {
    isHandlingUnverified = true;
    await signOut(auth);
    isHandlingUnverified = false;
    return;
  }

  await loadDashboard(user);
});

// --------------------------------------------------
// Auth choice screen
// --------------------------------------------------
showSignupBtn.addEventListener("click", () => showEmailForm("signup"));
showLoginBtn.addEventListener("click",  () => showEmailForm("login"));
showRecoveryBtn.addEventListener("click", showRecoveryChoice);

googleBtn.addEventListener("click", async () => {
  setStatus(authStatus, "");
  try {
    await signInWithPopup(auth, googleProvider);
  } catch {
    setStatus(authStatus, "Google sign-in failed. Please try again.", "error");
  }
});

// --------------------------------------------------
// Email auth form
// --------------------------------------------------
backBtn.addEventListener("click", showChoiceScreen);

submitAuthBtn.addEventListener("click", async () => {
  const email    = emailInput.value.trim();
  const password = passwordInput.value.trim();
  setStatus(formStatus, "");

  if (!email || !password) {
    setStatus(formStatus, "Please enter both email and password.", "error");
    return;
  }

  try {
    if (currentMode === "signup") {
      if (passwordInput.value !== confirmPasswordInput.value) {
        setStatus(formStatus, "Passwords do not match. Please try again.", "error");
        return;
      }
      try {
        isSigningUp = true;
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        await sendEmailVerification(userCredential.user);
        await signOut(auth);
        isSigningUp = false;
        showVerificationSent(email);
      } catch (error) {
        isSigningUp = false;
        if (error.code === "auth/email-already-in-use") {
          setStatus(formStatus, "An account with this email already exists. Please log in instead.", "error");
        } else if (error.code === "auth/weak-password") {
          setStatus(formStatus, "Password is too weak. Please use at least 6 characters.", "error");
        } else if (error.code === "auth/invalid-email") {
          setStatus(formStatus, "Invalid email address. Please check and try again.", "error");
        } else {
          setStatus(formStatus, "Registration failed. Please try again.", "error");
        }
      }
      return;
    }

    if (currentMode === "login") {
      try {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        await reload(userCredential.user);
        if (!userCredential.user.emailVerified) {
          isHandlingUnverified = true;
          await signOut(auth);
          isHandlingUnverified = false;
          setStatus(formStatus, "Account not verified. Please check your inbox and click the verification link to log in.", "error");
          return;
        }
        setStatus(formStatus, "Login successful.", "success");
      } catch (error) {
        if (["auth/user-not-found","auth/wrong-password","auth/invalid-credential"].includes(error.code)) {
          setStatus(formStatus, "Login failed. Incorrect email or password.", "error");
        } else {
          setStatus(formStatus, "Login failed. Please try again.", "error");
        }
      }
      return;
    }


  } catch {
    setStatus(formStatus, "An unexpected error occurred. Please try again.", "error");
  }
});

// --------------------------------------------------
// Recovery screen — tab toggle
// --------------------------------------------------
tabEmailBtn.addEventListener("click", () => {
  tabEmailBtn.classList.add("active");
  tabGoogleBtn.classList.remove("active");
  recoveryEmailTab.classList.remove("hidden");
  recoveryGoogleTab.classList.add("hidden");
  setStatus(recoveryStatus, "");
});

tabGoogleBtn.addEventListener("click", () => {
  tabGoogleBtn.classList.add("active");
  tabEmailBtn.classList.remove("active");
  recoveryGoogleTab.classList.remove("hidden");
  recoveryEmailTab.classList.add("hidden");
  setStatus(recoveryStatus, "");
});

// Back buttons
recoveryBackBtn.addEventListener("click", showChoiceScreen);
recoveryGoogleBackBtn.addEventListener("click", showChoiceScreen);

// Email/Password recovery
recoverPasswordBtn.addEventListener("click", async () => {
  const email     = recoveryEmailInput.value.trim();
  const password  = recoveryPasswordInput.value.trim();
  const backupKey = recoveryBackupKeyEmail.value.trim();
  setStatus(recoveryStatus, "");

  if (!email || !password || !backupKey) {
    setStatus(recoveryStatus, "Please fill in all fields.", "error");
    return;
  }

  isRecovering = true;
  recoverPasswordBtn.textContent = "Recovering...";
  recoverPasswordBtn.disabled = true;

  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    await reload(userCredential.user);
    const providerId = userCredential.user.providerData[0]?.providerId || "";
    if (providerId !== "google.com") {
      // email/password account — proceed
    }
    const idToken = await userCredential.user.getIdToken(true);
    await signOut(auth);

    const res = await fetch(`${API_BASE_URL}/recover-account`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${idToken}` },
      body: JSON.stringify({ backup_key: backupKey })
    });
    const data = await res.json();

    if (!res.ok) {
      setStatus(recoveryStatus, data.detail || "Recovery failed.", "error");
      return;
    }
    setStatus(recoveryStatus, data.message || "Account recovered.", "success");
    setTimeout(() => showEmailForm("login"), 2000);

  } catch (err) {
    if (["auth/user-not-found","auth/wrong-password","auth/invalid-credential"].includes(err.code)) {
      setStatus(recoveryStatus, "Incorrect email or password.", "error");
    } else {
      setStatus(recoveryStatus, err.message || "Recovery failed. Please try again.", "error");
    }
    try { await signOut(auth); } catch (_) {}
  } finally {
    isRecovering = false;
    recoverPasswordBtn.textContent = "Recover";
    recoverPasswordBtn.disabled = false;
  }
});

// Google recovery
recoverGoogleBtn.addEventListener("click", async () => {
  const backupKey = recoveryBackupKeyGoogle.value.trim();
  setStatus(recoveryStatus, "");

  if (!backupKey) {
    setStatus(recoveryStatus, "Please enter your backup key.", "error");
    return;
  }

  isRecovering = true;
  recoverGoogleBtn.disabled = true;

  try {
    const result = await signInWithPopup(auth, googleProvider);
    const providerId = result.user.providerData[0]?.providerId || "";
    if (providerId !== "google.com") {
      await signOut(auth);
      setStatus(recoveryStatus, "This option is only for Google accounts.", "error");
      return;
    }
    const idToken = await result.user.getIdToken(true);
    await signOut(auth);

    const res = await fetch(`${API_BASE_URL}/recover-account`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${idToken}` },
      body: JSON.stringify({ backup_key: backupKey })
    });
    const data = await res.json();

    if (!res.ok) {
      setStatus(recoveryStatus, data.detail || "Recovery failed.", "error");
      return;
    }
    setStatus(recoveryStatus, data.message || "Account recovered.", "success");
    setTimeout(() => showEmailForm("login"), 2000);

  } catch (err) {
    setStatus(recoveryStatus, "Google sign-in failed. Please try again.", "error");
    try { await signOut(auth); } catch (_) {}
  } finally {
    isRecovering = false;
    recoverGoogleBtn.disabled = false;
  }
});

// --------------------------------------------------
// Post-recovery / post-signup navigation
// --------------------------------------------------
goSignupBtn.addEventListener("click", () => showEmailForm("login"));
goLoginBtn.addEventListener("click",  () => showEmailForm("login"));

// --------------------------------------------------
// Forgot password
// --------------------------------------------------
forgotPasswordBtn.addEventListener("click", showForgotPassword);
forgotBackBtn.addEventListener("click", () => showEmailForm("login"));

// Live confirm password validation for forgot password
forgotConfirmPassword.addEventListener("input", () => {
  const pw  = forgotNewPassword.value;
  const cpw = forgotConfirmPassword.value;
  if (!cpw) { forgotPasswordHint.textContent = ""; forgotPasswordHint.className = "password-hint"; return; }
  if (pw === cpw) {
    forgotPasswordHint.textContent = "Passwords match.";
    forgotPasswordHint.className = "password-hint hint-success";
  } else {
    forgotPasswordHint.textContent = "Passwords do not match.";
    forgotPasswordHint.className = "password-hint hint-error";
  }
});

forgotNewPassword.addEventListener("input", () => {
  if (forgotConfirmPassword.value) forgotConfirmPassword.dispatchEvent(new Event("input"));
});

forgotSubmitBtn.addEventListener("click", async () => {
  const email       = forgotEmail.value.trim();
  const backupKey   = forgotBackupKey.value.trim();
  const newPassword = forgotNewPassword.value;
  const confirmPw   = forgotConfirmPassword.value;
  setStatus(forgotStatus, "");

  if (!email || !backupKey || !newPassword || !confirmPw) {
    setStatus(forgotStatus, "Please fill in all fields.", "error");
    return;
  }
  if (newPassword !== confirmPw) {
    setStatus(forgotStatus, "Passwords do not match.", "error");
    return;
  }
  if (newPassword.length < 6) {
    setStatus(forgotStatus, "Password must be at least 6 characters.", "error");
    return;
  }

  forgotSubmitBtn.textContent = "Resetting...";
  forgotSubmitBtn.disabled = true;

  try {
    const res = await fetch(`${API_BASE_URL}/reset-password`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, backup_key: backupKey, new_password: newPassword })
    });
    const data = await res.json();

    if (!res.ok) {
      setStatus(forgotStatus, data.detail || "Reset failed.", "error");
      return;
    }
    setStatus(forgotStatus, data.message || "Password reset successfully.", "success");
    setTimeout(() => showEmailForm("login"), 2500);

  } catch (err) {
    setStatus(forgotStatus, "Reset failed. Please try again.", "error");
  } finally {
    forgotSubmitBtn.textContent = "Reset Password";
    forgotSubmitBtn.disabled = false;
  }
});

// --------------------------------------------------
// Password visibility toggles
// --------------------------------------------------
function makeEyeToggle(inputEl, eyeShow, eyeHide) {
  return () => {
    const isHidden = inputEl.type === "password";
    inputEl.type = isHidden ? "text" : "password";
    eyeShow.classList.toggle("hidden",  isHidden);
    eyeHide.classList.toggle("hidden", !isHidden);
  };
}
togglePasswordBtn.addEventListener("click",        makeEyeToggle(passwordInput,        eyeOffIcon,        eyeIcon));
toggleConfirmPasswordBtn.addEventListener("click",  makeEyeToggle(confirmPasswordInput, eyeOffIconConfirm, eyeIconConfirm));

// --------------------------------------------------
// Confirm password live validation
// --------------------------------------------------
confirmPasswordInput.addEventListener("input", () => {
  const pw  = passwordInput.value;
  const cpw = confirmPasswordInput.value;
  if (!cpw) {
    confirmPasswordHint.textContent = "";
    confirmPasswordHint.className = "password-hint";
    confirmMatchIcon.classList.add("hidden");
    return;
  }
  if (pw === cpw) {
    confirmPasswordHint.textContent = "Passwords match.";
    confirmPasswordHint.className = "password-hint hint-success";
    confirmMatchIcon.classList.remove("hidden");
  } else {
    confirmPasswordHint.textContent = "Passwords do not match.";
    confirmPasswordHint.className = "password-hint hint-error";
    confirmMatchIcon.classList.add("hidden");
  }
});

passwordInput.addEventListener("input", () => {
  if (currentMode === "signup" && confirmPasswordInput.value) {
    confirmPasswordInput.dispatchEvent(new Event("input"));
  }
});

// --------------------------------------------------
// Submit request
// --------------------------------------------------
submitRequestBtn.addEventListener("click", async () => {
  const content = requestContent.value.trim();
  setStatus(requestStatus, "");
  if (!content) {
    setStatus(requestStatus, "Please enter request content.", "error");
    return;
  }
  try {
    await apiPost("/requests", { content });
    setStatus(requestStatus, "Request submitted.", "success");
    requestContent.value = "";
  } catch (error) {
    if (error) setStatus(requestStatus, "Failed to submit request. Please try again.", "error");
  }
});

// --------------------------------------------------
// Mode B — Generate Standard Request (auto-submit)
// --------------------------------------------------
generateStandardBtn.addEventListener("click", async () => {
  const user = auth.currentUser;
  if (!user) return;

  setStatus(requestStatus, "Generating standard request...", "");

  // Fetch profile to get display name
  let displayName = "User";
  try {
    const idToken = await user.getIdToken(true);
    const res = await fetch(`${API_BASE_URL}/profile`, {
      headers: {
        "Authorization": `Bearer ${idToken}`,
        "X-Platform": "web"
      },
      credentials: "include"
    });
    if (res.ok) {
      const data = await res.json();
      displayName = data.profile?.username || data.profile?.display_name || "User";
    }
  } catch (e) {
    // Use fallback name
  }

  const standardContent =
    `Dear Mr/Ms ${displayName},\n\nBy signing this document you agree to pay 500$ for our services.\n\nThe FYP54 team.`;

  // Auto-submit directly — no pre-fill needed
  try {
    await apiPost("/requests", { content: standardContent });
    setStatus(requestStatus, "Standard request submitted successfully.", "success");
    requestContent.value = "";
  } catch (error) {
    if (error) setStatus(requestStatus, "Failed to submit standard request.", "error");
  }
});

// --------------------------------------------------
// Signing Format Toggle handlers removed — format is chosen on iOS only
// --------------------------------------------------

// --------------------------------------------------
// Lost phone
// --------------------------------------------------
lostPhoneBtn.addEventListener("click", async () => {
  if (!confirm("This will blacklist your account and terminate all active sessions. Continue?")) return;
  try {
    await apiPost("/report-compromised", {});
    clearSessionFlag();
    alert("Your account has been blacklisted. You will now be logged out.");
    await signOut(auth);
  } catch (error) {
    alert(error.message);
  }
});

// --------------------------------------------------
// Logout
// --------------------------------------------------
logoutBtn.addEventListener("click", async () => {
  disconnectWebSocket();
  try {
    const user = auth.currentUser;
    if (user) {
      const idToken = await user.getIdToken(true);
      // credentials: "include" so the browser sends the HttpOnly cookie,
      // and the server can delete the session row + clear the cookie
      await fetch(`${API_BASE_URL}/logout`, {
        method: "POST",
        headers: {
          "Content-Type":  "application/json",
          "Authorization": `Bearer ${idToken}`,
          "X-Platform":    "web"
        },
        credentials: "include"
      });
    }
  } catch (_) {
    // best-effort
  } finally {
    clearSessionFlag();
    await signOut(auth);
  }
});
