import os
import re
import time
import json
import base64
import asyncio
import secrets
import hashlib
from contextlib import asynccontextmanager, contextmanager
from typing import Optional

import requests as http_requests
import urllib3
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric.ec import ECDSA
from cryptography.hazmat.primitives.asymmetric import padding as asym_padding
from cryptography.x509 import ocsp
from cryptography.x509.oid import ExtensionOID, AuthorityInformationAccessOID
from cryptography.hazmat.primitives.serialization import pkcs7

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

import psycopg2
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Header, Cookie, Request, Response, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import firebase_admin
from firebase_admin import credentials, auth, messaging as fcm_messaging

load_dotenv()

DB_CONFIG = {
    "host":     os.getenv("DB_HOST"),
    "port":     os.getenv("DB_PORT"),
    "database": os.getenv("DB_NAME"),
    "user":     os.getenv("DB_USER"),
    "password": os.getenv("DB_PASSWORD"),
}

SESSION_TIMEOUT_SECONDS = 15 * 60  

ADCS_HOST     = os.getenv("ADCS_HOST")
ADCS_USERNAME = os.getenv("ADCS_USERNAME")
ADCS_PASSWORD = os.getenv("ADCS_PASSWORD")
CA_CERT_PATH  = os.getenv("CA_CERT_PATH")   

REVOCATION_API_URL = os.getenv("REVOCATION_API_URL")
REVOCATION_SECRET  = os.getenv("REVOCATION_SECRET")
CRL_URL            = os.getenv("CRL_URL")

if not firebase_admin._apps:
    firebase_admin.initialize_app(credentials.Certificate("fyp-54-firebase.json"))

class ConnectionManager:
    def __init__(self):
        self.active: dict[str, set[WebSocket]] = {}

    async def connect(self, uid: str, ws: WebSocket):
        await ws.accept()
        self.active.setdefault(uid, set()).add(ws)

    def disconnect(self, uid: str, ws: WebSocket):
        conns = self.active.get(uid)
        if not conns:
            return
        conns.discard(ws)
        if not conns:
            del self.active[uid]

    async def send_to_user(self, uid: str, message: dict):
        conns = self.active.get(uid)
        if not conns:
            return
        dead = set()
        for ws in conns:
            try:
                await ws.send_json(message)
            except Exception:
                dead.add(ws)
        conns -= dead
        if not conns:
            del self.active[uid]

manager = ConnectionManager()

def cleanup_unverified_users(max_age_minutes: int = 15):
    cutoff_ms = int(time.time() * 1000) - max_age_minutes * 60 * 1000
    deleted = 0
    page = auth.list_users()
    while page:
        for user in page.users:
            ids = [p.provider_id for p in user.provider_data]
            if "password" in ids and not user.email_verified \
                    and user.user_metadata.creation_timestamp < cutoff_ms:
                try:
                    auth.delete_user(user.uid)
                    deleted += 1
                except Exception as e:
                    print(f"[cleanup] Failed to delete {user.uid}: {e}")
        page = page.get_next_page()
    print(f"[cleanup] Removed {deleted} unverified user(s).")

@asynccontextmanager
async def lifespan(_: FastAPI):
    cleanup_unverified_users()
    yield

app = FastAPI(title="Secure Signing Portal", lifespan=lifespan)

_ORIGINS = [
    f"{scheme}://{host}:{port}"
    for scheme in ("http", "https")
    for host in ("localhost", "127.0.0.1")
    for port in (5500, 3000, 8000)
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class CreateRequestBody(BaseModel):
    content:          str
    signature_format: str = "pkcs7"  

class UpdateStatusBody(BaseModel):
    status: str

class RecoverAccountBody(BaseModel):
    backup_key: str

class ResetPasswordBody(BaseModel):
    email:        str
    backup_key:   str
    new_password: str

class RequestCertificateBody(BaseModel):
    csr_pem: str           
    force:   bool = False   

class ImportCertificateBody(BaseModel):
    cert_pem: str           

class SubmitSignatureBody(BaseModel):
    request_id:       int
    pkcs7_b64:        str          
    content_hash:     str          
    signature_format: str = "pkcs7"  

@contextmanager
def get_cursor():
    conn = psycopg2.connect(**DB_CONFIG)
    cur  = conn.cursor()
    try:
        yield conn, cur
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()
        conn.close()

def _hash_code(code: str) -> str:
    return hashlib.sha256(code.encode()).hexdigest()

def generate_backup_codes(n: int = 10) -> tuple[list[str], list[str]]:
    """Returns (plaintext_codes, hashed_codes). Format: AAAA-BBBB-CCCC."""
    plain, hashed = [], []
    for _ in range(n):
        raw  = secrets.token_hex(6).upper()
        code = f"{raw[0:4]}-{raw[4:8]}-{raw[8:12]}"
        plain.append(code)
        hashed.append(_hash_code(code))
    return plain, hashed

def _consume_backup_key(user_id: int, backup_key: str, cur) -> bool:
    """Verify and delete one backup key row. Returns True if matched and deleted."""
    cur.execute("SELECT id, code_hash FROM backup_codes WHERE user_id = %s", (user_id,))
    key_hash = _hash_code(backup_key.strip().upper())
    for row_id, stored_hash in cur.fetchall():
        if stored_hash == key_hash:
            cur.execute("DELETE FROM backup_codes WHERE id = %s", (row_id,))
            return True
    return False

def _remaining_key_count(user_id: int, cur) -> int:
    cur.execute("SELECT COUNT(*) FROM backup_codes WHERE user_id = %s", (user_id,))
    return cur.fetchone()[0]

def _bearer_token(authorization: Optional[str]) -> str:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid Authorization header.")
    return authorization[7:].strip()

def verify_token(authorization: Optional[str]) -> dict:
    try:
        return auth.verify_id_token(_bearer_token(authorization), clock_skew_seconds=10)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=401, detail="Authentication failed. Please log in again.")

def _hash_session_token(raw_token: str) -> str:
    """SHA-256 hash of the raw session token. This is what gets stored in the DB.
    Session tokens are 256-bit random values so SHA-256 is appropriate, there is
    no dictionary attack surface, and bcrypt's cost would just add latency with
    no security gain."""
    return hashlib.sha256(raw_token.encode()).hexdigest()

def _generate_session_token() -> str:
    """Generate a cryptographically secure 32-byte (64 hex char) random token.
    This is the raw value returned to the client exactly once. It is never
    stored in plaintext, only its SHA-256 hash goes to the DB."""
    return secrets.token_hex(32)

def create_session(user_id: int, platform: str, conn, cur, ip_address: str = None) -> str:
    """
    Create a new session for the given user+platform, replacing any existing
    session for that platform. This enforces the one-session-per-platform rule.
    For web sessions, ip_address is stored and checked on every request.
    Returns the raw (plaintext) session token, never stored in plaintext.
    """
    cur.execute(
        "DELETE FROM sessions WHERE user_id = %s AND platform = %s",
        (user_id, platform)
    )

    raw_token  = _generate_session_token()
    token_hash = _hash_session_token(raw_token)

    cur.execute(
        """
        INSERT INTO sessions (user_id, token_hash, platform, ip_address, last_active, created_at)
        VALUES (%s, %s, %s, %s, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        """,
        (user_id, token_hash, platform, ip_address)
    )
    return raw_token

def validate_and_refresh_session(user_id: int, raw_token: str, cur, current_ip: str = None) -> None:
    """
    Validate a session token for the given user. Raises 401 if:
      - The token does not exist
      - The session has been inactive for more than SESSION_TIMEOUT_SECONDS
      - The request IP does not match the IP the session was created from (web only)
    On success, updates last_active to NOW() (sliding window).
    """
    token_hash = _hash_session_token(raw_token)

    cur.execute(
        """
        SELECT id, last_active, ip_address
        FROM   sessions
        WHERE  token_hash = %s AND user_id = %s
        """,
        (token_hash, user_id)
    )
    row = cur.fetchone()

    if not row:
        raise HTTPException(status_code=401, detail="Session not found. Please log in again.")

    session_id, last_active, stored_ip = row

    if current_ip and stored_ip and current_ip != stored_ip:
        cur.execute("DELETE FROM sessions WHERE id = %s", (session_id,))
        log_action(user_id, "session_ip_mismatch", ip_address=current_ip, detail=f"stored={stored_ip} current={current_ip}", cur=cur)
        raise HTTPException(status_code=401, detail="Session IP mismatch. Please log in again.")

    cur.execute("SELECT EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - %s))", (last_active,))
    idle_seconds = cur.fetchone()[0]

    if idle_seconds > SESSION_TIMEOUT_SECONDS:
        cur.execute("DELETE FROM sessions WHERE id = %s", (session_id,))
        log_action(user_id, "session_expired", cur=cur)
        raise HTTPException(status_code=401, detail="Session expired. Please log in again.")

    cur.execute(
        "UPDATE sessions SET last_active = CURRENT_TIMESTAMP WHERE id = %s",
        (session_id,)
    )

def delete_session(user_id: int, raw_token: str, cur) -> None:
    """Delete a specific session by raw token (used on logout)."""
    token_hash = _hash_session_token(raw_token)
    cur.execute(
        "DELETE FROM sessions WHERE token_hash = %s AND user_id = %s",
        (token_hash, user_id)
    )

def delete_all_sessions(user_id: int, cur) -> None:
    """Delete ALL sessions for a user across all platforms.
    Called when a device is reported compromised so the account is force-logged
    out everywhere simultaneously."""
    cur.execute("DELETE FROM sessions WHERE user_id = %s", (user_id,))

def log_action(user_id, action, platform=None, ip_address=None, detail=None, cur=None, conn=None):
    """Insert a row into the logs table. Best-effort, never raises."""
    try:
        cur.execute(
            """
            INSERT INTO logs (user_id, action, platform, ip_address, detail, created_at)
            VALUES (%s, %s, %s, %s, %s, CURRENT_TIMESTAMP)
            """,
            (user_id, action, platform, ip_address, detail)
        )
    except Exception as e:
        print(f"[log] Failed to write log: {e}")

def validate_session_token_ws(user_id: int, raw_token: str, cur, current_ip: str = None) -> bool:
    """
    Same as validate_and_refresh_session but returns False instead of raising,
    so the WebSocket handler can send a clean auth_error message.
    Also refreshes last_active on success.
    """
    try:
        validate_and_refresh_session(user_id, raw_token, cur, current_ip=current_ip)
        return True
    except HTTPException:
        return False

def require_auth_and_session(
    authorization: Optional[str],
    x_session_token: Optional[str],
    x_platform: Optional[str],
    conn,
    cur,
    web_session_cookie: Optional[str] = None,
    current_ip: Optional[str] = None,
) -> dict:
    """
    Authentication guard for every protected endpoint.

    - Web: Firebase JWT + HttpOnly cookie session token + IP check.
    - Mobile: Firebase JWT + X-Session-Token header (unchanged).

    Raises 401 if any required check fails.
    Returns the user dict on success.
    """
    decoded  = verify_token(authorization)
    user     = upsert_user_from_token(decoded, conn, cur)
    platform = (x_platform or "web").strip().lower()

    if platform == "web":
        if not web_session_cookie:
            raise HTTPException(status_code=401, detail="Session not found. Please log in again.")
        validate_and_refresh_session(user["id"], web_session_cookie, cur, current_ip=current_ip)

    elif platform == "mobile":
        if not x_session_token:
            raise HTTPException(status_code=401, detail="Missing session token. Please log in again.")
        validate_and_refresh_session(user["id"], x_session_token, cur)

    return user

def _provider_display(provider: Optional[str]) -> str:
    if provider == "google.com": return "Google"
    if provider == "password":   return "System"
    return provider or "Unknown"

def _avatar_letter(username: str) -> str:
    return username[0].upper() if username else "U"

def _row_to_user(row) -> dict:
    provider = row[4]
    username = row[3] or "user"
    return {
        "id":               row[0],
        "firebase_uid":     row[1],
        "email":            row[2],
        "username":         username,
        "provider":         provider,
        "provider_display": _provider_display(provider),
        "avatar_letter":    _avatar_letter(username),
        "display_name":     row[5],
        "is_blacklisted":   row[6],
        "blacklisted_at":   row[7].isoformat() if row[7] else None,
        "created_at":       row[8].isoformat() if row[8] else str(row[8]),
    }

def _derive_username(email: Optional[str], provider: str, display_name: Optional[str]) -> str:
    if provider == "google.com" and display_name:
        return display_name.strip()
    if email and "@" in email:
        return email.split("@")[0]
    return display_name.strip() if display_name else "user"

def upsert_user_from_token(decoded_token: dict, conn, cur) -> dict:
    firebase_uid   = decoded_token["uid"]
    email          = decoded_token.get("email")
    display_name   = decoded_token.get("name", "")
    email_verified = decoded_token.get("email_verified", False)
    provider       = decoded_token.get("firebase", {}).get("sign_in_provider", "unknown")

    if provider == "password" and not email_verified:
        raise HTTPException(
            status_code=403,
            detail="Email not verified. Please verify your email before using the app."
        )

    username = _derive_username(email, provider, display_name)

    if email:
        cur.execute(
            "SELECT firebase_uid, provider FROM users WHERE email = %s",
            (email,)
        )
        existing_by_email = cur.fetchone()
        if existing_by_email:
            existing_uid, existing_provider = existing_by_email
            if existing_uid != firebase_uid:
                existing_display = _provider_display(existing_provider)
                raise HTTPException(
                    status_code=409,
                    detail="Sign-in method not allowed for this account."
                )

    cur.execute(
        "SELECT id, firebase_uid, email, username, provider, display_name, "
        "is_blacklisted, blacklisted_at, created_at "
        "FROM users WHERE firebase_uid = %s",
        (firebase_uid,)
    )
    row = cur.fetchone()

    if row:
        existing_provider = row[4]
        if existing_provider != provider:
            existing_display = _provider_display(existing_provider)
            raise HTTPException(
                status_code=409,
                detail="Sign-in method not allowed for this account."
            )
        cur.execute(
            "UPDATE users SET email=%s, username=%s, display_name=%s WHERE id=%s",
            (email, username, display_name, row[0])
        )
        cur.execute(
            "SELECT id, firebase_uid, email, username, provider, display_name, "
            "is_blacklisted, blacklisted_at, created_at FROM users WHERE id=%s",
            (row[0],)
        )
        return _row_to_user(cur.fetchone())

    cur.execute(
        "INSERT INTO users (firebase_uid, email, username, provider, display_name) "
        "VALUES (%s,%s,%s,%s,%s) "
        "RETURNING id, firebase_uid, email, username, provider, display_name, "
        "is_blacklisted, blacklisted_at, created_at",
        (firebase_uid, email, username, provider, display_name)
    )
    return _row_to_user(cur.fetchone())

def ensure_not_blacklisted(user: dict):
    if user["is_blacklisted"]:
        raise HTTPException(
            status_code=403,
            detail="This account is blacklisted. Use your backup keys to recover access."
        )

def _row_to_request(row) -> dict:
    return {
        "id":         row[0],
        "content":    row[1],
        "summary":    row[2],
        "status":     row[3],
        "created_at": row[4].isoformat() if row[4] else str(row[4]),
        "updated_at": row[5].isoformat() if row[5] else str(row[5]),
    }

def summarize_text(text: str, max_length: int = 120) -> str:
    clean = " ".join(text.split())
    return clean if len(clean) <= max_length else clean[:max_length].rstrip() + "..."


def _request_certificate_from_adcs(csr_pem: str, user_email: str, user_cn: str) -> str:
    """
    Submit a CSR to AD CS certsrv and return the signed X.509 certificate as PEM.
    Raises HTTPException on failure.
    """
    from requests.auth import HTTPBasicAuth

    submit_url = f"{ADCS_HOST}/certsrv/certfnsh.asp"
    response = http_requests.post(
        submit_url,
        auth=HTTPBasicAuth(ADCS_USERNAME, ADCS_PASSWORD),
        data={
            "Mode":             "newreq",
            "CertRequest":      csr_pem,
            "CertAttrib":       "CertificateTemplate:User",
            "FriendlyType":     "Saved-Request Certificate",
            "TargetStoreFlags": "0",
            "SaveCert":         "yes"
        },
        verify=False,
        timeout=15
    )

    if response.status_code != 200:
        raise HTTPException(status_code=502, detail="Certificate issuance failed. Please try again.")

    if "Certificate Issued" not in response.text and "certnew.cer" not in response.text:
        if "Certificate Pending" in response.text:
            raise HTTPException(status_code=502, detail="Certificate issuance failed. Please try again.")
        raise HTTPException(status_code=502, detail="Certificate issuance failed. Please try again.")

    req_id_match = re.search(r"ReqID=(\d+)", response.text)
    if not req_id_match:
        raise HTTPException(status_code=502, detail="Certificate issuance failed. Please try again.")

    req_id = req_id_match.group(1)
    cert_url = f"{ADCS_HOST}/certsrv/certnew.cer?ReqID={req_id}&Enc=b64"
    cert_response = http_requests.get(
        cert_url,
        auth=HTTPBasicAuth(ADCS_USERNAME, ADCS_PASSWORD),
        verify=False,
        timeout=15
    )

    if cert_response.status_code != 200:
        raise HTTPException(status_code=502, detail="Certificate issuance failed. Please try again.")

    raw = cert_response.text.strip().replace("\r\n", "\n").replace("\r", "\n")

    if raw.startswith("-----BEGIN CERTIFICATE-----"):
        lines = raw.splitlines()
        header = lines[0]
        footer = lines[-1]
        body   = "".join(l.strip() for l in lines[1:-1] if l.strip() and not l.startswith("-----"))
        body64 = "\n".join(body[i:i+64] for i in range(0, len(body), 64))
        cert_pem = f"{header}\n{body64}\n{footer}"
    else:
        body   = "".join(raw.split())
        body64 = "\n".join(body[i:i+64] for i in range(0, len(body), 64))
        cert_pem = f"-----BEGIN CERTIFICATE-----\n{body64}\n-----END CERTIFICATE-----"

    return cert_pem


def _get_cert_serial_and_expiry(cert_pem: str) -> tuple[str, str]:
    """Extract serial number and expiry date from a PEM certificate."""
    cert = x509.load_pem_x509_certificate(cert_pem.encode())
    serial = format(cert.serial_number, "x").upper()
    expires_at = cert.not_valid_after_utc.isoformat()
    return serial, expires_at


def _revoke_certificate_in_adcs(serial_number: str) -> bool:
    """
    Revoke a certificate in AD CS by serial number.
    Calls the Flask revocation API running on the Windows VM.
    Best-effort, returns True on success, False on failure.
    DB revocation is always done first, this is supplementary.
    """
    try:
        resp = http_requests.post(
            f"{REVOCATION_API_URL}/revoke",
            json={
                "serial": serial_number,
                "reason": "1",
                "secret": REVOCATION_SECRET
            },
            verify=False,
            timeout=10
        )
        if resp.status_code == 200:
            print(f"[ADCS] Certificate {serial_number} revoked in AD CS successfully.")
            return True
        else:
            print(f"[ADCS] Revocation API returned {resp.status_code}: {resp.text}")
            return False
    except Exception as e:
        print(f"[ADCS] Revocation API call failed (non-fatal): {e}")
        return False


def _download_crl() -> x509.CertificateRevocationList:
    """Download and parse the CRL from AD CS. Short timeout, best effort only."""
    resp = http_requests.get(CRL_URL, timeout=3)
    if resp.status_code != 200:
        raise Exception(f"CRL download failed: HTTP {resp.status_code}")
    return x509.load_der_x509_crl(resp.content)


def _extract_pkcs7_components(pkcs7_der: bytes) -> dict | None:
    """
    Walk PKCS#7 SignedData DER ASN.1 to extract:
      - signed_attrs_bytes: raw bytes of signedAttrs (tag 0xA0) for re-tagging
      - signature_bytes: raw RSA/ECDSA signature bytes from SignerInfo
      - content_bytes: encapsulated content bytes
      - signing_time: extracted UTCTime string if present, else None

    Returns dict or None if parsing fails.
    """
    try:
        def read_len(data, pos):
            if data[pos] < 0x80:
                return data[pos], pos + 1
            n = data[pos] & 0x7F
            return int.from_bytes(data[pos+1:pos+1+n], 'big'), pos + 1 + n

        def read_tlv(data, pos):
            if pos >= len(data): return None, pos
            tag = data[pos]; pos += 1
            length, pos = read_len(data, pos)
            value = data[pos:pos+length]
            return (tag, value), pos + length

        def find_all(data, target_tag):
            """Find all TLV blocks with target_tag at top level."""
            results = []
            pos = 0
            while pos < len(data):
                if pos >= len(data): break
                tag = data[pos]; pos += 1
                if pos >= len(data): break
                length, pos = read_len(data, pos)
                value = data[pos:pos+length]
                pos += length
                if tag == target_tag:
                    results.append(value)
            return results

        pos = 0
        tlv, pos = read_tlv(pkcs7_der, 0)
        if not tlv or tlv[0] != 0x30: return None
        ci_inner = tlv[1]

        pos2 = 0
        tlv2, pos2 = read_tlv(ci_inner, pos2)
        tlv3, pos2 = read_tlv(ci_inner, pos2)
        if not tlv3: return None
        sd_wrapper = tlv3[1]

        tlv4, _ = read_tlv(sd_wrapper, 0)
        if not tlv4 or tlv4[0] != 0x30: return None
        sd = tlv4[1]

        pos3 = 0
        components = []
        while pos3 < len(sd):
            t = sd[pos3]
            length, npos = read_len(sd, pos3+1)
            val = sd[npos:npos+length]
            components.append((t, val, pos3, npos+length))
            pos3 = npos + length

        content_bytes = None
        for tag, val, _, _ in components:
            if tag == 0x30:
                inner_pos = 0
                oid_tlv, inner_pos = read_tlv(val, inner_pos)
                explicit_tlv, inner_pos = read_tlv(val, inner_pos)
                if explicit_tlv and explicit_tlv[0] == 0xA0:
                    octet_tlv, _ = read_tlv(explicit_tlv[1], 0)
                    if octet_tlv and octet_tlv[0] == 0x04:
                        content_bytes = octet_tlv[1]
                break

        signer_infos_val = None
        for tag, val, _, _ in reversed(components):
            if tag == 0x31:
                signer_infos_val = val
                break
        if not signer_infos_val: return None

        si_tlv, _ = read_tlv(signer_infos_val, 0)
        if not si_tlv or si_tlv[0] != 0x30: return None
        si = si_tlv[1]

        si_pos = 0
        si_components = []
        while si_pos < len(si):
            t = si[si_pos]
            length, npos = read_len(si, si_pos+1)
            val = si[npos:npos+length]
            raw_start = si_pos
            si_components.append((t, val, raw_start, npos+length))
            si_pos = npos + length

        signed_attrs_raw = None
        signed_attrs_inner = None
        signature_bytes = None
        for tag, val, raw_start, raw_end in si_components:
            if tag == 0xA0:
                signed_attrs_raw = si[raw_start:raw_end]
                signed_attrs_inner = val
            if tag == 0x04:
                signature_bytes = val

        signed_attrs_for_verify = None
        if signed_attrs_raw is not None:
            signed_attrs_for_verify = bytes([0x31]) + signed_attrs_raw[1:]

        signing_time = None
        if signed_attrs_inner:
            oid_signing_time = bytes([0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x09, 0x05])
            attr_pos = 0
            while attr_pos < len(signed_attrs_inner):
                attr_tlv, attr_pos = read_tlv(signed_attrs_inner, attr_pos)
                if not attr_tlv or attr_tlv[0] != 0x30: continue
                attr_inner = attr_tlv[1]
                oid_tlv2, inner_pos2 = read_tlv(attr_inner, 0)
                if not oid_tlv2 or oid_tlv2[0] != 0x06: continue
                if oid_tlv2[1] == oid_signing_time:
                    set_tlv, _ = read_tlv(attr_inner, inner_pos2)
                    if set_tlv and set_tlv[0] == 0x31:
                        time_tlv, _ = read_tlv(set_tlv[1], 0)
                        if time_tlv and time_tlv[0] == 0x17:
                            signing_time = time_tlv[1].decode('ascii', errors='ignore')

        return {
            "signed_attrs_for_verify": signed_attrs_for_verify,
            "signed_attrs_present":    signed_attrs_raw is not None,
            "signature_bytes":         signature_bytes,
            "content_bytes":           content_bytes,
            "signing_time":            signing_time,
        }
    except Exception as e:
        print(f"[PKCS7 Parse] Failed: {e}")
        return None


def _verify_pkcs7_signature(pkcs7_b64: str, expected_content_hash: str) -> tuple[bool, str, str]:
    """
    Full PKCS#7 signature verification for Fyp54-CA issued certificates (ECDSA P-256).
    Returns (is_valid, signer_serial, error_message).

    Verification steps:
    1. Decode and parse PKCS#7 structure
    2. Extract signer certificate
    3. Verify certificate chain (issued by Fyp54-CA)
    4. Verify certificate validity period
    5. Download CRL and check certificate not revoked
    6. Verify content hash matches (via messageDigest attr or direct hash)
    7. Verify ECDSA signature cryptographically over signedAttrs (if present) or content
    """
    from datetime import timezone, datetime
    try:
        try:
            pkcs7_der = base64.b64decode(pkcs7_b64)
        except Exception:
            return False, "", "Invalid base64 encoding."

        try:
            pkcs7_obj = pkcs7.load_der_pkcs7_certificates(pkcs7_der)
        except Exception:
            return False, "", "Invalid PKCS#7 structure."

        if not pkcs7_obj:
            return False, "", "No certificates found in PKCS#7."

        signer_cert = pkcs7_obj[0]
        signer_serial = format(signer_cert.serial_number, "x").upper()

        try:
            with open(CA_CERT_PATH, "rb") as f:
                ca_cert = x509.load_pem_x509_certificate(f.read())
        except Exception:
            return False, signer_serial, "CA certificate not found on backend."

        if signer_cert.issuer != ca_cert.subject:
            return False, signer_serial, "Certificate was not issued by Fyp54-CA."

        try:
            ca_cert.public_key().verify(
                signer_cert.signature,
                signer_cert.tbs_certificate_bytes,
                ECDSA(hashes.SHA256())
            )
        except Exception:
            try:
                ca_cert.public_key().verify(
                    signer_cert.signature,
                    signer_cert.tbs_certificate_bytes,
                    asym_padding.PKCS1v15(),
                    hashes.SHA256()
                )
            except Exception:
                return False, signer_serial, "Certificate chain verification failed."

        now = datetime.now(timezone.utc)
        if now < signer_cert.not_valid_before_utc:
            return False, signer_serial, "Certificate is not yet valid."
        if now > signer_cert.not_valid_after_utc:
            return False, signer_serial, "Certificate has expired."

        try:
            crl = _download_crl()
            revoked_serials = [r.serial_number for r in crl]
            if signer_cert.serial_number in revoked_serials:
                return False, signer_serial, "Certificate has been revoked (CRL)."
        except Exception as e:
            return False, signer_serial, f"CRL check failed, cannot verify revocation status: {e}"

        components = _extract_pkcs7_components(pkcs7_der)

        if components and components["signed_attrs_present"]:
            signed_attrs_for_verify = components["signed_attrs_for_verify"]
            signature_bytes         = components["signature_bytes"]

            if components["content_bytes"] is not None:
                import hashlib
                actual_hash = hashlib.sha256(components["content_bytes"]).hexdigest()
                if actual_hash.lower() != expected_content_hash.lower():
                    return False, signer_serial, "Content hash mismatch, signed content does not match submitted content."

            if components.get("signing_time"):
                print(f"[PKCS7] Signing time from signedAttrs: {components['signing_time']}")

            if not signed_attrs_for_verify or not signature_bytes:
                return False, signer_serial, "Could not extract signature bytes from PKCS#7, structure invalid."
            try:
                signer_cert.public_key().verify(
                    signature_bytes,
                    signed_attrs_for_verify,
                    ECDSA(hashes.SHA256())
                )
                print(f"[PKCS7] ECDSA signature verified over signedAttrs ✓")
            except Exception as e:
                return False, signer_serial, f"ECDSA signature verification failed: {e}"

        else:
            print("[PKCS7] No signedAttrs, using legacy content-direct verification path")
            if not components or not components["content_bytes"] or not components["signature_bytes"]:
                return False, signer_serial, "Could not extract content or signature bytes from PKCS#7, structure invalid."
            try:
                signer_cert.public_key().verify(
                    components["signature_bytes"],
                    components["content_bytes"],
                    ECDSA(hashes.SHA256())
                )
            except Exception as e:
                return False, signer_serial, f"ECDSA signature verification failed (legacy): {e}"

        return True, signer_serial, ""

    except Exception as e:
        return False, "", f"Verification error: {str(e)}"



def _check_ocsp_status(cert_pem: str) -> str:
    """
    Check certificate revocation status via OCSP.
    Returns: "good" | "revoked" | "unknown" | "error"
    """
    try:
        cert = x509.load_pem_x509_certificate(cert_pem.encode())
        with open(CA_CERT_PATH, "rb") as f:
            issuer_cert = x509.load_pem_x509_certificate(f.read())

        builder = ocsp.OCSPRequestBuilder()
        builder = builder.add_certificate(cert, issuer_cert, hashes.SHA256())
        ocsp_request = builder.build()
        ocsp_request_der = ocsp_request.public_bytes(serialization.Encoding.DER)

        try:
            aia = cert.extensions.get_extension_for_class(x509.AuthorityInformationAccess)
            ocsp_urls = [
                desc.access_location.value
                for desc in aia.value
                if desc.access_method == x509.AuthorityInformationAccessOID.OCSP
            ]
            if not ocsp_urls:
                return "unknown"
            ocsp_url = ocsp_urls[0]
        except Exception:
            ocsp_url = os.getenv("OCSP_URL")

        ocsp_response_raw = http_requests.post(
            ocsp_url,
            data=ocsp_request_der,
            headers={"Content-Type": "application/ocsp-request"},
            verify=False,
            timeout=10
        )

        if ocsp_response_raw.status_code != 200:
            return "error"

        ocsp_resp = ocsp.load_der_ocsp_response(ocsp_response_raw.content)

        if ocsp_resp.response_status != ocsp.OCSPResponseStatus.SUCCESSFUL:
            return "error"

        cert_status = ocsp_resp.certificate_status
        if cert_status == ocsp.OCSPCertStatus.GOOD:
            return "good"
        elif cert_status == ocsp.OCSPCertStatus.REVOKED:
            return "revoked"
        else:
            return "unknown"

    except Exception as e:
        print(f"[OCSP] Check failed: {e}")
        return "error"


def _check_ocsp_status_external(cert: x509.Certificate, issuer_cert: x509.Certificate) -> str:
    """
    Check revocation status of an externally-imported certificate via OCSP.
    Unlike _check_ocsp_status(), this does NOT use the local CA cert —
    it uses the issuer cert extracted from the PFX chain or fetched from AIA.
    Returns: "good" | "revoked" | "unknown" | "error"
    """
    try:
        try:
            aia = cert.extensions.get_extension_for_oid(ExtensionOID.AUTHORITY_INFORMATION_ACCESS)
            ocsp_urls = [
                desc.access_location.value
                for desc in aia.value
                if desc.access_method == AuthorityInformationAccessOID.OCSP
            ]
            if not ocsp_urls:
                return "unknown"
            ocsp_url = ocsp_urls[0]
        except Exception:
            return "unknown"

        builder = ocsp.OCSPRequestBuilder()
        builder = builder.add_certificate(cert, issuer_cert, hashes.SHA256())
        ocsp_request = builder.build()
        ocsp_request_der = ocsp_request.public_bytes(serialization.Encoding.DER)

        ocsp_response_raw = http_requests.post(
            ocsp_url,
            data=ocsp_request_der,
            headers={"Content-Type": "application/ocsp-request"},
            verify=False,
            timeout=10
        )

        if ocsp_response_raw.status_code != 200:
            return "error"

        ocsp_resp = ocsp.load_der_ocsp_response(ocsp_response_raw.content)

        if ocsp_resp.response_status != ocsp.OCSPResponseStatus.SUCCESSFUL:
            return "error"

        cert_status = ocsp_resp.certificate_status
        status_value = cert_status.value if hasattr(cert_status, 'value') else cert_status
        if status_value == 0:
            return "good"
        elif status_value == 1:
            return "revoked"
        else:
            return "unknown"

    except Exception as e:
        print(f"[OCSP-External] Check failed: {e}")
        return "error"


def _fetch_issuer_cert_from_aia(cert: x509.Certificate):
    """
    Fetch the issuer certificate from the AIA caIssuers URL embedded in the cert.
    Returns x509.Certificate or None.
    """
    try:
        aia = cert.extensions.get_extension_for_oid(ExtensionOID.AUTHORITY_INFORMATION_ACCESS)
        issuer_urls = [
            desc.access_location.value
            for desc in aia.value
            if desc.access_method == AuthorityInformationAccessOID.CA_ISSUERS
        ]
        if not issuer_urls:
            return None
        resp = http_requests.get(issuer_urls[0], timeout=10, verify=False)
        if resp.status_code != 200:
            return None
        try:
            return x509.load_der_x509_certificate(resp.content)
        except Exception:
            return x509.load_pem_x509_certificate(resp.content)
    except Exception as e:
        print(f"[AIA] Could not fetch issuer cert: {e}")
        return None


def _verify_external_pkcs7_signature(
    pkcs7_b64: str,
    expected_content_hash: str
) -> tuple[bool, str, str]:
    """
    Verify a PKCS#7 SignedData structure built with an externally imported certificate.
    Used when cert source == 'imported' (RSA key from PFX, any trusted online CA).

    Steps:
    1. Parse PKCS#7 structure
    2. Extract signer certificate
    3. Not self-signed + has OCSP/CRL revocation info
    4. Validity period
    5. Revocation: OCSP first, CRL fallback (both non-fatal on network error)
    6. Content hash
    7. Cryptographic RSA signature verification

    Returns (is_valid, signer_serial, error_message).
    """
    from datetime import timezone, datetime
    try:
        try:
            pkcs7_der = base64.b64decode(pkcs7_b64)
        except Exception:
            return False, "", "Invalid base64 encoding."
        try:
            pkcs7_obj = pkcs7.load_der_pkcs7_certificates(pkcs7_der)
        except Exception:
            return False, "", "Invalid PKCS#7 structure."
        if not pkcs7_obj:
            return False, "", "No certificates found in PKCS#7."

        signer_cert = pkcs7_obj[0]
        signer_serial = format(signer_cert.serial_number, "x").upper()

        if signer_cert.issuer == signer_cert.subject:
            return False, signer_serial, "Self-signed certificates are not accepted."

        has_ocsp = False
        has_crl  = False
        try:
            aia = signer_cert.extensions.get_extension_for_oid(ExtensionOID.AUTHORITY_INFORMATION_ACCESS)
            has_ocsp = any(
                d.access_method == AuthorityInformationAccessOID.OCSP
                for d in aia.value
            )
        except x509.ExtensionNotFound:
            pass
        try:
            signer_cert.extensions.get_extension_for_oid(ExtensionOID.CRL_DISTRIBUTION_POINTS)
            has_crl = True
        except x509.ExtensionNotFound:
            pass

        if not has_ocsp and not has_crl:
            return False, signer_serial, "Certificate has no revocation information. Must be from a recognized online CA."

        now = datetime.now(timezone.utc)
        if now < signer_cert.not_valid_before_utc:
            return False, signer_serial, "Certificate is not yet valid."
        if now > signer_cert.not_valid_after_utc:
            return False, signer_serial, "Certificate has expired."

        revocation_checked = False

        issuer_cert = _fetch_issuer_cert_from_aia(signer_cert)
        if issuer_cert and has_ocsp:
            try:
                cert_pem_str = signer_cert.public_bytes(serialization.Encoding.PEM).decode()
                ocsp_status = _check_ocsp_status_external(signer_cert, issuer_cert)
                if ocsp_status == "good":
                    revocation_checked = True
                elif ocsp_status == "revoked":
                    return False, signer_serial, "Certificate has been revoked (OCSP)."
            except Exception as e:
                print(f"[OCSP-External] Failed during verification, trying CRL: {e}")

        if not revocation_checked and has_crl:
            try:
                cdp = signer_cert.extensions.get_extension_for_oid(ExtensionOID.CRL_DISTRIBUTION_POINTS)
                crl_urls = [
                    name.value
                    for point in cdp.value
                    if point.full_name
                    for name in point.full_name
                ]
                if crl_urls:
                    crl_resp = http_requests.get(crl_urls[0], timeout=10, verify=False)
                    if crl_resp.status_code == 200:
                        try:
                            crl = x509.load_der_x509_crl(crl_resp.content)
                        except Exception:
                            crl = x509.load_pem_x509_crl(crl_resp.content)
                        revoked_entry = crl.get_revoked_certificate_by_serial_number(
                            signer_cert.serial_number
                        )
                        if revoked_entry is not None:
                            return False, signer_serial, "Certificate has been revoked (CRL)."
                        revocation_checked = True
            except Exception as e:
                print(f"[CRL-External] Check failed (non-fatal): {e}")

        if not revocation_checked:
            print(f"[Revocation] Both OCSP and CRL unavailable for {signer_serial} proceeding (DB check is safety net)")

        import hashlib
        components = _extract_pkcs7_components(pkcs7_der)

        if not components:
            return False, signer_serial, "Could not parse PKCS#7 structure for signature verification."

        if components["content_bytes"] is not None:
            actual_hash = hashlib.sha256(components["content_bytes"]).hexdigest()
            if actual_hash.lower() != expected_content_hash.lower():
                return False, signer_serial, "Content hash mismatch, signed content does not match submitted content."

        public_key = signer_cert.public_key()
        from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicKey

        if not isinstance(public_key, RSAPublicKey):
            return False, signer_serial, "Expected RSA key for imported certificate."

        if components and components["signed_attrs_present"]:
            signed_attrs_for_verify = components["signed_attrs_for_verify"]
            signature_bytes         = components["signature_bytes"]

            if components.get("signing_time"):
                print(f"[PKCS7-External] Signing time: {components['signing_time']}")

            if not signed_attrs_for_verify or not signature_bytes:
                return False, signer_serial, "Could not extract signature bytes from PKCS#7, structure invalid."
            try:
                public_key.verify(
                    signature_bytes,
                    signed_attrs_for_verify,
                    asym_padding.PKCS1v15(),
                    hashes.SHA256()
                )
                print(f"[PKCS7-External] RSA signature verified over signedAttrs ✓")
            except Exception as e:
                return False, signer_serial, f"RSA signature verification failed: {e}"
        else:
            print("[PKCS7-External] No signedAttrs, using legacy content-direct verification path")
            if not components or not components["content_bytes"] or not components["signature_bytes"]:
                return False, signer_serial, "Could not extract content or signature bytes from PKCS#7, structure invalid."
            try:
                public_key.verify(
                    components["signature_bytes"],
                    components["content_bytes"],
                    asym_padding.PKCS1v15(),
                    hashes.SHA256()
                )
            except Exception as e:
                return False, signer_serial, f"RSA signature verification failed: {e}"

        return True, signer_serial, ""

    except Exception as e:
        return False, "", f"External verification error: {str(e)}"


def _extract_rsa_signature_from_pkcs7(pkcs7_der: bytes) -> bytes | None:
    """
    Walk the PKCS#7 DER ASN.1 structure to extract the RSA signature bytes
    from the SignerInfo's signature field (last OCTET STRING in SignerInfo).
    Returns the raw signature bytes or None if parsing fails.
    """
    try:
        def read_length(data: bytes, pos: int) -> tuple[int, int]:
            """Returns (length, new_pos)."""
            if data[pos] < 0x80:
                return data[pos], pos + 1
            n_bytes = data[pos] & 0x7F
            length = int.from_bytes(data[pos+1:pos+1+n_bytes], 'big')
            return length, pos + 1 + n_bytes

        def find_last_octet_string(data: bytes) -> bytes | None:
            """Find all OCTET STRING (0x04) values at any depth, return last one."""
            results = []
            pos = 0
            while pos < len(data):
                if pos >= len(data):
                    break
                tag = data[pos]
                pos += 1
                if pos >= len(data):
                    break
                length, pos = read_length(data, pos)
                value = data[pos:pos+length]
                pos += length
                if tag == 0x04:
                    results.append(value)
                elif tag in (0x30, 0x31, 0xa0, 0xa1):
                    nested = find_last_octet_string(value)
                    if nested:
                        results.append(nested)
            return results[-1] if results else None

        return find_last_octet_string(pkcs7_der)
    except Exception:
        return None


@app.get("/")
def home():
    return {"message": "Backend is running"}

@app.get("/profile")
def get_profile(
    request:          Request,
    authorization:    Optional[str] = Header(default=None),
    x_session_token:  Optional[str] = Header(default=None),
    x_platform:       Optional[str] = Header(default=None),
    web_session:      Optional[str] = Cookie(default=None),
):
    try:
        with get_cursor() as (conn, cur):
            user = require_auth_and_session(
                authorization, x_session_token, x_platform, conn, cur,
                web_session_cookie=web_session,
                current_ip=request.client.host
            )
            conn.commit()
        return {"status": "success", "profile": user}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="Something went wrong. Please try again.")

@app.post("/register")
def register(
    request:       Request,
    response:      Response,
    authorization: Optional[str] = Header(default=None),
    x_platform:    Optional[str] = Header(default=None),
):
    """
    Called on every login. Creates a new session for this platform.
    - Web: session token is set as an HttpOnly cookie, JS never sees it.
    - Mobile: session token is returned in JSON as before (unchanged).
    """
    decoded  = verify_token(authorization)
    platform = (x_platform or "web").strip().lower()
    client_ip = request.client.host if request.client else None
    try:
        with get_cursor() as (conn, cur):
            user = upsert_user_from_token(decoded, conn, cur)

            raw_token = create_session(user["id"], platform, conn, cur, ip_address=client_ip)

            is_existing = _remaining_key_count(user["id"], cur) > 0
            if is_existing:
                log_action(user["id"], "login", platform=platform, ip_address=client_ip, cur=cur)
                conn.commit()
                if platform == "web":
                    response.set_cookie(
                        key="web_session", value=raw_token,
                        httponly=True, secure=True, samesite="strict", max_age=86400
                    )
                    return {"status": "existing", "backup_codes": []}
                return {"status": "existing", "session_token": raw_token, "backup_codes": []}

            plain_codes, hashed_codes = generate_backup_codes(10)
            cur.executemany(
                "INSERT INTO backup_codes (user_id, code_hash) VALUES (%s, %s)",
                [(user["id"], h) for h in hashed_codes]
            )
            conn.commit()

        if platform == "web":
            response.set_cookie(
                key="web_session", value=raw_token,
                httponly=True, secure=True, samesite="strict", max_age=86400
            )
            with get_cursor() as (c2, cur2):
                log_action(user["id"], "account_created", platform=platform, ip_address=client_ip, detail="backup codes issued", cur=cur2)
                c2.commit()
            return {"status": "success", "backup_codes": plain_codes}

        with get_cursor() as (c2, cur2):
            log_action(user["id"], "account_created", platform=platform, ip_address=client_ip, detail="backup codes issued", cur=cur2)
            c2.commit()
        return {"status": "success", "session_token": raw_token, "backup_codes": plain_codes}

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="Something went wrong. Please try again.")

@app.post("/logout")
def logout(
    request:         Request,
    response:        Response,
    authorization:   Optional[str] = Header(default=None),
    x_session_token: Optional[str] = Header(default=None),
    x_platform:      Optional[str] = Header(default=None),
    web_session:     Optional[str] = Cookie(default=None),
):
    """
    Cleans up the server-side session on logout.
    - Web: deletes the session row and clears the HttpOnly cookie.
    - Mobile: deletes the session row (unchanged).
    """
    platform = (x_platform or "web").strip().lower()

    if platform == "web":
        response.delete_cookie(key="web_session", httponly=True, secure=True, samesite="strict")

    token_to_delete = web_session if platform == "web" else x_session_token
    if not token_to_delete:
        return {"status": "success", "message": "Logged out."}

    try:
        decoded = verify_token(authorization)
    except HTTPException:
        return {"status": "success", "message": "Logged out."}

    try:
        with get_cursor() as (conn, cur):
            user = upsert_user_from_token(decoded, conn, cur)
            delete_session(user["id"], token_to_delete, cur)
            log_action(user["id"], "logout", platform=platform, ip_address=request.client.host, cur=cur)
            conn.commit()
    except Exception:
        pass

    return {"status": "success", "message": "Logged out."}

@app.get("/requests")
def get_requests(
    request:         Request,
    authorization:   Optional[str] = Header(default=None),
    x_session_token: Optional[str] = Header(default=None),
    x_platform:      Optional[str] = Header(default=None),
    web_session:     Optional[str] = Cookie(default=None),
):
    try:
        with get_cursor() as (conn, cur):
            user = require_auth_and_session(
                authorization, x_session_token, x_platform, conn, cur,
                web_session_cookie=web_session, current_ip=request.client.host
            )
            ensure_not_blacklisted(user)
            cur.execute(
                "SELECT id, content, summary, status, created_at, updated_at "
                "FROM requests WHERE user_id=%s ORDER BY created_at DESC",
                (user["id"],)
            )
            rows = cur.fetchall()
            conn.commit()
        return {"status": "success", "requests": [_row_to_request(r) for r in rows]}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="Something went wrong. Please try again.")

@app.post("/requests")
async def create_request(
    request:         Request,
    body:            CreateRequestBody,
    authorization:   Optional[str] = Header(default=None),
    x_session_token: Optional[str] = Header(default=None),
    x_platform:      Optional[str] = Header(default=None),
    web_session:     Optional[str] = Cookie(default=None),
):
    content = body.content.strip()
    if not content:
        raise HTTPException(status_code=400, detail="Request content cannot be empty.")
    summary = summarize_text(content)
    try:
        with get_cursor() as (conn, cur):
            user = require_auth_and_session(
                authorization, x_session_token, x_platform, conn, cur,
                web_session_cookie=web_session, current_ip=request.client.host
            )
            ensure_not_blacklisted(user)
            cur.execute(
                "INSERT INTO requests (user_id, content, summary, status, signature_format) "
                "VALUES (%s,%s,%s,'pending',%s) "
                "RETURNING id, content, summary, status, created_at, updated_at",
                (user["id"], content, summary, body.signature_format)
            )
            row = cur.fetchone()
            log_action(user["id"], "request_created", platform=(x_platform or "web"), ip_address=request.client.host, detail=f"request_id={row[0]}", cur=cur)
            conn.commit()
        request_data = _row_to_request(row)
        await manager.send_to_user(user["firebase_uid"], {
            "type": "new_request", "request": request_data
        })
        _send_fcm_notification(
            user_id=user["id"],
            title="New Signing Request",
            body="You have a new document awaiting your signature.",
            data={"request_id": str(row[0]), "type": "new_request"}
        )
        return {"status": "success", "request": request_data}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="Something went wrong. Please try again.")

@app.patch("/requests/{request_id}/status")
async def update_request_status(
    request_id:      int,
    request:         Request,
    body:            UpdateStatusBody,
    authorization:   Optional[str] = Header(default=None),
    x_session_token: Optional[str] = Header(default=None),
    x_platform:      Optional[str] = Header(default=None),
    web_session:     Optional[str] = Cookie(default=None),
):
    new_status = body.status.strip().lower()
    if new_status not in ("accepted", "rejected"):
        raise HTTPException(status_code=400, detail="Status must be 'accepted' or 'rejected'.")
    try:
        with get_cursor() as (conn, cur):
            user = require_auth_and_session(
                authorization, x_session_token, x_platform, conn, cur,
                web_session_cookie=web_session, current_ip=request.client.host
            )
            ensure_not_blacklisted(user)
            cur.execute(
                "SELECT id, status FROM requests WHERE id=%s AND user_id=%s",
                (request_id, user["id"])
            )
            row = cur.fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="Request not found.")
            if row[1] != "pending":
                raise HTTPException(
                    status_code=400,
                    detail=f"Request is already '{row[1]}' and cannot be changed."
                )
            cur.execute(
                "UPDATE requests SET status=%s, updated_at=CURRENT_TIMESTAMP "
                "WHERE id=%s "
                "RETURNING id, content, summary, status, created_at, updated_at",
                (new_status, request_id)
            )
            updated = cur.fetchone()
            log_action(user["id"], "request_status_updated", platform=(x_platform or "web"), ip_address=request.client.host, detail=f"request_id={request_id} status={new_status}", cur=cur)
            conn.commit()
        request_data = _row_to_request(updated)
        await manager.send_to_user(user["firebase_uid"], {
            "type": "status_update", "request": request_data
        })
        return {"status": "success", "message": f"Request {new_status}.", "request": request_data}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="Something went wrong. Please try again.")

@app.post("/report-compromised")
def report_compromised(
    request:         Request,
    response:        Response,
    authorization:   Optional[str] = Header(default=None),
    x_session_token: Optional[str] = Header(default=None),
    x_platform:      Optional[str] = Header(default=None),
    web_session:     Optional[str] = Cookie(default=None),
):
    """
    Blacklists the account AND terminates ALL sessions on ALL platforms.
    Also clears the web session cookie if called from web.
    """
    platform = (x_platform or "web").strip().lower()
    if platform == "web":
        response.delete_cookie(key="web_session", httponly=True, secure=True, samesite="strict")
    try:
        with get_cursor() as (conn, cur):
            user = require_auth_and_session(
                authorization, x_session_token, x_platform, conn, cur,
                web_session_cookie=web_session, current_ip=request.client.host
            )
            cur.execute(
                "UPDATE users SET is_blacklisted=TRUE, blacklisted_at=CURRENT_TIMESTAMP WHERE id=%s",
                (user["id"],)
            )
            delete_all_sessions(user["id"], cur)

            cur.execute(
                """
                UPDATE certificates
                SET status='revoked', revoked_at=CURRENT_TIMESTAMP
                WHERE user_id=%s AND status='active'
                RETURNING serial_number, source
                """,
                (user["id"],)
            )
            revoked_row = cur.fetchone()
            if revoked_row:
                revoked_serial, revoked_source = revoked_row
                if revoked_source == 'adcs':
                    _revoke_certificate_in_adcs(revoked_serial)

            cur.execute("DELETE FROM device_tokens WHERE user_id = %s", (user["id"],))
            cur.execute(
                "UPDATE users SET last_active_platform = NULL, last_active_at = NULL WHERE id = %s",
                (user["id"],)
            )
            log_action(user["id"], "account_blacklisted", platform=(x_platform or "web"), ip_address=request.client.host, cur=cur)
            conn.commit()
        return {"status": "success", "message": "Account blacklisted. Use your backup keys to recover access."}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="Something went wrong. Please try again.")

@app.post("/recover-account")
def recover_account(
    request:       Request,
    body:          RecoverAccountBody,
    authorization: Optional[str] = Header(default=None),
    x_platform:    Optional[str] = Header(default=None),
):
    """
    Recovery flow, does NOT require a session (the user is locked out):
      1. App signs in via Firebase (email + password or Google), proves credentials.
      2. App sends the resulting Firebase token + backup_key here.
      3. Backend verifies the token then checks the backup key in DB.
      4. If valid: consume the key, unblacklist the user.

    Sessions are NOT created here. The user must log in normally after recovery
    to obtain a new session token.
    """
    decoded      = verify_token(authorization)
    firebase_uid = decoded["uid"]
    try:
        with get_cursor() as (conn, cur):
            cur.execute(
                "SELECT id, is_blacklisted FROM users WHERE firebase_uid=%s",
                (firebase_uid,)
            )
            row = cur.fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="User not found.")
            user_id, is_blacklisted = row

            if not is_blacklisted:
                raise HTTPException(status_code=400, detail="This account is not blacklisted.")

            remaining = _remaining_key_count(user_id, cur)
            if remaining == 0:
                raise HTTPException(
                    status_code=403,
                    detail="All backup keys have been used. Please contact support for further assistance."
                )

            if not _consume_backup_key(user_id, body.backup_key, cur):
                raise HTTPException(status_code=401, detail="Invalid backup key.")

            cur.execute(
                "UPDATE users SET is_blacklisted=FALSE, blacklisted_at=NULL WHERE id=%s",
                (user_id,)
            )

            cur.execute(
                """
                UPDATE certificates
                SET status='revoked', revoked_at=CURRENT_TIMESTAMP
                WHERE user_id=%s AND status='active'
                RETURNING serial_number, source
                """,
                (user_id,)
            )
            recovered_cert = cur.fetchone()
            if recovered_cert:
                recovered_serial, recovered_source = recovered_cert
                if recovered_source == 'adcs':
                    _revoke_certificate_in_adcs(recovered_serial)

            log_action(user_id, "account_recovered", platform=(x_platform or "web"), ip_address=request.client.host, detail=f"{remaining - 1} backup keys remaining", cur=cur)
            conn.commit()
            remaining_after = remaining - 1

        msg = "Account recovered successfully."
        if remaining_after == 0:
            msg += " Warning: you have no backup keys left. Contact support if you need new ones."
        elif remaining_after <= 2:
            msg += f" You have {remaining_after} backup key(s) remaining, use them carefully."
        return {"status": "success", "message": msg}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="Something went wrong. Please try again.")

@app.post("/reset-password")
def reset_password(request: Request, body: ResetPasswordBody, x_platform: Optional[str] = Header(default=None)):
    """
    Forgot password flow, no session required:
      1. App sends email + backup_key + new_password (user forgot their password).
      2. Backend looks up user by email, verifies the backup key, consumes it,
         then uses Firebase Admin SDK to update the password.
    """
    new_password = body.new_password.strip()
    if len(new_password) < 6:
        raise HTTPException(status_code=400, detail="New password must be at least 6 characters.")
    try:
        firebase_user = auth.get_user_by_email(body.email)
    except Exception:
        raise HTTPException(status_code=404, detail="No account found with this email.")
    try:
        with get_cursor() as (conn, cur):
            cur.execute("SELECT id FROM users WHERE firebase_uid=%s", (firebase_user.uid,))
            row = cur.fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="User not found.")
            user_id = row[0]

            remaining = _remaining_key_count(user_id, cur)
            if remaining == 0:
                raise HTTPException(
                    status_code=403,
                    detail="All backup keys have been used. Please contact support for further assistance."
                )

            if not _consume_backup_key(user_id, body.backup_key, cur):
                raise HTTPException(status_code=401, detail="Invalid backup key.")

            auth.update_user(firebase_user.uid, password=new_password)
            log_action(user_id, "password_reset", platform=(x_platform or "web"), ip_address=request.client.host, detail=f"{remaining - 1} backup keys remaining", cur=cur)
            conn.commit()
            remaining_after = remaining - 1

        msg = "Password reset successfully."
        if remaining_after == 0:
            msg += " Warning: you have no backup keys left. Contact support if you need new ones."
        elif remaining_after <= 2:
            msg += f" You have {remaining_after} backup key(s) remaining."
        return {"status": "success", "message": msg}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="Something went wrong. Please try again.")


@app.post("/request-certificate")
async def request_certificate(
    request:         Request,
    body:            RequestCertificateBody,
    authorization:   Optional[str] = Header(default=None),
    x_session_token: Optional[str] = Header(default=None),
    x_platform:      Optional[str] = Header(default=None),
    web_session:     Optional[str] = Cookie(default=None),
):
    """
    Receives a CSR from iOS (generated in Secure Enclave), forwards it to AD CS,
    stores the issued certificate in the DB, and returns it to the iOS app.
    Called once on first login after backup codes are confirmed.
    """
    try:
        with get_cursor() as (conn, cur):
            user = require_auth_and_session(
                authorization, x_session_token, x_platform, conn, cur,
                web_session_cookie=web_session, current_ip=request.client.host
            )
            ensure_not_blacklisted(user)

            cur.execute(
                "SELECT id, certificate, serial_number FROM certificates WHERE user_id=%s AND status='active' ORDER BY issued_at DESC LIMIT 1 FOR UPDATE",
                (user["id"],)
            )
            existing = cur.fetchone()
            if existing:
                if not body.force:
                    conn.commit()
                    return {"status": "existing", "certificate": existing[1]}
                else:
                    cur.execute(
                        """
                        UPDATE certificates
                        SET status='revoked', revoked_at=CURRENT_TIMESTAMP
                        WHERE id=%s
                        """,
                        (existing[0],)
                    )
                    _revoke_certificate_in_adcs(existing[2])
                    log_action(user["id"], "certificate_revoked_on_reissue",
                              platform=(x_platform or "mobile"),
                              ip_address=request.client.host,
                              detail=f"serial={existing[2]} revoked before reissue",
                              cur=cur)
                    conn.commit()

            cert_pem = _request_certificate_from_adcs(
                csr_pem=body.csr_pem,
                user_email=user["email"] or "",
                user_cn=user["username"]
            )

            serial, expires_at = _get_cert_serial_and_expiry(cert_pem)

            cur.execute(
                "SELECT id FROM certificates WHERE serial_number=%s AND user_id=%s",
                (serial, user["id"])
            )
            if cur.fetchone():
                raise HTTPException(
                    status_code=502,
                    detail="AD CS returned a previously issued certificate. Please try again."
                )

            cur.execute(
                """
                INSERT INTO certificates (user_id, certificate, serial_number, status, expires_at)
                VALUES (%s, %s, %s, 'active', %s)
                RETURNING id
                """,
                (user["id"], cert_pem, serial, expires_at)
            )
            cert_id = cur.fetchone()[0]
            log_action(user["id"], "certificate_issued", platform=(x_platform or "mobile"),
                      ip_address=request.client.host, detail=f"serial={serial} cert_id={cert_id}", cur=cur)
            conn.commit()

        return {"status": "success", "certificate": cert_pem}

    except HTTPException:
        raise
    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        print(f"[/request-certificate] ERROR: {e}\nTraceback:\n{tb}")
        raise HTTPException(status_code=500, detail="Something went wrong. Please try again.")


@app.get("/certificate")
def get_certificate(
    request:         Request,
    authorization:   Optional[str] = Header(default=None),
    x_session_token: Optional[str] = Header(default=None),
    x_platform:      Optional[str] = Header(default=None),
    web_session:     Optional[str] = Cookie(default=None),
):
    """
    Returns the active certificate for the authenticated user.
    iOS calls this on every app launch to ensure it has the latest certificate.
    """
    try:
        with get_cursor() as (conn, cur):
            user = require_auth_and_session(
                authorization, x_session_token, x_platform, conn, cur,
                web_session_cookie=web_session, current_ip=request.client.host
            )
            cur.execute(
                "SELECT certificate, serial_number, issued_at, expires_at FROM certificates "
                "WHERE user_id=%s AND status='active' ORDER BY issued_at DESC LIMIT 1",
                (user["id"],)
            )
            row = cur.fetchone()
            conn.commit()

        if not row:
            return {"status": "none", "certificate": None}

        return {
            "status":        "success",
            "certificate":   row[0],
            "serial_number": row[1],
            "issued_at":     row[2].isoformat() if row[2] else None,
            "expires_at":    row[3].isoformat() if row[3] else None,
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="Something went wrong. Please try again.")


@app.get("/certificate/is-revoked")
def is_certificate_revoked(
    serial:          str,
    authorization:   Optional[str] = Header(default=None),
    x_session_token: Optional[str] = Header(default=None),
    x_platform:      Optional[str] = Header(default=None),
    web_session:     Optional[str] = Cookie(default=None),
    request:         Request = None,
):
    """
    Checks if a specific certificate serial number is revoked in the DB.
    Used by iOS to check if the physical cert on the device is revoked,
    regardless of which user is currently logged in.
    Returns { revoked: true/false }
    """
    try:
        with get_cursor() as (conn, cur):
            require_auth_and_session(
                authorization, x_session_token, x_platform, conn, cur,
                web_session_cookie=web_session,
                current_ip=request.client.host if request and request.client else None
            )
            cur.execute(
                "SELECT status FROM certificates WHERE serial_number=%s",
                (serial.upper(),)
            )
            row = cur.fetchone()
            conn.commit()

        if not row:
            return {"revoked": True}
        return {"revoked": row[0] != "active"}

    except HTTPException:
        raise
    except Exception:
        return {"revoked": False}


@app.get("/validate-certificate")
def validate_certificate(
    request:         Request,
    authorization:   Optional[str] = Header(default=None),
    x_session_token: Optional[str] = Header(default=None),
    x_platform:      Optional[str] = Header(default=None),
    web_session:     Optional[str] = Cookie(default=None),
):
    """
    Validates the active certificate for the authenticated user.
    Checks: exists in DB, status=active, not expired, not in CRL.
    Called by iOS on every app launch before any signing operation.
    Returns { valid: true/false, reason: "..." }
    """
    from datetime import timezone, datetime
    try:
        with get_cursor() as (conn, cur):
            user = require_auth_and_session(
                authorization, x_session_token, x_platform, conn, cur,
                web_session_cookie=web_session, current_ip=request.client.host
            )

            cur.execute(
                """
                SELECT serial_number, expires_at, status
                FROM certificates
                WHERE user_id=%s AND status='active'
                ORDER BY issued_at DESC LIMIT 1
                """,
                (user["id"],)
            )
            row = cur.fetchone()
            conn.commit()

        if not row:
            return {"valid": False, "reason": "no_certificate"}

        serial, expires_at, status = row

        if expires_at:
            now = datetime.now(timezone.utc)
            if expires_at.tzinfo is None:
                from datetime import timezone as tz
                expires_at = expires_at.replace(tzinfo=tz.utc)
            if now > expires_at:
                return {"valid": False, "reason": "expired"}

        try:
            crl = _download_crl()
            for revoked in crl:
                if format(revoked.serial_number, "x").upper() == serial.upper():
                    return {"valid": False, "reason": "revoked"}
        except Exception as e:
            print(f"[validate-certificate] CRL check failed: {e}")

        return {
            "valid":         True,
            "serial_number": serial,
            "expires_at":    expires_at.isoformat() if expires_at else None
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="Something went wrong. Please try again.")


@app.post("/revoke-my-certificate")
def revoke_my_certificate(
    request:         Request,
    authorization:   Optional[str] = Header(default=None),
    x_session_token: Optional[str] = Header(default=None),
    x_platform:      Optional[str] = Header(default=None),
    web_session:     Optional[str] = Cookie(default=None),
):
    """
    Revokes the user's own active certificate.
    Called when user taps 'Reset Signing Certificate' in Profile.
    Revokes in DB + calls AD CS revocation API.
    iOS then deletes local key+cert and generates fresh on next login.
    """
    try:
        with get_cursor() as (conn, cur):
            user = require_auth_and_session(
                authorization, x_session_token, x_platform, conn, cur,
                web_session_cookie=web_session, current_ip=request.client.host
            )
            ensure_not_blacklisted(user)

            cur.execute(
                """
                UPDATE certificates
                SET status='revoked', revoked_at=CURRENT_TIMESTAMP
                WHERE user_id=%s AND status='active'
                RETURNING serial_number, source
                """,
                (user["id"],)
            )
            row = cur.fetchone()
            if not row:
                conn.commit()
                return {"status": "success", "message": "No active certificate to revoke."}

            serial, cert_source = row
            log_action(user["id"], "certificate_reset_by_user",
                      platform=(x_platform or "mobile"),
                      ip_address=request.client.host,
                      detail=f"serial={serial} source={cert_source} revoked by user via profile reset",
                      cur=cur)
            cur.execute("DELETE FROM device_tokens WHERE user_id = %s", (user["id"],))
            cur.execute(
                "UPDATE users SET last_active_platform = NULL, last_active_at = NULL WHERE id = %s",
                (user["id"],)
            )
            conn.commit()

        if cert_source == 'adcs':
            _revoke_certificate_in_adcs(serial)

        return {"status": "success", "message": "Certificate revoked. A new one will be issued on next login."}

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="Something went wrong. Please try again.")


@app.post("/import-certificate")
async def import_certificate(
    request:         Request,
    body:            ImportCertificateBody,
    authorization:   Optional[str] = Header(default=None),
    x_session_token: Optional[str] = Header(default=None),
    x_platform:      Optional[str] = Header(default=None),
    web_session:     Optional[str] = Cookie(default=None),
):
    """
    Register an externally imported certificate (from a PFX file) for this user.

    The iOS app extracts the certificate from the PFX, stores the private key
    in the Keychain (NOT the Secure Enclave), and sends only the PEM certificate
    here for registration. The private key never leaves the device.

    Checks performed:
    1. Not self-signed
    2. Has OCSP/CRL revocation infrastructure (AIA + CDP extensions)
    3. Validity period
    4. CN in certificate subject matches logged-in user's email
    5. Not a duplicate active registration
    Then: revokes existing active cert (DB only for imported, DB+ADCS for adcs)
          and inserts new cert with source='imported'.
    """
    try:
        with get_cursor() as (conn, cur):
            user = require_auth_and_session(
                authorization, x_session_token, x_platform, conn, cur,
                web_session_cookie=web_session, current_ip=request.client.host
            )
            ensure_not_blacklisted(user)

            try:
                cert = x509.load_pem_x509_certificate(body.cert_pem.encode())
            except Exception as e:
                raise HTTPException(status_code=400, detail="Invalid certificate format.")

            if cert.issuer == cert.subject:
                raise HTTPException(
                    status_code=400,
                    detail="Self-signed certificates are not accepted. Please use a certificate issued by a recognized online CA."
                )

            has_ocsp = False
            has_crl  = False
            try:
                aia = cert.extensions.get_extension_for_oid(ExtensionOID.AUTHORITY_INFORMATION_ACCESS)
                has_ocsp = any(
                    d.access_method == AuthorityInformationAccessOID.OCSP
                    for d in aia.value
                )
            except x509.ExtensionNotFound:
                pass
            try:
                cert.extensions.get_extension_for_oid(ExtensionOID.CRL_DISTRIBUTION_POINTS)
                has_crl = True
            except x509.ExtensionNotFound:
                pass

            if not has_ocsp and not has_crl:
                raise HTTPException(
                    status_code=400,
                    detail="Certificate has no revocation information (no AIA OCSP or CDP CRL). Must be from a recognized online CA."
                )

            from datetime import timezone, datetime as dt
            now = dt.now(timezone.utc)
            if now < cert.not_valid_before_utc:
                raise HTTPException(status_code=400, detail="Certificate is not yet valid.")
            if now > cert.not_valid_after_utc:
                raise HTTPException(status_code=400, detail="Certificate has expired.")

            try:
                cn = cert.subject.get_attributes_for_oid(x509.NameOID.COMMON_NAME)[0].value.strip().lower()
            except (IndexError, Exception):
                raise HTTPException(
                    status_code=400,
                    detail="Certificate has no Common Name (CN) in subject."
                )

            user_email = (user.get("email") or "").strip().lower()
            if not user_email:
                raise HTTPException(
                    status_code=400,
                    detail="Your account has no email address to verify against."
                )
            if cn != user_email:
                raise HTTPException(
                    status_code=400,
                    detail=f"Certificate identity ({cn}) does not match your account email ({user_email}). You can only import a certificate issued to your own email address."
                )

            serial, expires_at = _get_cert_serial_and_expiry(body.cert_pem)

            cur.execute(
                "SELECT id FROM certificates WHERE serial_number=%s AND user_id=%s AND status='active'",
                (serial, user["id"])
            )
            if cur.fetchone():
                raise HTTPException(
                    status_code=400,
                    detail="This certificate is already registered and active on your account."
                )

            cur.execute(
                """
                UPDATE certificates
                SET status='revoked', revoked_at=CURRENT_TIMESTAMP
                WHERE user_id=%s AND status='active'
                RETURNING serial_number, source
                """,
                (user["id"],)
            )
            existing = cur.fetchone()
            if existing:
                existing_serial, existing_source = existing
                log_action(user["id"], "certificate_revoked_on_import",
                          platform=(x_platform or "mobile"),
                          ip_address=request.client.host,
                          detail=f"serial={existing_serial} source={existing_source} revoked before import",
                          cur=cur)
                if existing_source == 'adcs':
                    _revoke_certificate_in_adcs(existing_serial)

            cur.execute(
                """
                INSERT INTO certificates (user_id, certificate, serial_number, status, expires_at, source)
                VALUES (%s, %s, %s, 'active', %s, 'imported')
                RETURNING id
                """,
                (user["id"], body.cert_pem, serial, expires_at)
            )
            cert_id = cur.fetchone()[0]
            log_action(user["id"], "certificate_imported",
                      platform=(x_platform or "mobile"),
                      ip_address=request.client.host,
                      detail=f"serial={serial} cert_id={cert_id} cn={cn} source=imported",
                      cur=cur)
            conn.commit()

        return {"status": "success", "serial_number": serial, "expires_at": expires_at}

    except HTTPException:
        raise
    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        print(f"[/import-certificate] ERROR: {e}\nTraceback:\n{tb}")
        raise HTTPException(status_code=500, detail="Something went wrong. Please try again.")


@app.post("/submit-signature")
async def submit_signature(
    request:         Request,
    body:            SubmitSignatureBody,
    authorization:   Optional[str] = Header(default=None),
    x_session_token: Optional[str] = Header(default=None),
    x_platform:      Optional[str] = Header(default=None),
    web_session:     Optional[str] = Cookie(default=None),
):
    """
    Receives a PKCS#7 signed document from iOS.
    Verification steps:
    1. Verify PKCS#7 structure and certificate chain (issued by Fyp54-CA)
    2. Check certificate is not revoked in our DB
    3. Check certificate via OCSP (real-time revocation)
    4. Store signature in DB
    5. Update request status to accepted
    6. Notify web via WebSocket
    """
    try:
        with get_cursor() as (conn, cur):
            user = require_auth_and_session(
                authorization, x_session_token, x_platform, conn, cur,
                web_session_cookie=web_session, current_ip=request.client.host
            )
            ensure_not_blacklisted(user)

            cur.execute(
                "SELECT id, content, status FROM requests WHERE id=%s AND user_id=%s",
                (body.request_id, user["id"])
            )
            req_row = cur.fetchone()
            if not req_row:
                raise HTTPException(status_code=404, detail="Request not found.")
            if req_row[2] != "pending":
                raise HTTPException(status_code=400, detail=f"Request is already '{req_row[2]}'.")

            sig_format = body.signature_format.lower() if body.signature_format else "pkcs7"

            if sig_format == "pkcs7":
                try:
                    pkcs7_der_peek = base64.b64decode(body.pkcs7_b64)
                    pkcs7_certs_peek = pkcs7.load_der_pkcs7_certificates(pkcs7_der_peek)
                    peek_serial = format(pkcs7_certs_peek[0].serial_number, "x").upper() if pkcs7_certs_peek else None
                except Exception:
                    peek_serial = None

                cert_source = 'adcs'
                if peek_serial:
                    cur.execute(
                        "SELECT source FROM certificates WHERE serial_number=%s AND user_id=%s AND status='active'",
                        (peek_serial, user["id"])
                    )
                    source_row = cur.fetchone()
                    if source_row:
                        cert_source = source_row[0]

                cur.execute(
                    "SELECT content FROM requests WHERE id=%s",
                    (body.request_id,)
                )
                req_content_row = cur.fetchone()
                if not req_content_row:
                    raise HTTPException(status_code=404, detail="Request not found.")
                server_content_hash = hashlib.sha256(req_content_row[0].encode("utf-8")).hexdigest()

                if cert_source == 'adcs':
                    is_valid, signer_serial, error_msg = _verify_pkcs7_signature(
                        body.pkcs7_b64, server_content_hash
                    )
                else:
                    is_valid, signer_serial, error_msg = _verify_external_pkcs7_signature(
                        body.pkcs7_b64, server_content_hash
                    )

                if not is_valid:
                    cur.execute(
                        """
                        INSERT INTO signatures (request_id, user_id, certificate_id, pkcs7, content_hash, verified, signed_at, signature_format, error_reason)
                        VALUES (%s, %s, %s, %s, %s, FALSE, CURRENT_TIMESTAMP, %s, %s)
                        """,
                        (body.request_id, user["id"], None, body.pkcs7_b64, body.content_hash, sig_format, error_msg)
                    )
                    cur.execute(
                        "UPDATE requests SET status='rejected', updated_at=CURRENT_TIMESTAMP WHERE id=%s "
                        "RETURNING id, content, summary, status, created_at, updated_at",
                        (body.request_id,)
                    )
                    updated = cur.fetchone()
                    log_action(user["id"], "signature_verification_failed", platform=(x_platform or "mobile"),
                              ip_address=request.client.host,
                              detail=f"request_id={body.request_id} serial={signer_serial} reason={error_msg}", cur=cur)
                    conn.commit()
                    request_data = _row_to_request(updated)
                    await manager.send_to_user(user["firebase_uid"], {
                        "type": "status_update", "request": request_data
                    })
                    return {"status": "rejected", "message": f"Signature verification failed: {error_msg}"}

                cur.execute(
                    "SELECT id, certificate, status, source FROM certificates WHERE serial_number=%s AND user_id=%s",
                    (signer_serial, user["id"])
                )
                cert_row = cur.fetchone()
                if not cert_row:
                    raise HTTPException(status_code=400, detail="Signing certificate not found in our system.")
                if cert_row[2] != "active":
                    raise HTTPException(status_code=400, detail="Signing certificate has been revoked.")

                cert_id  = cert_row[0]
                cert_pem = cert_row[1]

                if cert_row[3] == 'adcs':
                    try:
                        crl = _download_crl()
                        for revoked in crl:
                            if format(revoked.serial_number, "x").upper() == signer_serial.upper():
                                raise HTTPException(status_code=400, detail="Certificate has been revoked (CRL).")
                    except HTTPException:
                        raise
                    except Exception as e:
                        print(f"[submit-signature] CRL check failed (non-fatal): {e}")

            elif sig_format == "raw":
                cur.execute(
                    "SELECT id, certificate, status, serial_number FROM certificates WHERE user_id=%s AND status='active' ORDER BY issued_at DESC LIMIT 1",
                    (user["id"],)
                )
                cert_row = cur.fetchone()
                if not cert_row:
                    raise HTTPException(status_code=400, detail="No active signing certificate found.")

                cert_id      = cert_row[0]
                cert_pem     = cert_row[1]
                signer_serial = cert_row[3]

                try:
                    from datetime import timezone, datetime
                    cert_obj   = x509.load_pem_x509_certificate(cert_pem.encode())
                    public_key = cert_obj.public_key()

                    now = datetime.now(timezone.utc)
                    if now < cert_obj.not_valid_before_utc or now > cert_obj.not_valid_after_utc:
                        raise HTTPException(status_code=400, detail="Certificate is expired or not yet valid.")

                    sig_bytes     = base64.b64decode(body.pkcs7_b64)
                    content_bytes = req_row[1].encode("utf-8")

                    public_key.verify(sig_bytes, content_bytes, ECDSA(hashes.SHA256()))

                    computed_hash = hashlib.sha256(content_bytes).hexdigest()
                    if computed_hash != body.content_hash:
                        raise HTTPException(status_code=400, detail="Content hash mismatch.")

                except HTTPException:
                    raise
                except Exception as e:
                    raise HTTPException(status_code=400, detail="Something went wrong. Please try again.")

                try:
                    crl = _download_crl()
                    for revoked in crl:
                        if format(revoked.serial_number, "x").upper() == signer_serial.upper():
                            raise HTTPException(status_code=400, detail="Certificate has been revoked (CRL).")
                except HTTPException:
                    raise
                except Exception as e:
                    print(f"[submit-signature raw] CRL check failed (non-fatal): {e}")
            else:
                raise HTTPException(status_code=400, detail=f"Unknown signature format: {sig_format}")

            cur.execute(
                """
                INSERT INTO signatures (request_id, user_id, certificate_id, pkcs7, content_hash, verified, signed_at, signature_format, error_reason)
                VALUES (%s, %s, %s, %s, %s, TRUE, CURRENT_TIMESTAMP, %s, NULL)
                RETURNING id
                """,
                (body.request_id, user["id"], cert_id, body.pkcs7_b64, body.content_hash, sig_format)
            )
            sig_id = cur.fetchone()[0]

            cur.execute(
                "UPDATE requests SET status='accepted', updated_at=CURRENT_TIMESTAMP WHERE id=%s "
                "RETURNING id, content, summary, status, created_at, updated_at",
                (body.request_id,)
            )
            updated = cur.fetchone()

            log_action(user["id"], "request_signed", platform=(x_platform or "mobile"),
                      ip_address=request.client.host,
                      detail=f"request_id={body.request_id} sig_id={sig_id} serial={signer_serial} format={sig_format}", cur=cur)
            conn.commit()

        request_data = _row_to_request(updated)
        await manager.send_to_user(user["firebase_uid"], {
            "type": "status_update", "request": request_data
        })

        return {"status": "success", "message": "Signature verified and stored.", "signature_id": sig_id}

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="Something went wrong. Please try again.")


@app.get("/signature/{request_id}")
def get_signature(
    request_id:      int,
    request:         Request,
    authorization:   Optional[str] = Header(default=None),
    x_session_token: Optional[str] = Header(default=None),
    x_platform:      Optional[str] = Header(default=None),
    web_session:     Optional[str] = Cookie(default=None),
):
    """
    Returns the PKCS#7 signature for a specific request.
    Used by the web frontend to display signature details and download the .p7m file.
    """
    try:
        with get_cursor() as (conn, cur):
            user = require_auth_and_session(
                authorization, x_session_token, x_platform, conn, cur,
                web_session_cookie=web_session, current_ip=request.client.host
            )
            cur.execute(
                """
                SELECT s.pkcs7, s.content_hash, s.verified, s.signed_at,
                       c.certificate, c.serial_number, c.expires_at,
                       s.signature_format
                FROM signatures s
                JOIN certificates c ON s.certificate_id = c.id
                WHERE s.request_id=%s AND s.user_id=%s
                ORDER BY s.signed_at DESC LIMIT 1
                """,
                (request_id, user["id"])
            )
            row = cur.fetchone()
            conn.commit()

        if not row:
            return {"status": "none"}

        return {
            "status":           "success",
            "pkcs7_b64":        row[0],
            "content_hash":     row[1],
            "verified":         row[2],
            "signed_at":        row[3].isoformat() if row[3] else None,
            "certificate":      row[4],
            "serial_number":    row[5],
            "expires_at":       row[6].isoformat() if row[6] else None,
            "signature_format": row[7] if row[7] else "pkcs7",
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="Something went wrong. Please try again.")




def _send_fcm_notification(user_id: int, title: str, body: str, data: dict = None):
    """
    Send an FCM push notification to all registered Android devices for this user.
    Only fires if the user last logged in on Android.
    iOS users are never touched, they never register a token and last_active_platform != 'android'.
    Completely non-fatal: never raises, never blocks the calling endpoint.
    """
    try:
        with get_cursor() as (conn, cur):
            cur.execute(
                "SELECT last_active_platform FROM users WHERE id = %s",
                (user_id,)
            )
            row = cur.fetchone()
            if not row or row[0] != 'android':
                return

            cur.execute(
                "SELECT fcm_token FROM device_tokens WHERE user_id = %s AND platform = 'android'",
                (user_id,)
            )
            tokens = [r[0] for r in cur.fetchall()]

        if not tokens:
            return

        for token in tokens:
            try:
                message = fcm_messaging.Message(
                    notification=fcm_messaging.Notification(title=title, body=body),
                    data={k: str(v) for k, v in (data or {}).items()},
                    android=fcm_messaging.AndroidConfig(
                        priority='high',
                        notification=fcm_messaging.AndroidNotification(sound='default'),
                    ),
                    token=token,
                )
                fcm_messaging.send(message)
                print(f"[FCM] Sent to user_id={user_id} token={token[:20]}...")
            except fcm_messaging.UnregisteredError:
                with get_cursor() as (conn2, cur2):
                    cur2.execute("DELETE FROM device_tokens WHERE fcm_token = %s", (token,))
                    conn2.commit()
                print(f"[FCM] Stale token removed for user_id={user_id}")
            except Exception as e:
                print(f"[FCM] Send failed (non-fatal): {e}")

    except Exception as e:
        print(f"[FCM] _send_fcm_notification error (non-fatal): {e}")



class RegisterDeviceTokenBody(BaseModel):
    fcm_token: str
    platform:  str = "android"

@app.post("/register-device-token")
def register_device_token(
    request:         Request,
    body:            RegisterDeviceTokenBody,
    authorization:   Optional[str] = Header(default=None),
    x_session_token: Optional[str] = Header(default=None),
    x_platform:      Optional[str] = Header(default=None),
):
    """
    Android calls this after login to register its FCM token.
    iOS never calls this. Safe to call on every login (upserts).
    """
    if body.platform.lower() != 'android':
        raise HTTPException(status_code=400, detail="Only Android devices register FCM tokens.")
    try:
        with get_cursor() as (conn, cur):
            user = require_auth_and_session(
                authorization, x_session_token, x_platform, conn, cur,
                web_session_cookie=None, current_ip=request.client.host
            )
            cur.execute(
                """
                INSERT INTO device_tokens (user_id, fcm_token, platform, updated_at)
                VALUES (%s, %s, 'android', CURRENT_TIMESTAMP)
                ON CONFLICT (user_id, fcm_token) DO UPDATE SET updated_at = CURRENT_TIMESTAMP
                """,
                (user["id"], body.fcm_token)
            )
            cur.execute(
                "UPDATE users SET last_active_platform = 'android', last_active_at = CURRENT_TIMESTAMP WHERE id = %s",
                (user["id"],)
            )
            conn.commit()
        return {"status": "success", "message": "Device token registered."}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="Something went wrong. Please try again.")


@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    await ws.send_json({"type": "auth_required"})

    firebase_uid = None
    try:
        raw = await asyncio.wait_for(ws.receive_text(), timeout=10.0)
        msg = json.loads(raw)

        if msg.get("type") != "auth" or not msg.get("token"):
            await ws.send_json({"type": "auth_error", "message": "Expected auth message with token."})
            await ws.close(code=4001)
            return

        try:
            decoded      = auth.verify_id_token(msg["token"], clock_skew_seconds=10)
            firebase_uid = decoded["uid"]
        except Exception as e:
            await ws.send_json({"type": "auth_error", "message": f"Invalid token: {e}"})
            await ws.close(code=4001)
            return

        platform          = msg.get("platform", "web").strip().lower()
        raw_session_token = msg.get("session_token", "").strip()

        if platform == "mobile":
            if not raw_session_token:
                await ws.send_json({"type": "auth_error", "message": "Missing session token."})
                await ws.close(code=4001)
                return

            session_valid = False
            try:
                with get_cursor() as (conn, cur):
                    cur.execute(
                        "SELECT id FROM users WHERE firebase_uid = %s",
                        (firebase_uid,)
                    )
                    user_row = cur.fetchone()
                    if user_row:
                        session_valid = validate_session_token_ws(user_row[0], raw_session_token, cur)
                        if session_valid:
                            conn.commit()
            except Exception:
                session_valid = False

            if not session_valid:
                await ws.send_json({"type": "auth_error", "message": "Invalid or expired session."})
                await ws.close(code=4001)
                return

        manager.active.setdefault(firebase_uid, set()).add(ws)
        await ws.send_json({"type": "auth_ok"})

        while True:
            try:
                raw = await asyncio.wait_for(ws.receive_text(), timeout=60.0)
                msg = json.loads(raw)
                if msg.get("type") == "ping":
                    await ws.send_json({"type": "pong"})
            except asyncio.TimeoutError:
                await ws.send_json({"type": "ping"})

    except WebSocketDisconnect:
        pass
    except Exception as e:
        print(f"[WS] Error for {firebase_uid}: {e}")
    finally:
        if firebase_uid:
            manager.disconnect(firebase_uid, ws)