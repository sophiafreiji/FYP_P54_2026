import SwiftUI

struct ImportedKeyBanner: View {
    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundColor(.white)
                .font(.subheadline)
            Text("Imported credentials active, private key not in Secure Enclave")
                .font(.caption)
                .fontWeight(.semibold)
                .foregroundColor(.white)
            Spacer()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(Color.orange)
    }
}

struct MainAppView: View {
    @EnvironmentObject var authVM: AuthViewModel
    @StateObject private var requestsVM = RequestsViewModel()
    @StateObject private var profileVM  = ProfileViewModel()
    @State private var showLostPhoneAlert = false
    @State private var showLogoutAlert    = false

    var body: some View {
        VStack(spacing: 0) {
            if authVM.keySource == .imported && authVM.canSign {
                ImportedKeyBanner()
            }

            TabView {
                RequestsTabView()
                    .environmentObject(requestsVM)
                    .environmentObject(authVM)
                    .tabItem { Label("Pending", systemImage: "clock.badge") }

                HistoryTabView()
                    .environmentObject(requestsVM)
                    .tabItem { Label("History", systemImage: "list.bullet.clipboard") }

                ProfileTabView(showLostPhoneAlert: $showLostPhoneAlert, showLogoutAlert: $showLogoutAlert)
                    .environmentObject(profileVM)
                    .environmentObject(authVM)
                    .tabItem { Label("Profile", systemImage: "person.circle") }
            }
            .tint(.blue)
        }
        .onAppear {
            requestsVM.startLive()
            Task {
                await profileVM.fetchProfile()
                await requestsVM.fetchRequests()
            }
        }
        .onDisappear { requestsVM.stopLive() }
        .alert("Report Compromised Device", isPresented: $showLostPhoneAlert) {
            Button("Cancel", role: .cancel) {}
            Button("Report Compromised", role: .destructive) {
                Task {
                    if await authVM.reportCompromised() { await authVM.signOut() }
                }
            }
        } message: {
            if authVM.canSign {
                Text("This will blacklist your account because your device is compromised. Use your backup keys to recover access.")
            } else {
                Text("You cannot report this device as compromised because your signing certificate is not installed here. Please use your own registered device.")
            }
        }
        .alert("Logout", isPresented: $showLogoutAlert) {
            Button("Cancel", role: .cancel) {}
            Button("Logout", role: .destructive) { Task { await authVM.signOut() } }
        } message: {
            Text("Are you sure you want to logout?")
        }
    }
}
