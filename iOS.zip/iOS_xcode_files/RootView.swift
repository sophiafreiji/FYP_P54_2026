import SwiftUI
import FirebaseAuth
import UIKit

struct RootView: View {
    @StateObject private var authVM = AuthViewModel()
    @State private var serverAvailable = false
    @State private var checkingServer  = true
    @State private var isSettingUp     = false

    var body: some View {
        Group {
            if checkingServer || authVM.isLoading {
                SplashView(serverUnavailable: false)
            } else if !serverAvailable {
                SplashView(serverUnavailable: true, onRetry: { checkServer(isRetry: true) })
            } else if authVM.isConfirmedLoggedIn {
                if isSettingUp {
                    SplashView(serverUnavailable: false)
                } else {
                    MainAppView().environmentObject(authVM)
                        .id(authVM.currentUser?.uid ?? "unknown")
                }
            } else {
                AuthView().environmentObject(authVM)
            }
        }
        .animation(.easeInOut(duration: 0.3), value: authVM.isConfirmedLoggedIn)
        .animation(.easeInOut(duration: 0.3), value: serverAvailable)
        .animation(.easeInOut(duration: 0.3), value: isSettingUp)
        .onChange(of: authVM.isConfirmedLoggedIn) { _, confirmed in
            if confirmed {
                isSettingUp = true
                Task {
                    await authVM.ensureCertificateOnLaunch()
                    isSettingUp = false
                }
            }
        }
        .onAppear { checkServer() }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.didEnterBackgroundNotification)) { _ in
            Task { await authVM.signOut() }
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.willEnterForegroundNotification)) { _ in
            checkServer(isRetry: true)
        }
        .onReceive(NotificationCenter.default.publisher(for: .serverUnavailable)) { _ in
            authVM.forceLogout()
            serverAvailable = false
            checkingServer  = false
        }
        .onReceive(NotificationCenter.default.publisher(for: .sessionInvalidated)) { _ in
            authVM.forceLogout()
        }
        .onReceive(NotificationCenter.default.publisher(for: .sessionExpired)) { _ in
            authVM.sessionExpiredLogout()
        }
    }

    private func checkServer(isRetry: Bool = false) {
        if !isRetry { checkingServer = true }
        Task {
            do {
                try await APIService.shared.checkConnectivity()
                serverAvailable = true
            } catch {
                serverAvailable = false
            }
            checkingServer = false
        }
    }
}
