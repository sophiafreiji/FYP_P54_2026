import Foundation
import FirebaseAuth

private enum WSType {
    static let authRequired = "auth_required"
    static let auth         = "auth"
    static let authOk       = "auth_ok"
    static let authError    = "auth_error"
    static let newRequest   = "new_request"
    static let statusUpdate = "status_update"
    static let ping         = "ping"
    static let pong         = "pong"
    static let sessionInvalid = "session_invalid"
}

private struct WSMessage: Decodable {
    let type:    String
    let message: String?
    let request: SigningRequest?
}

@MainActor
class WebSocketService: NSObject {
    static let shared = WebSocketService()

    var onNewRequest:   ((SigningRequest) -> Void)?
    var onStatusUpdate: ((SigningRequest) -> Void)?
    var onConnected:    (() -> Void)?
    var onDisconnected: (() -> Void)?

    private var task:           URLSessionWebSocketTask?
    private var session:        URLSession?
    private var shouldReconnect = false
    private var reconnectDelay: TimeInterval = 2
    private var reconnectWork:  Task<Void, Never>?
    private var connected       = false

    private override init() { super.init() }

    func connect() {
        guard !connected else { return }
        shouldReconnect = true

        let wsURL = APIService.shared.baseURL
            .replacingOccurrences(of: "https://", with: "wss://")
            .replacingOccurrences(of: "http://",  with: "ws://")

        guard let url = URL(string: wsURL + "/ws") else { return }

        session = URLSession(configuration: .default, delegate: SelfSignedCertDelegate(), delegateQueue: nil)
        task    = session?.webSocketTask(with: url)
        task?.resume()
        connected      = true
        reconnectDelay = 2
        listen()
    }

    func disconnect() {
        shouldReconnect = false
        reconnectWork?.cancel()
        reconnectWork = nil
        task?.cancel(with: .goingAway, reason: nil)
        task      = nil
        connected = false
        onDisconnected?()
    }

    private func send(_ payload: [String: String]) {
        guard let data = try? JSONSerialization.data(withJSONObject: payload),
              let text = String(data: data, encoding: .utf8) else { return }
        task?.send(.string(text)) { _ in }
    }

    private func listen() {
        task?.receive { [weak self] result in
            Task { @MainActor [weak self] in
                guard let self else { return }
                switch result {
                case .failure:
                    self.handleDisconnect()
                case .success(let msg):
                    if case .string(let text) = msg { self.handle(text) }
                    self.listen()
                }
            }
        }
    }

    private func handle(_ text: String) {
        guard let data = text.data(using: .utf8),
              let msg  = try? JSONDecoder().decode(WSMessage.self, from: data) else { return }

        switch msg.type {
        case WSType.authRequired:
            Task {
                guard let user = Auth.auth().currentUser,
                      let token = try? await user.getIDToken(),
                      let sessionToken = APIService.shared.sessionToken else {
                    disconnect()
                    return
                }
                send([
                    "type":          WSType.auth,
                    "token":         token,
                    "session_token": sessionToken,
                    "platform":      "mobile"
                ])
            }
        case WSType.authOk:
            onConnected?()
        case WSType.authError:
            disconnect()
        case WSType.sessionInvalid:
            shouldReconnect = false
            disconnect()
            NotificationCenter.default.post(name: .sessionInvalidated, object: nil)
        case WSType.newRequest:
            if let req = msg.request { onNewRequest?(req) }
        case WSType.statusUpdate:
            if let req = msg.request { onStatusUpdate?(req) }
        case WSType.ping:
            send(["type": WSType.pong])
        default:
            break
        }
    }

    private func handleDisconnect() {
        connected = false
        task      = nil
        onDisconnected?()
        guard shouldReconnect else { return }

        let delay = reconnectDelay
        reconnectDelay = min(reconnectDelay * 2, 30)

        reconnectWork = Task {
            try? await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
            guard !Task.isCancelled else { return }
            if let user = Auth.auth().currentUser { _ = try? await user.getIDToken() }
            self.connect()
        }
    }
}
