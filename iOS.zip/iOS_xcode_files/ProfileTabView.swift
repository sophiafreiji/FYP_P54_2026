import SwiftUI
import UniformTypeIdentifiers

extension UTType {
    static let pkcs12 = UTType(mimeType: "application/x-pkcs12") ?? UTType.data
}

struct ProfileTabView: View {
    @EnvironmentObject var profileVM: ProfileViewModel
    @EnvironmentObject var authVM:    AuthViewModel
    @Binding var showLostPhoneAlert:  Bool
    @Binding var showLogoutAlert:     Bool
    @State private var showResetCertAlert  = false
    @State private var showImportPFXSheet  = false
    @State private var showPasswordAlert   = false
    @State private var importFileData:     Data?   = nil
    @State private var importPassword:     String  = ""
    @State private var certInfo:           CryptoService.CertificateInfo? = nil

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.96, green: 0.97, blue: 0.98).ignoresSafeArea()

                if profileVM.isLoading {
                    ProgressView("Loading profile...")
                } else if let profile = profileVM.profile {
                    ScrollView {
                        VStack(spacing: 20) {
                            profileCard(profile)
                            infoRows(profile)
                            if authVM.canSign, let info = certInfo {
                                certificateSection(info)
                            }
                            actionRows
                        }
                        .padding(16)
                    }
                } else {
                    errorView
                }
            }
            .navigationTitle("Profile")
            .navigationBarTitleDisplayMode(.large)
            .task {
                await profileVM.fetchProfile()
                certInfo = CryptoService.shared.extractCertificateInfo()
            }
            .onChange(of: authVM.keySource) {
                certInfo = CryptoService.shared.extractCertificateInfo()
            }
            .alert("Clear Certificate", isPresented: $showResetCertAlert) {
                Button("Cancel", role: .cancel) {}
                Button("Reset", role: .destructive) {
                    Task { await authVM.resetSigningCertificate() }
                }
            } message: {
                Text("This will revoke your current certificate and delete your local signing key. A new certificate will be issued automatically on your next login.")
            }
            .fileImporter(
                isPresented:             $showImportPFXSheet,
                allowedContentTypes:     [.pkcs12],
                allowsMultipleSelection: false
            ) { result in
                guard let url = try? result.get().first else { return }
                guard url.startAccessingSecurityScopedResource() else { return }
                defer { url.stopAccessingSecurityScopedResource() }
                importFileData = try? Data(contentsOf: url)
                importPassword = ""
                showPasswordAlert = true
            }
            .alert("Enter PFX Password", isPresented: $showPasswordAlert) {
                SecureField("Password", text: $importPassword)
                Button("Import") {
                    guard let data = importFileData else { return }
                    Task { await authVM.importPFX(data: data, password: importPassword) }
                }
                Button("Cancel", role: .cancel) { importFileData = nil }
            } message: {
                Text("Enter the password used to protect the PFX file.")
            }
            .alert("Import Failed", isPresented: Binding(
                get: { authVM.importErrorMessage != nil },
                set: { if !$0 { authVM.importErrorMessage = nil } }
            )) {
                Button("OK", role: .cancel) { authVM.importErrorMessage = nil }
            } message: {
                Text(authVM.importErrorMessage ?? "")
            }
            .alert("Import Successful", isPresented: Binding(
                get: { authVM.importSuccessMessage != nil },
                set: { if !$0 { authVM.importSuccessMessage = nil } }
            )) {
                Button("OK", role: .cancel) {
                    authVM.importSuccessMessage = nil
                    certInfo = CryptoService.shared.extractCertificateInfo()
                }
            } message: {
                Text(authVM.importSuccessMessage ?? "")
            }
        }
    }

    private func certificateSection(_ info: CryptoService.CertificateInfo) -> some View {
        VStack(spacing: 0) {

            HStack {
                Image(systemName: "lock.shield.fill")
                    .foregroundColor(.blue)
                Text("Signing Certificate")
                    .font(.subheadline).fontWeight(.bold)
                Spacer()
                Text(info.source)
                    .font(.caption2).fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding(.horizontal, 8).padding(.vertical, 4)
                    .background(info.source == "Fyp54-CA" ? Color.blue : Color.purple)
                    .clipShape(Capsule())
            }
            .padding(.horizontal, 16).padding(.top, 16).padding(.bottom, 10)

            Divider().padding(.horizontal, 16)

            if info.isExpired {
                HStack(spacing: 8) {
                    Image(systemName: "exclamationmark.octagon.fill").foregroundColor(.white)
                    Text("Certificate EXPIRED on \(formatDate(info.notAfter))")
                        .font(.caption).fontWeight(.semibold).foregroundColor(.white)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 16).padding(.vertical, 10)
                .background(Color.red)
            } else if info.isExpiringSoon {
                HStack(spacing: 8) {
                    Image(systemName: "exclamationmark.triangle.fill").foregroundColor(.white)
                    Text("Expires in \(info.daysUntilExpiry) day\(info.daysUntilExpiry == 1 ? "" : "s") - \(formatDate(info.notAfter))")
                        .font(.caption).fontWeight(.semibold).foregroundColor(.white)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 16).padding(.vertical, 10)
                .background(Color.orange)
            }

            VStack(spacing: 0) {
                CertRow(label: "Subject",    value: info.subject)
                Divider().padding(.leading, 16)
                CertRow(label: "Issuer",     value: info.issuer)
                Divider().padding(.leading, 16)
                CertRow(label: "Serial",     value: String(info.serial.prefix(20)) + (info.serial.count > 20 ? "..." : ""))
                Divider().padding(.leading, 16)
                CertRow(label: "Key Type",   value: info.keyType)
                Divider().padding(.leading, 16)
                CertRow(label: "Valid From", value: formatDate(info.notBefore))
                Divider().padding(.leading, 16)
                CertRow(label: "Valid Until",value: formatDate(info.notAfter))
            }
            .padding(.vertical, 8)

            Divider().padding(.horizontal, 16)

            Button {
                exportCertificate()
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "square.and.arrow.up")
                    Text("Export Certificate (.pem)")
                        .fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity)
                .padding(12)
                .foregroundColor(.blue)
            }
            .padding(.horizontal, 8).padding(.bottom, 8)
        }
        .cardStyle()
    }

    private func exportCertificate() {
        guard let pem = CryptoService.shared.exportCertificatePEM() else { return }

        let tempURL = FileManager.default.temporaryDirectory
            .appendingPathComponent("certificate.pem")
        guard (try? pem.write(to: tempURL, atomically: true, encoding: .utf8)) != nil else { return }

        let av = UIActivityViewController(activityItems: [tempURL], applicationActivities: nil)
        guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let root  = scene.windows.first?.rootViewController else { return }

        av.popoverPresentationController?.sourceView = root.view
        av.popoverPresentationController?.sourceRect = CGRect(
            x: root.view.bounds.midX, y: root.view.bounds.midY, width: 0, height: 0
        )
        root.present(av, animated: true)
    }

    private func profileCard(_ profile: UserProfile) -> some View {
        VStack(spacing: 12) {
            Circle().fill(Color.blue).frame(width: 80, height: 80)
                .overlay(
                    Text(profile.avatarLetter)
                        .font(.system(size: 34, weight: .bold))
                        .foregroundColor(.white)
                )
            Text(profile.username).font(.title3).fontWeight(.bold)
            if profile.isBlacklisted {
                Label("Blacklisted", systemImage: "exclamationmark.triangle.fill")
                    .font(.caption).fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding(.horizontal, 12).padding(.vertical, 6)
                    .background(Color.red.opacity(0.8))
                    .clipShape(Capsule())
            }
        }
        .padding(24)
        .frame(maxWidth: .infinity)
        .cardStyle()
    }

    private func infoRows(_ profile: UserProfile) -> some View {
        VStack(spacing: 0) {
            ProfileRow(icon: "person.fill",  label: "Username", value: profile.username)
            Divider().padding(.leading, 50)
            ProfileRow(icon: "envelope.fill", label: "Email",   value: profile.email ?? "—")
            Divider().padding(.leading, 50)
            ProfileRow(icon: "network",       label: "Provider", value: profile.providerDisplay)
        }
        .cardStyle()
    }

    private var actionRows: some View {
        VStack(spacing: 0) {

            if authVM.canSign {
                SigningFormatRow()
                Divider().padding(.leading, 56)
            }

            ActionRow(
                icon:      authVM.canSign ? "iphone.slash" : "lock.fill",
                label:     "Lost my phone",
                subtitle:  authVM.canSign ? nil : "Not available, this device belongs to another user",
                iconColor: authVM.canSign ? .red : .secondary,
                textColor: authVM.canSign ? .red : .secondary,
                disabled:  !authVM.canSign
            ) {
                showLostPhoneAlert = true
            }
            Divider().padding(.leading, 56)

            if authVM.canSign {
                ActionRow(
                    icon:      "arrow.triangle.2.circlepath.circle",
                    label:     "Clear Certificate",
                    subtitle:  "Deletes keys and certificate",
                    iconColor: .orange,
                    textColor: .primary,
                    disabled:  false
                ) {
                    showResetCertAlert = true
                }
                Divider().padding(.leading, 56)
                ActionRow(
                    icon:      "square.and.arrow.down.on.square",
                    label:     "Import Certificate",
                    subtitle:  "Import an external certificate (.p12/.pfx)",
                    iconColor: .purple,
                    textColor: .primary,
                    disabled:  false
                ) {
                    showImportPFXSheet = true
                }
                Divider().padding(.leading, 56)
            }
            ActionRow(icon: "rectangle.portrait.and.arrow.right", label: "Logout", subtitle: nil, iconColor: .secondary, textColor: .primary, disabled: false) {
                showLogoutAlert = true
            }
        }
        .cardStyle()
    }

    private var errorView: some View {
        VStack(spacing: 12) {
            Image(systemName: "person.crop.circle.badge.exclamationmark")
                .font(.system(size: 40)).foregroundColor(.secondary)
            Text(profileVM.errorMessage ?? "Could not load profile.")
                .multilineTextAlignment(.center).foregroundColor(.secondary)
            Button("Retry") { Task { await profileVM.fetchProfile() } }
                .buttonStyle(.bordered)
        }
        .padding()
    }
}

struct ProfileRow: View {
    let icon: String
    let label: String
    let value: String

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: icon).foregroundColor(.blue).frame(width: 22)
            VStack(alignment: .leading, spacing: 2) {
                Text(label).font(.caption).foregroundColor(.secondary)
                Text(value).font(.subheadline).fontWeight(.medium)
            }
            Spacer()
        }
        .padding(.horizontal, 16).padding(.vertical, 12)
    }
}

private struct ActionRow: View {
    let icon:      String
    let label:     String
    let subtitle:  String?
    let iconColor: Color
    let textColor: Color
    let disabled:  Bool
    let action:    () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: icon).foregroundColor(iconColor).frame(width: 28)
                VStack(alignment: .leading, spacing: 2) {
                    Text(label).foregroundColor(textColor).fontWeight(.semibold)
                    if let subtitle {
                        Text(subtitle).font(.caption).foregroundColor(.secondary)
                    }
                }
                Spacer()
                Image(systemName: "chevron.right").foregroundColor(.secondary).font(.caption)
            }
            .padding(16)
        }
        .disabled(disabled)
    }
}

private extension View {
    func cardStyle() -> some View {
        self
            .background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .shadow(color: .black.opacity(0.05), radius: 6, x: 0, y: 3)
    }
}

private func formatDate(_ date: Date) -> String {
    let f = DateFormatter()
    f.dateFormat = "dd/MM/yyyy - HH:mm:ss"
    f.locale = Locale(identifier: "en_GB")
    return f.string(from: date)
}

private struct CertRow: View {
    let label: String
    let value: String

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Text(label)
                .font(.caption)
                .foregroundColor(.secondary)
                .frame(width: 80, alignment: .leading)
            Text(value)
                .font(.caption)
                .fontWeight(.medium)
                .foregroundColor(.primary)
                .multilineTextAlignment(.leading)
            Spacer()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
    }
}

struct SigningFormatRow: View {
    @State private var selectedFormat: String = UserDefaults.standard.string(forKey: "signingFormat") ?? "pkcs7"

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 12) {
                Image(systemName: "signature")
                    .foregroundColor(.blue)
                    .frame(width: 28)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Signing Format")
                        .fontWeight(.semibold)
                    Text(selectedFormat == "pkcs7"
                         ? "Standard format"
                         : "Raw ECDSA signature bytes")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                Spacer()
            }

            HStack(spacing: 0) {
                ForEach(["pkcs7", "raw"], id: \.self) { format in
                    Button {
                        selectedFormat = format
                        UserDefaults.standard.set(format, forKey: "signingFormat")
                    } label: {
                        Text(format == "pkcs7" ? "PKCS#7" : "Raw")
                            .font(.subheadline)
                            .fontWeight(.semibold)
                            .padding(.vertical, 8)
                            .frame(maxWidth: .infinity)
                            .background(selectedFormat == format ? Color.blue : Color(UIColor.systemGray5))
                            .foregroundColor(selectedFormat == format ? .white : .primary)
                    }
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .padding(.leading, 40)
        }
        .padding(16)
    }
}
