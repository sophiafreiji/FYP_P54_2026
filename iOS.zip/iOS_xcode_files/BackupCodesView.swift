import SwiftUI
import UIKit

struct BackupCodesView: View {
    let codes:         [String]
    let goToApp:       Bool
    let onDone:        () -> Void
    var onRequestCert: (() async -> Void)? = nil

    @State private var confirmed = false

    var body: some View {
        ZStack {
            Color(red: 0.07, green: 0.09, blue: 0.16).ignoresSafeArea()

            ScrollView {
                VStack(spacing: 24) {
                    VStack(spacing: 12) {
                        Image(systemName: "key.fill")
                            .font(.system(size: 48)).foregroundColor(.yellow)
                        Text("Save Your Backup Keys")
                            .font(.title2).fontWeight(.bold).foregroundColor(.white)
                        Text("These 10 keys are your only way to recover your account or reset your password.")
                            .font(.subheadline).foregroundColor(.white.opacity(0.7))
                            .multilineTextAlignment(.center)
                    }
                    .padding(.top, 40)

                    HStack(spacing: 10) {
                        Image(systemName: "exclamationmark.triangle.fill").foregroundColor(.orange)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Write them down on a different device!")
                                .font(.caption).fontWeight(.semibold).foregroundColor(.orange)
                        }
                    }
                    .padding(14)
                    .background(Color.orange.opacity(0.15))
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.orange.opacity(0.4)))
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .padding(.horizontal, 4)

                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                        ForEach(Array(codes.enumerated()), id: \.offset) { index, code in
                            CodeCell(index: index + 1, code: code)
                        }
                    }

                    VStack(spacing: 16) {
                        Button { withAnimation { confirmed.toggle() } } label: {
                            HStack(spacing: 10) {
                                Image(systemName: confirmed ? "checkmark.square.fill" : "square")
                                    .foregroundColor(confirmed ? .green : .white.opacity(0.5))
                                Text("I have securely stored my keys.")
                                    .font(.subheadline).foregroundColor(.white.opacity(0.85))
                                    .multilineTextAlignment(.leading)
                            }
                        }

                        Button {
                            onDone()
                            if let certRequest = onRequestCert {
                                Task { await certRequest() }
                            }
                        } label: {
                            Text(goToApp ? "Continue to App" : "Continue to Login")
                                .fontWeight(.semibold)
                                .frame(maxWidth: .infinity)
                                .padding(16)
                                .background(confirmed ? Color.blue : Color.gray.opacity(0.4))
                                .foregroundColor(.white)
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                        }
                        .disabled(!confirmed)
                    }
                    .padding(.bottom, 40)
                }
                .padding(.horizontal, 24)
            }
        }
    }
}

private struct CodeCell: View {
    let index: Int
    let code:  String

    var body: some View {
        VStack(spacing: 6) {
            Text("#\(index)")
                .font(.caption2).fontWeight(.bold)
                .foregroundColor(.white.opacity(0.4))
            HideInScreenshotView {
                Text(code)
                    .font(.system(.body, design: .monospaced)).fontWeight(.semibold)
                    .foregroundColor(.white)
            }
            .frame(height: 24)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .background(Color.white.opacity(0.08))
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white.opacity(0.12)))
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .onLongPressGesture { }
    }
}

struct HideInScreenshotView<Content: View>: UIViewRepresentable {
    private let content:           () -> Content
    private let hostingController: UIHostingController<Content>

    init(@ViewBuilder content: @escaping () -> Content) {
        self.content           = content
        self.hostingController = UIHostingController(rootView: content())
        self.hostingController.view.backgroundColor = .clear
    }

    func makeUIView(context: Context) -> UIView {
        let secureTextField            = UITextField()
        secureTextField.isSecureTextEntry        = true
        secureTextField.isUserInteractionEnabled = false

        guard let secureView = secureTextField.subviews.first else {
            let host = UIHostingController(rootView: content())
            host.view.backgroundColor = .clear
            return host.view
        }

        secureView.removeFromSuperview()
        secureView.subviews.forEach { $0.removeFromSuperview() }

        hostingController.view.translatesAutoresizingMaskIntoConstraints = false
        secureView.addSubview(hostingController.view)

        NSLayoutConstraint.activate([
            hostingController.view.topAnchor.constraint(equalTo: secureView.topAnchor),
            hostingController.view.bottomAnchor.constraint(equalTo: secureView.bottomAnchor),
            hostingController.view.leadingAnchor.constraint(equalTo: secureView.leadingAnchor),
            hostingController.view.trailingAnchor.constraint(equalTo: secureView.trailingAnchor),
        ])

        return secureView
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        hostingController.rootView = content()
    }
}
