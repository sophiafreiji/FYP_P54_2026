import Foundation
import Security
import CryptoKit
import LocalAuthentication

enum CryptoError: Error, LocalizedError {
    case keyGenerationFailed(String)
    case csrBuildingFailed(String)
    case signingFailed(String)
    case pkcs7BuildingFailed(String)
    case certificateLoadFailed(String)
    case keyNotFound

    var errorDescription: String? {
        switch self {
        case .keyGenerationFailed(let m): return "Key generation failed: \(m)"
        case .csrBuildingFailed(let m):   return "CSR failed: \(m)"
        case .signingFailed(let m):       return "Signing failed: \(m)"
        case .pkcs7BuildingFailed(let m): return "PKCS#7 failed: \(m)"
        case .certificateLoadFailed(let m): return "Certificate error: \(m)"
        case .keyNotFound:                return "Signing key not found"
        }
    }
}

class CryptoService {

    static let shared = CryptoService()
    private let keyTag          = "com.fyp54.signingKey"
    private let importedKeyTag  = "com.fyp54.importedSigningKey"
    private let certLabel       = "com.fyp54.signingCert"
    private let keySourceUD     = "keySource"
    private init() {}

    var isImported: Bool {
        UserDefaults.standard.string(forKey: keySourceUD) == "imported"
    }

    func generateOrLoadKeyPair() throws -> SecKey {
        if let existing = loadPrivateKey() { return existing }

        var cfError: Unmanaged<CFError>?

        let access = SecAccessControlCreateWithFlags(
            kCFAllocatorDefault,
            kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
            [.privateKeyUsage, .userPresence],
            &cfError
        )
        guard let access, cfError == nil else {
            throw CryptoError.keyGenerationFailed(
                cfError?.takeRetainedValue().localizedDescription ?? "unknown"
            )
        }

        let attributes: [String: Any] = [
            kSecAttrKeyType as String:       kSecAttrKeyTypeECSECPrimeRandom,
            kSecAttrKeySizeInBits as String: 256,
            kSecAttrTokenID as String:       kSecAttrTokenIDSecureEnclave,
            kSecPrivateKeyAttrs as String: [
                kSecAttrIsPermanent as String:    true,
                kSecAttrApplicationTag as String: keyTag.data(using: .utf8)!,
                kSecAttrAccessControl as String:  access
            ] as [String: Any]
        ]

        guard let key = SecKeyCreateRandomKey(attributes as CFDictionary, &cfError) else {
            throw CryptoError.keyGenerationFailed(
                cfError?.takeRetainedValue().localizedDescription ?? "unknown"
            )
        }
        return key
    }

    func loadPrivateKey() -> SecKey? {
        if isImported {
            return loadImportedPrivateKey()
        } else {
            return loadSEPrivateKey()
        }
    }

    private func loadSEPrivateKey() -> SecKey? {
        let query: [String: Any] = [
            kSecClass as String:              kSecClassKey,
            kSecAttrApplicationTag as String: keyTag.data(using: .utf8)!,
            kSecAttrKeyType as String:        kSecAttrKeyTypeECSECPrimeRandom,
            kSecReturnRef as String:          true
        ]
        var item: CFTypeRef?
        return SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess
            ? (item as! SecKey)
            : nil
    }

    private func loadImportedPrivateKey() -> SecKey? {
        let query: [String: Any] = [
            kSecClass as String:              kSecClassKey,
            kSecAttrApplicationTag as String: importedKeyTag.data(using: .utf8)!,
            kSecReturnRef as String:          true
        ]
        var item: CFTypeRef?
        return SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess
            ? (item as! SecKey)
            : nil
    }

    func hasImportedKey() -> Bool {
        let query: [String: Any] = [
            kSecClass as String:              kSecClassKey,
            kSecAttrApplicationTag as String: importedKeyTag.data(using: .utf8)!,
            kSecReturnRef as String:          false
        ]
        var item: CFTypeRef?
        return SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess
    }

    func loadPrivateKeyWithContext(_ context: LAContext) -> SecKey? {
        if isImported {
            return loadImportedPrivateKey()
        }
        let query: [String: Any] = [
            kSecClass as String:                        kSecClassKey,
            kSecAttrApplicationTag as String:           keyTag.data(using: .utf8)!,
            kSecAttrKeyType as String:                  kSecAttrKeyTypeECSECPrimeRandom,
            kSecReturnRef as String:                    true,
            kSecUseAuthenticationContext as String:     context
        ]
        var item: CFTypeRef?
        return SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess
            ? (item as! SecKey)
            : nil
    }

    func deleteKeyPair() {
        let seQuery: [String: Any] = [
            kSecClass as String:              kSecClassKey,
            kSecAttrApplicationTag as String: keyTag.data(using: .utf8)!
        ]
        SecItemDelete(seQuery as CFDictionary)

        let importedQuery: [String: Any] = [
            kSecClass as String:              kSecClassKey,
            kSecAttrApplicationTag as String: importedKeyTag.data(using: .utf8)!
        ]
        SecItemDelete(importedQuery as CFDictionary)

        UserDefaults.standard.removeObject(forKey: keySourceUD)
    }

    func importPFX(data: Data, password: String) throws -> (SecKey, SecCertificate) {
        let options: [String: Any] = [kSecImportExportPassphrase as String: password]
        var items: CFArray?
        let status = SecPKCS12Import(data as CFData, options as CFDictionary, &items)

        guard status == errSecSuccess,
              let array = items as? [[String: Any]],
              !array.isEmpty
        else {
            let msg = status == errSecAuthFailed
                ? "Incorrect password. Please check and try again."
                : "Could not open PFX file."
            throw CryptoError.certificateLoadFailed(msg)
        }

        guard let identity = array[0][kSecImportItemIdentity as String] as! SecIdentity? else {
            throw CryptoError.certificateLoadFailed("Something went wrong.")
        }

        var certificate: SecCertificate?
        var privateKey: SecKey?
        let certStatus = SecIdentityCopyCertificate(identity, &certificate)
        let keyStatus  = SecIdentityCopyPrivateKey(identity, &privateKey)

        guard certStatus == errSecSuccess, let cert = certificate else {
            throw CryptoError.certificateLoadFailed("Something went wrong.")
        }
        guard keyStatus == errSecSuccess, let key = privateKey else {
            throw CryptoError.certificateLoadFailed("Something went wrong.")
        }

        let importedQuery: [String: Any] = [
            kSecClass as String:              kSecClassKey,
            kSecAttrApplicationTag as String: importedKeyTag.data(using: .utf8)!
        ]
        SecItemDelete(importedQuery as CFDictionary)

        let addKeyQuery: [String: Any] = [
            kSecClass as String:              kSecClassKey,
            kSecValueRef as String:           key,
            kSecAttrApplicationTag as String: importedKeyTag.data(using: .utf8)!,
            kSecAttrIsPermanent as String:    true,
            kSecAttrAccessible as String:     kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        ]
        let addStatus = SecItemAdd(addKeyQuery as CFDictionary, nil)
        guard addStatus == errSecSuccess || addStatus == errSecDuplicateItem else {
            throw CryptoError.certificateLoadFailed("Failed to store imports.")
        }

        UserDefaults.standard.set("imported", forKey: keySourceUD)

        return (key, cert)
    }

    func commitImport(importedCert: SecCertificate) throws {
        let seKeyQuery: [String: Any] = [
            kSecClass as String:              kSecClassKey,
            kSecAttrApplicationTag as String: keyTag.data(using: .utf8)!
        ]
        SecItemDelete(seKeyQuery as CFDictionary)

        deleteCertificate()

        let certPEM = derToPEM(SecCertificateCopyData(importedCert) as Data)
        try storeCertificate(certPEM)
    }

    func deleteImportedKey() {
        let query: [String: Any] = [
            kSecClass as String:              kSecClassKey,
            kSecAttrApplicationTag as String: importedKeyTag.data(using: .utf8)!
        ]
        SecItemDelete(query as CFDictionary)
        UserDefaults.standard.set(KeySource.secureEnclave.rawValue, forKey: keySourceUD)
    }

    func storeCertificate(_ certPEM: String) throws {
        guard let derData = pemToDER(certPEM) else {
            throw CryptoError.certificateLoadFailed("Something went wrong.")
        }
        guard let cert = SecCertificateCreateWithData(nil, derData as CFData) else {
            throw CryptoError.certificateLoadFailed("Something went wrong.")
        }

        deleteCertificate()

        let addQuery: [String: Any] = [
            kSecClass as String:       kSecClassCertificate,
            kSecValueRef as String:    cert,
            kSecAttrLabel as String:   certLabel,
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        ]
        let status = SecItemAdd(addQuery as CFDictionary, nil)
        guard status == errSecSuccess else {
            throw CryptoError.certificateLoadFailed("Something went wrong.")
        }
    }

    func loadCertificate() -> SecCertificate? {
        let query: [String: Any] = [
            kSecClass as String:     kSecClassCertificate,
            kSecAttrLabel as String: certLabel,
            kSecReturnRef as String: true
        ]
        var item: CFTypeRef?
        return SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess
            ? (item as! SecCertificate)
            : nil
    }

    func hasCertificate() -> Bool { loadCertificate() != nil }

    func storedCertSerialNumber() -> String? {
        guard let cert = loadCertificate() else { return nil }
        var cfError: Unmanaged<CFError>?
        guard let serialData = SecCertificateCopySerialNumberData(cert, &cfError) as Data? else {
            return nil
        }
        let hex = serialData.map { String(format: "%02X", $0) }.joined()
        let stripped = hex.drop(while: { $0 == "0" })
        return stripped.isEmpty ? "0" : String(stripped)
    }

    func deleteCertificate() {
        let query: [String: Any] = [
            kSecClass as String:     kSecClassCertificate,
            kSecAttrLabel as String: certLabel
        ]
        SecItemDelete(query as CFDictionary)
        clearCertMetadata()
    }

    func buildCSR(privateKey: SecKey, email: String, commonName: String) throws -> String {
        var cfErr: Unmanaged<CFError>?
        guard let pubKeyData = SecKeyCopyExternalRepresentation(
            SecKeyCopyPublicKey(privateKey)!, &cfErr
        ) as Data? else {
            throw CryptoError.csrBuildingFailed(
                cfErr?.takeRetainedValue().localizedDescription ?? "Cannot export."
            )
        }
        let ecPublicKeyOID: [UInt8] = [0x2A, 0x86, 0x48, 0xCE, 0x3D, 0x02, 0x01]
        let prime256v1OID:  [UInt8] = [0x2A, 0x86, 0x48, 0xCE, 0x3D, 0x03, 0x01, 0x07]

        let algID   = seq(oid(ecPublicKeyOID) + oid(prime256v1OID))
        let pubBits = bitString([0x00] + Array(pubKeyData))
        let spki    = seq(algID + pubBits)

        let subjectDN = buildSubjectDN(commonName: commonName, org: "Fyp54", country: "LB")

        let version        = tlv(0x02, [0x00])
        let attributesTag  = tlv(0xA0, [])
        let csrInfo        = seq(version + subjectDN + spki + attributesTag)

        let csrInfoData = Data(csrInfo)
        let signature   = try sign(data: csrInfoData, with: privateKey)

        let ecdsaSHA256OID: [UInt8] = [0x2A, 0x86, 0x48, 0xCE, 0x3D, 0x04, 0x03, 0x02]
        let sigAlg = seq(oid(ecdsaSHA256OID))
        let sigBit = bitString([0x00] + Array(signature))
        let csr    = seq(csrInfo + sigAlg + sigBit)

        let b64 = Data(csr).base64EncodedString(options: [.lineLength64Characters, .endLineWithLineFeed])
        return "-----BEGIN CERTIFICATE REQUEST-----\n\(b64)\n-----END CERTIFICATE REQUEST-----"
    }

    func sign(data: Data, with privateKey: SecKey) throws -> Data {
        let algorithm: SecKeyAlgorithm = isImported
            ? .rsaSignatureMessagePKCS1v15SHA256
            : .ecdsaSignatureMessageX962SHA256

        guard SecKeyIsAlgorithmSupported(privateKey, .sign, algorithm) else {
            throw CryptoError.signingFailed("Algorithm not supported.")
        }
        var cfErr: Unmanaged<CFError>?
        guard let sig = SecKeyCreateSignature(privateKey, algorithm, data as CFData, &cfErr) as Data? else {
            throw CryptoError.signingFailed(
                cfErr?.takeRetainedValue().localizedDescription ?? "Something went wrong."
            )
        }
        return sig
    }

    func buildPKCS7(
        content:     Data,
        privateKey:  SecKey,
        certificate: SecCertificate
    ) throws -> Data {

        let oidSignedData:     [UInt8] = [0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x07, 0x02]
        let oidData:           [UInt8] = [0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x07, 0x01]
        let oidSHA256:         [UInt8] = [0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x01]
        let oidContentType:    [UInt8] = [0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x09, 0x03]
        let oidSigningTime:    [UInt8] = [0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x09, 0x05]
        let oidMessageDigest:  [UInt8] = [0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x09, 0x04]

        let oidSignatureAlg: [UInt8] = isImported
            ? [0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x01, 0x0B]
            : [0x2A, 0x86, 0x48, 0xCE, 0x3D, 0x04, 0x03, 0x02]

        let certDER = SecCertificateCopyData(certificate) as Data
        guard
            let issuerSeq  = SecCertificateCopyNormalizedIssuerSequence(certificate) as Data?,
            let serialData = SecCertificateCopySerialNumberData(certificate, nil) as Data?
        else {
            throw CryptoError.pkcs7BuildingFailed("Invalid certificate.")
        }

        let hashBytes = Array(SHA256.hash(data: content))

        let now = Date()
        let cal = Calendar(identifier: .gregorian)
        var utcCal = cal
        utcCal.timeZone = TimeZone(identifier: "UTC")!
        let comps = utcCal.dateComponents([.year, .month, .day, .hour, .minute, .second], from: now)
        let yy = String(format: "%02d", (comps.year ?? 2026) % 100)
        let mm = String(format: "%02d", comps.month ?? 1)
        let dd = String(format: "%02d", comps.day ?? 1)
        let hh = String(format: "%02d", comps.hour ?? 0)
        let mn = String(format: "%02d", comps.minute ?? 0)
        let ss = String(format: "%02d", comps.second ?? 0)
        let utcTimeStr = "\(yy)\(mm)\(dd)\(hh)\(mn)\(ss)Z"
        let utcTimeBytes = Array(utcTimeStr.utf8)
        let utcTimeEncoded = tlv(0x17, utcTimeBytes)

        let contentTypeAttr = seq(
            oid(oidContentType) +
            set([oid(oidData)])
        )

        let signingTimeAttr = seq(
            oid(oidSigningTime) +
            set([utcTimeEncoded])
        )

        let messageDigestAttr = seq(
            oid(oidMessageDigest) +
            set([tlv(0x04, hashBytes)])
        )

        let signedAttrsContent = contentTypeAttr + signingTimeAttr + messageDigestAttr
        let signedAttrsForSigning = tlv(0x31, signedAttrsContent)
        let signedAttrsForEmbed  = tlv(0xA0, signedAttrsContent)

        let signature = try sign(data: Data(signedAttrsForSigning), with: privateKey)

        let sha256AlgID      = seq(oid(oidSHA256) + [0x05, 0x00])
        let digestAlgorithms = set([sha256AlgID])

        let contentOctetStr  = tlv(0x04, Array(content))
        let contentExplicit  = tlv(0xA0, contentOctetStr)
        let encapContentInfo = seq(oid(oidData) + contentExplicit)

        let certificates = tlv(0xA0, Array(certDER))

        let serialInt       = tlv(0x02, Array(serialData))
        let issuerAndSerial = seq(Array(issuerSeq) + serialInt)

        let signerVersion   = tlv(0x02, [0x01])
        let signerDigestAlg = sha256AlgID
        let signatureAlg    = seq(oid(oidSignatureAlg))
        let signatureOctet  = tlv(0x04, Array(signature))

        let signerInfo = seq(
            signerVersion +
            issuerAndSerial +
            signerDigestAlg +
            signedAttrsForEmbed +
            signatureAlg +
            signatureOctet
        )
        let signerInfos = set([signerInfo])

        let sdVersion  = tlv(0x02, [0x01])
        let signedData = seq(
            sdVersion +
            digestAlgorithms +
            encapContentInfo +
            certificates +
            signerInfos
        )

        let sdExplicit  = tlv(0xA0, signedData)
        let contentInfo = seq(oid(oidSignedData) + sdExplicit)

        return Data(contentInfo)
    }

    struct CertificateInfo {
        let subject:    String
        let issuer:     String
        let serial:     String
        let notBefore:  Date
        let notAfter:   Date
        let keyType:    String
        let source:     String

        var daysUntilExpiry: Int {
            Calendar.current.dateComponents([.day], from: Date(), to: notAfter).day ?? 0
        }
        var isExpired:      Bool { daysUntilExpiry < 0 }
        var isExpiringSoon: Bool { daysUntilExpiry >= 0 && daysUntilExpiry <= 15 }
    }

    private let udCertSubject   = "certMeta_subject"
    private let udCertIssuer    = "certMeta_issuer"
    private let udCertSerial    = "certMeta_serial"
    private let udCertNotBefore = "certMeta_notBefore"
    private let udCertNotAfter  = "certMeta_notAfter"

    func saveCertMetadata(subject: String, issuer: String, serial: String,
                          notBefore: Date, notAfter: Date) {
        let ud = UserDefaults.standard
        ud.set(subject,             forKey: udCertSubject)
        ud.set(issuer,              forKey: udCertIssuer)
        ud.set(serial,              forKey: udCertSerial)
        ud.set(notBefore.timeIntervalSince1970, forKey: udCertNotBefore)
        ud.set(notAfter.timeIntervalSince1970,  forKey: udCertNotAfter)
    }

    func clearCertMetadata() {
        let ud = UserDefaults.standard
        [udCertSubject, udCertIssuer, udCertSerial, udCertNotBefore, udCertNotAfter]
            .forEach { ud.removeObject(forKey: $0) }
    }

    func extractCertificateInfo() -> CertificateInfo? {
        guard hasCertificate() else { return nil }

        let ud = UserDefaults.standard

        let subject: String = ud.string(forKey: udCertSubject)
            ?? (loadCertificate().flatMap { SecCertificateCopySubjectSummary($0) as String? })
            ?? "—"

        let issuer    = ud.string(forKey: udCertIssuer) ?? "—"
        let serial    = ud.string(forKey: udCertSerial) ?? storedCertSerialNumber() ?? "—"

        let notBeforeTS = ud.double(forKey: udCertNotBefore)
        let notAfterTS  = ud.double(forKey: udCertNotAfter)

        let notBefore = notBeforeTS > 0 ? Date(timeIntervalSince1970: notBeforeTS) : Date()
        let notAfter  = notAfterTS  > 0 ? Date(timeIntervalSince1970: notAfterTS)  : Date()

        let keyType = isImported ? "RSA 2048" : "ECDSA P-256"
        let source  = isImported ? "Imported" : "Fyp54-CA"

        return CertificateInfo(
            subject:   subject,
            issuer:    issuer,
            serial:    serial,
            notBefore: notBefore,
            notAfter:  notAfter,
            keyType:   keyType,
            source:    source
        )
    }

    func exportCertificatePEM() -> String? {
        guard let cert = loadCertificate() else { return nil }
        return derToPEM(SecCertificateCopyData(cert) as Data)
    }

    func sha256Hex(_ data: Data) -> String {
        SHA256.hash(data: data).compactMap { String(format: "%02x", $0) }.joined()
    }

    func pemToDER(_ pem: String) -> Data? {
        let normalised = pem
            .replacingOccurrences(of: "\r\n", with: "\n")
            .replacingOccurrences(of: "\r", with: "\n")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        let base64 = normalised
            .components(separatedBy: "\n")
            .filter { !$0.hasPrefix("-----") && !$0.isEmpty }
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .joined()

        if let data = Data(base64Encoded: base64) { return data }
        return Data(base64Encoded: base64, options: .ignoreUnknownCharacters)
    }

    func derToPEM(_ derData: Data) -> String {
        let b64 = derData.base64EncodedString(options: [.lineLength64Characters, .endLineWithLineFeed])
        return "-----BEGIN CERTIFICATE-----\n\(b64)\n-----END CERTIFICATE-----"
    }

    private func derLen(_ len: Int) -> [UInt8] {
        if len < 0x80  { return [UInt8(len)] }
        if len < 0x100 { return [0x81, UInt8(len)] }
        return [0x82, UInt8(len >> 8), UInt8(len & 0xFF)]
    }

    private func tlv(_ tag: UInt8, _ value: [UInt8]) -> [UInt8] {
        [tag] + derLen(value.count) + value
    }

    private func seq(_ value: [UInt8]) -> [UInt8] { tlv(0x30, value) }
    private func set(_ items: [[UInt8]]) -> [UInt8] { tlv(0x31, items.flatMap { $0 }) }
    private func oid(_ bytes: [UInt8])  -> [UInt8] { tlv(0x06, bytes) }

    private func bitString(_ bytes: [UInt8]) -> [UInt8] { tlv(0x03, bytes) }

    private func utf8Str(_ s: String) -> [UInt8] {
        tlv(0x0C, Array(s.utf8))
    }

    private func rdn(oidBytes: [UInt8], value: String) -> [UInt8] {
        let attrSeq = seq(oid(oidBytes) + utf8Str(value))
        return set([attrSeq])
    }

    private func buildSubjectDN(commonName: String, org: String, country: String) -> [UInt8] {
        let oidCN: [UInt8]  = [0x55, 0x04, 0x03]
        let oidO:  [UInt8]  = [0x55, 0x04, 0x0A]
        let oidC:  [UInt8]  = [0x55, 0x04, 0x06]
        return seq(
            rdn(oidBytes: oidCN, value: commonName) +
            rdn(oidBytes: oidO,  value: org) +
            rdn(oidBytes: oidC,  value: country)
        )
    }
}
