import Foundation
import FirebaseAuth
import LocalAuthentication

@MainActor
class RequestsViewModel: ObservableObject {
    @Published var requests:      [SigningRequest] = []
    @Published var isLoading      = false
    @Published var errorMessage:  String?
    @Published var multiSignProgress: String? = nil

    private let ws = WebSocketService.shared

    init() {
        ws.onNewRequest = { [weak self] req in
            guard let self, !self.requests.contains(where: { $0.id == req.id }) else { return }
            self.requests.insert(req, at: 0)
        }
        ws.onStatusUpdate = { [weak self] updated in
            guard let self, let idx = self.requests.firstIndex(where: { $0.id == updated.id }) else { return }
            self.requests[idx] = updated
        }
    }

    func startLive() { ws.connect(); Task { await fetchRequests() } }
    
    func stopLive()  { ws.disconnect() }

    func fetchRequests() async {
        guard let user = Auth.auth().currentUser else { return }
        isLoading = true
        errorMessage = nil
        do {
            requests = try await APIService.shared.getRequests(token: try await user.getIDToken())
        } catch let e as APIError {
            errorMessage = e.message
        } catch {
            errorMessage = "Failed to load requests."
        }
        isLoading = false
    }

    func rejectRequest(_ request: SigningRequest) async { await updateStatus(request, status: "rejected") }

    func acceptRequest(_ request: SigningRequest) async {
        guard let user = Auth.auth().currentUser else { return }
        let crypto = CryptoService.shared

        let signingFormat = UserDefaults.standard.string(forKey: "signingFormat") ?? "pkcs7"

        do {
            if crypto.isImported {
                let context = LAContext()
                do {
                    let ok = try await context.evaluatePolicy(
                        .deviceOwnerAuthentication,
                        localizedReason: "Authenticate to sign this document"
                    )
                    guard ok else {
                        errorMessage = "Authentication failed."
                        return
                    }
                } catch {
                    errorMessage = "Authentication cancelled."
                    return
                }
            }

            guard let privateKey = crypto.loadPrivateKey() else {
                errorMessage = "Certificate not available. Please sign out and sign back in."
                return
            }

            guard let certificate = crypto.loadCertificate() else {
                errorMessage = "Certificate not available. Please sign out and sign back in."
                return
            }

            let contentData = request.content.data(using: .utf8) ?? Data()
            let contentHash = crypto.sha256Hex(contentData)

            let pkcs7B64: String

            if signingFormat == "raw" {
                let signature = try crypto.sign(data: contentData, with: privateKey)
                pkcs7B64 = signature.base64EncodedString()
            } else {
                let pkcs7Data = try crypto.buildPKCS7(
                    content:     contentData,
                    privateKey:  privateKey,
                    certificate: certificate
                )
                pkcs7B64 = pkcs7Data.base64EncodedString()
            }

            let token = try await user.getIDToken()
            _ = try await APIService.shared.submitSignature(
                requestId:       request.id,
                pkcs7B64:        pkcs7B64,
                contentHash:     contentHash,
                token:           token,
                signatureFormat: signingFormat
            )

            if let idx = requests.firstIndex(where: { $0.id == request.id }) {
                requests[idx] = SigningRequest(
                    id:        request.id,
                    content:   request.content,
                    summary:   request.summary,
                    status:    "accepted",
                    createdAt: request.createdAt,
                    updatedAt: ISO8601DateFormatter().string(from: Date())
                )
            }

        } catch let e as APIError {
            errorMessage = e.message
        } catch {
            errorMessage = "Signing failed. Please try again."
        }
    }

    func acceptMultipleRequests(_ selectedRequests: [SigningRequest]) async {
        guard let user = Auth.auth().currentUser else { return }
        let crypto = CryptoService.shared
        let signingFormat = UserDefaults.standard.string(forKey: "signingFormat") ?? "pkcs7"

        let context = LAContext()
        context.localizedReason = "Sign \(selectedRequests.count) request\(selectedRequests.count > 1 ? "s" : "")"

        do {
            let success = try await context.evaluatePolicy(
                .deviceOwnerAuthentication,
                localizedReason: "Authenticate to sign \(selectedRequests.count) document\(selectedRequests.count > 1 ? "s" : "")"
            )
            guard success else {
                errorMessage = "Authentication failed."
                return
            }
        } catch {
            errorMessage = "Authentication cancelled."
            return
        }

        guard let privateKey = crypto.loadPrivateKeyWithContext(context) else {
            errorMessage = "Signing key not found."
            return
        }

        guard let certificate = crypto.loadCertificate() else {
            errorMessage = "Certificate not found."
            return
        }

        let total = selectedRequests.count
        var successCount = 0

        for (index, request) in selectedRequests.enumerated() {
            multiSignProgress = "Signing \(index + 1) of \(total)..."

            do {
                let contentData = request.content.data(using: .utf8) ?? Data()
                let contentHash = crypto.sha256Hex(contentData)

                let pkcs7B64: String
                if signingFormat == "raw" {
                    let signature = try crypto.sign(data: contentData, with: privateKey)
                    pkcs7B64 = signature.base64EncodedString()
                } else {
                    let pkcs7Data = try crypto.buildPKCS7(
                        content:     contentData,
                        privateKey:  privateKey,
                        certificate: certificate
                    )
                    pkcs7B64 = pkcs7Data.base64EncodedString()
                }

                let token = try await user.getIDToken()

                _ = try await APIService.shared.submitSignature(
                    requestId:       request.id,
                    pkcs7B64:        pkcs7B64,
                    contentHash:     contentHash,
                    token:           token,
                    signatureFormat: signingFormat
                )

                if let idx = requests.firstIndex(where: { $0.id == request.id }) {
                    requests[idx] = SigningRequest(
                        id:        request.id,
                        content:   request.content,
                        summary:   request.summary,
                        status:    "accepted",
                        createdAt: request.createdAt,
                        updatedAt: ISO8601DateFormatter().string(from: Date())
                    )
                }
                successCount += 1

            } catch let e as APIError {
                errorMessage = "REQ-\(request.id) failed. Please try again."
            } catch {
                errorMessage = "REQ-\(request.id) failed. Please try again."
            }
        }

        multiSignProgress = nil

        if successCount == total {
        } else {
            errorMessage = "\(successCount) of \(total) requests signed successfully."
        }
    }

    private func updateStatus(_ request: SigningRequest, status: String) async {
        guard let user = Auth.auth().currentUser else { return }
        do {
            let token = try await user.getIDToken()
            try await APIService.shared.updateRequestStatus(requestId: request.id, status: status, token: token)
            if let idx = requests.firstIndex(where: { $0.id == request.id }) {
                requests[idx] = SigningRequest(
                    id: request.id, content: request.content, summary: request.summary,
                    status: status, createdAt: request.createdAt,
                    updatedAt: ISO8601DateFormatter().string(from: Date())
                )
            }
        } catch let e as APIError {
            errorMessage = e.message
        } catch {
            errorMessage = "Failed to update request."
        }
    }

    var pendingRequests: [SigningRequest] {
        requests.filter { $0.status == "pending" }
    }

    var historyRequests: [SigningRequest] {
        requests
            .filter { $0.status == "accepted" || $0.status == "rejected" }
            .sorted { $0.id > $1.id }
    }
}
