import SwiftUI
import FirebaseCore

@main
struct TESTApp: App {
    init() { FirebaseApp.configure() }

    var body: some Scene {
        WindowGroup { RootView() }
    }
}
