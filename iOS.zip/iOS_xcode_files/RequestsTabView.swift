import SwiftUI

struct RequestsTabView: View {
    @EnvironmentObject var requestsVM: RequestsViewModel
    @EnvironmentObject var authVM:     AuthViewModel
    @State private var isSelecting     = false
    @State private var selectedIDs:    Set<Int> = []
    @State private var showMultiSignConfirm = false

    var body: some View {
        RequestListView(
            title: "Pending",
            isEmpty: requestsVM.pendingRequests.isEmpty,
            isLoading: requestsVM.isLoading && requestsVM.requests.isEmpty,
            loadingLabel: "Loading requests...",
            emptyMessage: "No pending requests",
            emptySubtitle: "New requests will appear here",
            errorMessage: Binding(
                get: { requestsVM.errorMessage },
                set: { if $0 == nil { requestsVM.errorMessage = nil } }
            ),
            canSign: authVM.canSign,
            isSelecting: $isSelecting,
            selectedIDs: $selectedIDs,
            onSelectToggle: {
                if isSelecting { selectedIDs.removeAll() }
                isSelecting.toggle()
            }
        ) {
            ForEach(requestsVM.pendingRequests) { req in
                RequestCard(
                    request:     req,
                    canSign:     authVM.canSign,
                    isSelecting: isSelecting,
                    isSelected:  selectedIDs.contains(req.id)
                ) {
                    if selectedIDs.contains(req.id) {
                        selectedIDs.remove(req.id)
                    } else {
                        selectedIDs.insert(req.id)
                    }
                }
                .environmentObject(requestsVM)
            }
        }
        .overlay(alignment: .bottom) {
            if let progress = requestsVM.multiSignProgress {
                HStack(spacing: 12) {
                    ProgressView().tint(.white)
                    Text(progress).foregroundColor(.white).fontWeight(.semibold)
                }
                .padding(.horizontal, 24).padding(.vertical, 14)
                .background(Color.blue)
                .clipShape(Capsule())
                .padding(.bottom, 20)
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .safeAreaInset(edge: .bottom) {
            if isSelecting && authVM.canSign {
                HStack(spacing: 12) {
                    Button("Cancel") {
                        isSelecting = false
                        selectedIDs.removeAll()
                    }
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity)
                    .padding(14)
                    .background(Color(UIColor.systemGray5))
                    .clipShape(RoundedRectangle(cornerRadius: 14))

                    Button {
                        if !selectedIDs.isEmpty {
                            showMultiSignConfirm = true
                        }
                    } label: {
                        Text(selectedIDs.isEmpty ? "Select requests" : "Sign \(selectedIDs.count) request\(selectedIDs.count > 1 ? "s" : "")")
                            .fontWeight(.semibold)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(14)
                            .background(selectedIDs.isEmpty ? Color.gray : Color.green)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    .disabled(selectedIDs.isEmpty)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(.ultraThinMaterial)
            }
        }
        .animation(.easeInOut(duration: 0.2), value: isSelecting)
        .animation(.easeInOut(duration: 0.2), value: requestsVM.multiSignProgress)
        .alert("Sign \(selectedIDs.count) Request\(selectedIDs.count > 1 ? "s" : "")", isPresented: $showMultiSignConfirm) {
            Button("Cancel", role: .cancel) {}
            Button("Sign") {
                let toSign = requestsVM.pendingRequests.filter { selectedIDs.contains($0.id) }
                isSelecting = false
                selectedIDs.removeAll()
                Task { await requestsVM.acceptMultipleRequests(toSign) }
            }
        } message: {
            Text("You will authenticate once with your PIN to sign \(selectedIDs.count) document\(selectedIDs.count > 1 ? "s" : ""). This cannot be undone.")
        }
    }
}

struct HistoryTabView: View {
    @EnvironmentObject var requestsVM: RequestsViewModel
    @State private var searchText   = ""
    @State private var filterState: FilterState = .all
    @State private var fromDate:    Date? = nil
    @State private var toDate:      Date? = nil
    @State private var showFromPicker = false
    @State private var showToPicker   = false

    enum FilterState: String, CaseIterable {
        case all      = "All"
        case accepted = "Accepted"
        case rejected = "Rejected"
    }

    private static func parseDate(_ raw: String) -> Date? {
        let fFrac = DateFormatter()
        fFrac.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSSSS"
        fFrac.locale = Locale(identifier: "en_US_POSIX")
        fFrac.timeZone = TimeZone(identifier: "Asia/Beirut")
        if let d = fFrac.date(from: raw) { return d }
        let fPlain = DateFormatter()
        fPlain.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        fPlain.locale = Locale(identifier: "en_US_POSIX")
        fPlain.timeZone = TimeZone(identifier: "Asia/Beirut")
        return fPlain.date(from: raw)
    }

    private static let displayFmt: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "dd/MM/yyyy  HH:mm"
        return f
    }()

    private var hasTimeFilter: Bool { fromDate != nil || toDate != nil }

    private var filtered: [SigningRequest] {
        requestsVM.historyRequests.filter { req in
            let matchesStatus: Bool = {
                switch filterState {
                case .all:      return true
                case .accepted: return req.status == "accepted"
                case .rejected: return req.status == "rejected"
                }
            }()
            let matchesSearch = searchText.isEmpty
                || String(req.id) == searchText.trimmingCharacters(in: .whitespaces)
            let matchesTime: Bool = {
                guard fromDate != nil || toDate != nil else { return true }
                guard let date = Self.parseDate(req.updatedAt) else { return true }
                if let from = fromDate, date < from { return false }
                if let to   = toDate,  date > to   { return false }
                return true
            }()
            return matchesStatus && matchesSearch && matchesTime
        }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.96, green: 0.97, blue: 0.98).ignoresSafeArea()

                VStack(spacing: 0) {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(FilterState.allCases, id: \.self) { state in
                                FilterPill(label: state.rawValue, isSelected: filterState == state) {
                                    filterState = state
                                }
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                    }
                    VStack(alignment: .leading, spacing: 8) {
                        HStack(spacing: 8) {
                            Button {
                                showFromPicker = true
                            } label: {
                                Text(fromDate.map { "From: \(Self.displayFmt.string(from: $0))" } ?? "From: Any")
                                    .font(.subheadline).fontWeight(.medium)
                                    .foregroundColor(fromDate != nil ? .blue : .primary)
                                    .padding(.horizontal, 12).padding(.vertical, 8)
                                    .frame(maxWidth: .infinity)
                                    .background(fromDate != nil ? Color.blue.opacity(0.1) : Color(UIColor.systemGray6))
                                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(fromDate != nil ? Color.blue.opacity(0.5) : Color.clear))
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                            }

                            Text("→")
                                .foregroundColor(.secondary)
                                .fontWeight(.medium)

                            Button {
                                showToPicker = true
                            } label: {
                                Text(toDate.map { "To: \(Self.displayFmt.string(from: $0))" } ?? "To: Any")
                                    .font(.subheadline).fontWeight(.medium)
                                    .foregroundColor(toDate != nil ? .blue : .primary)
                                    .padding(.horizontal, 12).padding(.vertical, 8)
                                    .frame(maxWidth: .infinity)
                                    .background(toDate != nil ? Color.blue.opacity(0.1) : Color(UIColor.systemGray6))
                                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(toDate != nil ? Color.blue.opacity(0.5) : Color.clear))
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                            }

                            if hasTimeFilter {
                                Button {
                                    fromDate = nil
                                    toDate   = nil
                                } label: {
                                    Image(systemName: "xmark")
                                        .font(.subheadline).fontWeight(.bold)
                                        .foregroundColor(.red)
                                        .padding(8)
                                        .background(Color.red.opacity(0.1))
                                        .clipShape(RoundedRectangle(cornerRadius: 10))
                                }
                            }
                        }
                        .padding(.horizontal, 16)

                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 8) {
                                ForEach([("Today", 0), ("Last 7 days", 7), ("Last 30 days", 30)], id: \.0) { label, days in
                                    Button {
                                        let cal = Calendar.current
                                        let now = Date()
                                        let endOfDay = cal.date(bySettingHour: 23, minute: 59, second: 59, of: now) ?? now
                                        let start: Date = days == 0
                                            ? cal.date(bySettingHour: 0, minute: 0, second: 0, of: now) ?? now
                                            : cal.date(byAdding: .day, value: -days, to: cal.date(bySettingHour: 0, minute: 0, second: 0, of: now) ?? now) ?? now
                                        fromDate = start
                                        toDate   = endOfDay
                                    } label: {
                                        Text(label)
                                            .font(.caption).fontWeight(.medium)
                                            .foregroundColor(.blue)
                                            .padding(.horizontal, 10).padding(.vertical, 5)
                                            .background(Color.blue.opacity(0.1))
                                            .clipShape(Capsule())
                                    }
                                }
                            }
                            .padding(.horizontal, 16)
                        }
                    }
                    .padding(.vertical, 10)
                    .background(Color(red: 0.96, green: 0.97, blue: 0.98))

                    ScrollView {
                        if requestsVM.isLoading && requestsVM.requests.isEmpty {
                            ProgressView("Loading history...")
                                .frame(maxWidth: .infinity).padding(.top, 60)
                        } else if filtered.isEmpty {
                            EmptyRequestsView(
                                message: !hasTimeFilter && searchText.isEmpty ? "No history yet" : "No results",
                                subtitle: !hasTimeFilter && searchText.isEmpty
                                    ? "Accepted and denied requests will appear here"
                                    : "Try adjusting your filter"
                            )
                            .frame(maxWidth: .infinity).padding(.top, 40)
                        } else {
                            LazyVStack(spacing: 14) {
                                ForEach(filtered) { req in
                                    HistoryCard(request: req)
                                }
                            }
                            .padding(16)
                        }
                    }
                }
            }
            .navigationTitle("History")
            .navigationBarTitleDisplayMode(.large)
            .searchable(text: $searchText, prompt: "Search by Request ID")
            .sheet(isPresented: $showFromPicker) {
                DateTimePickerSheet(
                    title: "From",
                    initial: fromDate,
                    endOfDay: false
                ) { picked in
                    fromDate = picked
                    showFromPicker = false
                } onCancel: {
                    showFromPicker = false
                }
                .id(showFromPicker)
            }
            .sheet(isPresented: $showToPicker) {
                DateTimePickerSheet(
                    title: "To",
                    initial: toDate,
                    endOfDay: true
                ) { picked in
                    toDate = picked
                    showToPicker = false
                } onCancel: {
                    showToPicker = false
                }
                .id(showToPicker)
            }
        }
    }
}

private struct DateTimePickerSheet: View {
    let title:    String
    let initial:  Date?
    let endOfDay: Bool
    let onPick:   (Date) -> Void
    let onCancel: () -> Void

    @State private var selectedDate: Date
    @State private var step: Int = 0  // 0 = date, 1 = time

    init(title: String, initial: Date?, endOfDay: Bool, onPick: @escaping (Date) -> Void, onCancel: @escaping () -> Void) {
        self.title    = title
        self.initial  = initial
        self.endOfDay = endOfDay
        self.onPick   = onPick
        self.onCancel = onCancel
        _selectedDate = State(initialValue: initial ?? Date())
    }

    var body: some View {
        NavigationStack {
            VStack {
                if step == 0 {
                    DatePicker(
                        "Select Date",
                        selection: $selectedDate,
                        displayedComponents: .date
                    )
                    .datePickerStyle(.graphical)
                    .padding()

                    Button("Next: Select Time") {
                        step = 1
                    }
                    .buttonStyle(.borderedProminent)
                    .padding()

                } else {
                    DatePicker(
                        "Select Time",
                        selection: $selectedDate,
                        displayedComponents: .hourAndMinute
                    )
                    .datePickerStyle(.wheel)
                    .labelsHidden()
                    .padding()

                    Button("Apply") {
                        let cal = Calendar.current
                        var finalDate = selectedDate
                        if endOfDay {
                            finalDate = cal.date(bySetting: .second, value: 59, of: selectedDate) ?? selectedDate
                        } else {
                            finalDate = cal.date(bySetting: .second, value: 0, of: selectedDate) ?? selectedDate
                        }
                        onPick(finalDate)
                    }
                    .buttonStyle(.borderedProminent)
                    .padding()

                    Button("Back") { step = 0 }
                        .padding(.bottom)
                }
            }
            .navigationTitle("\(title) Date & Time")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { onCancel() }
                }
            }
        }
    }
}

private struct RequestListView<Cards: View>: View {
    let title:         String
    let isEmpty:       Bool
    let isLoading:     Bool
    let loadingLabel:  String
    let emptyMessage:  String
    let emptySubtitle: String
    @Binding var errorMessage: String?
    let canSign:       Bool
    @Binding var isSelecting:  Bool
    @Binding var selectedIDs:  Set<Int>
    let onSelectToggle: () -> Void
    @ViewBuilder let cards: () -> Cards

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.96, green: 0.97, blue: 0.98).ignoresSafeArea()
                VStack(spacing: 0) {
                    if !canSign {
                        HStack(spacing: 10) {
                            Image(systemName: "lock.trianglebadge.exclamationmark.fill")
                                .foregroundColor(.orange)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Signing disabled on this device")
                                    .font(.subheadline).fontWeight(.semibold)
                                    .foregroundColor(.orange)
                                Text("This device is registered to another user.")
                                    .font(.caption).foregroundColor(.orange.opacity(0.85))
                            }
                        }
                        .padding(12)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.orange.opacity(0.12))
                        .overlay(Rectangle().frame(height: 1).foregroundColor(Color.orange.opacity(0.3)), alignment: .bottom)
                    }

                    ScrollView {
                        if isLoading {
                            ProgressView(loadingLabel)
                                .frame(maxWidth: .infinity).padding(.top, 60)
                        } else if isEmpty {
                            EmptyRequestsView(message: emptyMessage, subtitle: emptySubtitle)
                                .frame(maxWidth: .infinity).padding(.top, 60)
                        } else {
                            LazyVStack(spacing: 14) { cards() }.padding(16)
                        }
                    }
                }
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                if canSign && !isEmpty && !isLoading {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button(isSelecting ? "Cancel" : "Select") {
                            onSelectToggle()
                        }
                        .fontWeight(isSelecting ? .regular : .semibold)
                    }
                }
            }
            .alert("Error", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("OK") { errorMessage = nil }
            } message: {
                Text(errorMessage ?? "")
            }
        }
    }
}

struct RequestCard: View {
    let request:     SigningRequest
    let canSign:     Bool
    var isSelecting: Bool = false
    var isSelected:  Bool = false
    var onSelect:    (() -> Void)? = nil
    @EnvironmentObject var requestsVM: RequestsViewModel
    @State private var isAccepting     = false
    @State private var isRejecting     = false
    @State private var showFullContent = false

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                if isSelecting {
                    Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                        .foregroundColor(isSelected ? .blue : .secondary)
                        .font(.system(size: 22))
                        .onTapGesture { onSelect?() }
                }

                Text("REQ-\(request.id)").font(.caption).fontWeight(.bold).foregroundColor(.blue)
                Spacer()
                StatusBadge(status: request.status)
            }

            ContentToggle(content: request.content, summary: request.summary, showFull: $showFullContent)

            Text(request.formattedDate).font(.caption).foregroundColor(.secondary)

            if !isSelecting {
                Divider()

                HStack(spacing: 12) {
                    ActionButton(label: "Deny", loadingLabel: "Denying...", icon: "xmark.circle.fill",
                                 color: .red, isLoading: isRejecting, isDisabled: isAccepting || isRejecting || !canSign) {
                        Task { isRejecting = true; await requestsVM.rejectRequest(request); isRejecting = false }
                    }

                    ActionButton(
                        label:        canSign ? "Sign" : "Cannot Sign",
                        loadingLabel: "Signing...",
                        icon:         canSign ? "signature" : "lock.fill",
                        color:        canSign ? .green : .gray,
                        isLoading:    isAccepting,
                        isDisabled:   isAccepting || isRejecting || !canSign
                    ) {
                        Task {
                            isAccepting = true
                            await requestsVM.acceptRequest(request)
                            isAccepting = false
                        }
                    }
                }
            }
        }
        .padding(16)
        .cardStyle()
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(isSelected ? Color.blue : Color.clear, lineWidth: 2)
        )
        .contentShape(Rectangle())
        .onTapGesture {
            if isSelecting { onSelect?() }
        }
    }
}

struct HistoryCard: View {
    let request: SigningRequest
    @State private var showFullContent = false

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("REQ-\(request.id)").font(.caption).fontWeight(.bold).foregroundColor(.blue)
                Spacer()
                StatusBadge(status: request.status)
            }

            HistoryContentToggle(content: request.content, showFull: $showFullContent)

            Divider()

            VStack(alignment: .leading, spacing: 6) {
                DateRow(icon: "calendar", label: "Submitted", value: request.formattedDate)
                DateRow(icon: "clock",    label: "Decision",  value: request.formattedUpdatedDate)
            }
        }
        .padding(16).cardStyle()
    }
}

private struct ContentToggle: View {
    let content:  String
    let summary:  String
    @Binding var showFull: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(showFull ? content : summary)
                .font(.subheadline)
                .fixedSize(horizontal: false, vertical: showFull)
                .lineLimit(showFull ? nil : 3)
            if content != summary {
                Button { withAnimation { showFull.toggle() } } label: {
                    Text(showFull ? "Show less" : "Show more").font(.caption).foregroundColor(.blue)
                }
            }
        }
    }
}

private struct HistoryContentToggle: View {
    let content: String
    @Binding var showFull: Bool

    private var preview: String {
        content.count > 15 ? String(content.prefix(15)) + "..." : content
    }
    private var needsToggle: Bool { content.count > 15 }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(showFull ? content : preview)
                .font(.subheadline)
                .fixedSize(horizontal: false, vertical: showFull)
            if needsToggle {
                Button { withAnimation { showFull.toggle() } } label: {
                    Text(showFull ? "Show less" : "Show more").font(.caption).foregroundColor(.blue)
                }
            }
        }
    }
}

private struct ActionButton: View {
    let label:        String
    let loadingLabel: String
    let icon:         String
    let color:        Color
    let isLoading:    Bool
    let isDisabled:   Bool
    let action:       () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                if isLoading { ProgressView().tint(.white).scaleEffect(0.8) }
                else { Image(systemName: icon) }
                Text(isLoading ? loadingLabel : label).fontWeight(.semibold)
            }
            .frame(maxWidth: .infinity)
            .padding(12)
            .background(isDisabled ? Color(UIColor.systemGray4) : color)
            .foregroundColor(isDisabled ? Color(UIColor.systemGray) : .white)
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .disabled(isDisabled)
    }
}

private struct DateRow: View {
    let icon:  String
    let label: String
    let value: String

    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: icon).font(.caption).foregroundColor(.secondary).frame(width: 14)
            Text(label).font(.caption).foregroundColor(.secondary)
            Spacer()
            Text(value).font(.caption).fontWeight(.medium)
        }
    }
}

private struct FilterPill: View {
    let label:      String
    let isSelected: Bool
    var color:      Color = .blue
    let action:     () -> Void

    var body: some View {
        Button(action: action) {
            Text(label)
                .font(.subheadline).fontWeight(.semibold)
                .padding(.horizontal, 14).padding(.vertical, 7)
                .background(isSelected ? color : Color(UIColor.systemGray5))
                .foregroundColor(isSelected ? .white : .primary)
                .clipShape(Capsule())
        }
    }
}

struct StatusBadge: View {
    let status: String

    private var color: Color {
        switch status {
        case "accepted": return Color(red: 0.08, green: 0.50, blue: 0.24)
        case "rejected": return Color(red: 0.73, green: 0.11, blue: 0.11)
        default:         return Color(red: 0.72, green: 0.47, blue: 0.12)
        }
    }

    var body: some View {
        Text(status.uppercased())
            .font(.caption2).fontWeight(.bold)
            .foregroundColor(.white)
            .padding(.horizontal, 10).padding(.vertical, 5)
            .background(color)
            .clipShape(Capsule())
    }
}

struct EmptyRequestsView: View {
    let message:  String
    let subtitle: String

    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "tray").font(.system(size: 48)).foregroundColor(.secondary)
            Text(message).font(.title3).fontWeight(.semibold)
            Text(subtitle).font(.subheadline).foregroundColor(.secondary).multilineTextAlignment(.center)
        }
        .padding()
    }
}

private extension View {
    func cardStyle() -> some View {
        background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .shadow(color: .black.opacity(0.06), radius: 8, x: 0, y: 4)
    }
}
