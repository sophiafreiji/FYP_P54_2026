import SwiftUI

enum AuthScreen {
    case choice
    case login
    case signup
    case backupCodes(codes: [String])
    case recover
    case forgotPassword
    case verificationSent(email: String)
}

struct AuthView: View {
    @EnvironmentObject var authVM: AuthViewModel
    @State private var screen:    AuthScreen = .choice
    @State private var codesGoToApp = false

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.96, green: 0.97, blue: 0.98).ignoresSafeArea()
                ScrollView {
                    VStack(spacing: 0) {
                        VStack(spacing: 10) {
                            Image(systemName: "lock.shield.fill")
                                .font(.system(size: 44)).foregroundColor(.blue)
                            Text("Secure Signing")
                                .font(.title2).fontWeight(.bold)
                            Text("Fast • Safe • Verified")
                                .font(.subheadline).foregroundColor(.secondary)
                        }
                        .padding(.top, 40).padding(.bottom, 30)

                        Group {
                            switch screen {
                            case .choice:
                                ChoiceScreen(screen: $screen, codesGoToApp: $codesGoToApp)
                            case .login:
                                LoginScreen(screen: $screen, codesGoToApp: $codesGoToApp)
                            case .signup:
                                SignupScreen(screen: $screen)
                            case .backupCodes:
                                EmptyView()
                            case .recover:
                                RecoverScreen(screen: $screen)
                            case .forgotPassword:
                                ForgotPasswordScreen(screen: $screen)
                            case .verificationSent(let email):
                                VerificationSentScreen(email: email, screen: $screen)
                            }
                        }
                        .padding(28)
                        .background(Color.white)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .shadow(color: .black.opacity(0.08), radius: 20, x: 0, y: 8)
                        .padding(.horizontal, 20)
                        .padding(.bottom, 40)
                    }
                }
            }
        }
        .fullScreenCover(
            isPresented: Binding(
                get: { if case .backupCodes = screen { return true }; return false },
                set: { _ in }
            )
        ) {
            if case .backupCodes(let codes) = screen {
                BackupCodesView(
                    codes: codes,
                    goToApp: codesGoToApp,
                    onDone: {
                        if codesGoToApp {
                            authVM.isConfirmedLoggedIn = true
                        } else {
                            screen = .login
                        }
                    },
                    onRequestCert: codesGoToApp ? nil : {
                        await authVM.requestCertificateIfNeeded()
                    }
                )
            }
        }
        .onAppear {
            if authVM.sessionExpiredMessage != nil {
                screen = .choice
            }
        }
    }
}

struct ChoiceScreen: View {
    @Binding var screen: AuthScreen
    @Binding var codesGoToApp: Bool
    @EnvironmentObject var authVM: AuthViewModel
    @State private var isGoogleLoading = false

    var body: some View {
        VStack(spacing: 12) {
            AuthButton(title: "Sign Up", style: .primary)  { screen = .signup }
            AuthButton(title: "Login",   style: .secondary) { screen = .login  }

            Divider().padding(.vertical, 4)

            GoogleButton(label: "Continue with Google", isLoading: isGoogleLoading) {
                Task {
                    isGoogleLoading = true
                    if let codes = await authVM.signInWithGoogle(), !codes.isEmpty {
                        codesGoToApp = true
                        screen = .backupCodes(codes: codes)
                    }
                    isGoogleLoading = false
                }
            }

            Divider().padding(.vertical, 4)

            Button { screen = .recover } label: {
                Text("Recover Blacklisted Account")
                    .font(.subheadline).fontWeight(.semibold)
                    .foregroundColor(.red)
                    .frame(maxWidth: .infinity).padding()
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.red))
            }

            if let expiredMsg = authVM.sessionExpiredMessage {
                HStack(spacing: 8) {
                    Image(systemName: "clock.badge.exclamationmark")
                        .foregroundColor(.orange)
                    Text(expiredMsg)
                        .font(.subheadline)
                        .foregroundColor(.orange)
                        .multilineTextAlignment(.leading)
                }
                .padding(12)
                .background(Color.orange.opacity(0.1))
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.orange.opacity(0.4)))
            }

            if let err = authVM.errorMessage {
                StatusLabel(text: err, isError: true)
            }
        }
    }
}

struct LoginScreen: View {
    @Binding var screen: AuthScreen
    @Binding var codesGoToApp: Bool
    @EnvironmentObject var authVM: AuthViewModel
    @State private var email     = ""
    @State private var password  = ""
    @State private var isLoading = false

    var body: some View {
        VStack(spacing: 14) {
            AuthScreenTitle("Login")
            AuthTextField(placeholder: "Email", text: $email, keyboard: .emailAddress)
            PasswordField(placeholder: "Password", text: $password)

            HStack(spacing: 10) {
                AuthButton(title: isLoading ? "Logging in..." : "Login", style: .primary) {
                    Task {
                        isLoading = true
                        if let codes = await authVM.login(email: email, password: password), !codes.isEmpty {
                            codesGoToApp = true
                            screen = .backupCodes(codes: codes)
                        }
                        isLoading = false
                    }
                }
                .disabled(isLoading || email.isEmpty || password.isEmpty)

                AuthButton(title: "Back", style: .secondary) {
                    authVM.clearMessages(); screen = .choice
                }
            }

            Button { screen = .forgotPassword } label: {
                Text("Forgot password?")
                    .font(.footnote).foregroundColor(.blue)
                    .frame(maxWidth: .infinity, alignment: .trailing)
            }

            if let err = authVM.errorMessage { StatusLabel(text: err, isError: true) }
        }
    }
}

struct SignupScreen: View {
    @Binding var screen: AuthScreen
    @EnvironmentObject var authVM: AuthViewModel
    @State private var email           = ""
    @State private var password        = ""
    @State private var confirmPassword = ""
    @State private var isLoading       = false

    private var passwordsMatch: Bool { !confirmPassword.isEmpty && password == confirmPassword }

    private var hasMinLength:  Bool { password.count >= 8 }
    private var hasUppercase:  Bool { password.contains(where: { $0.isUppercase }) }
    private var hasLowercase:  Bool { password.contains(where: { $0.isLowercase }) }
    private var hasNumber:     Bool { password.contains(where: { $0.isNumber }) }
    private var hasSpecial:    Bool {
        let special = CharacterSet(charactersIn: "!@#$%^&*()_+-=[]{}|;':\",./<>?")
        return password.unicodeScalars.contains(where: { special.contains($0) })
    }
    private var isPasswordValid: Bool { hasMinLength && hasUppercase && hasLowercase && hasNumber && hasSpecial }

    var body: some View {
        VStack(spacing: 14) {
            AuthScreenTitle("Create Account")
            AuthTextField(placeholder: "Email", text: $email, keyboard: .emailAddress)
            PasswordField(placeholder: "Password", text: $password)

            if !password.isEmpty {
                VStack(alignment: .leading, spacing: 4) {
                    PasswordRequirement(label: "At least 8 characters", met: hasMinLength)
                    PasswordRequirement(label: "One uppercase letter",  met: hasUppercase)
                    PasswordRequirement(label: "One lowercase letter",  met: hasLowercase)
                    PasswordRequirement(label: "One number",            met: hasNumber)
                    PasswordRequirement(label: "One special character", met: hasSpecial)
                }
                .padding(.horizontal, 4)
            }

            VStack(alignment: .leading, spacing: 4) {
                PasswordField(placeholder: "Confirm Password", text: $confirmPassword)
                if !confirmPassword.isEmpty {
                    Text(passwordsMatch ? "Passwords match" : "Passwords do not match")
                        .font(.caption)
                        .foregroundColor(passwordsMatch ? .green : .red)
                }
            }

            HStack(spacing: 10) {
                AuthButton(title: isLoading ? "Signing up..." : "Sign Up", style: .primary) {
                    Task {
                        isLoading = true
                        await authVM.signUp(email: email, password: password)
                        isLoading = false
                        if let email = authVM.successMessage {
                            authVM.clearMessages()
                            screen = .verificationSent(email: email)
                        }
                    }
                }
                .disabled(isLoading || email.isEmpty || !passwordsMatch || !isPasswordValid)

                AuthButton(title: "Back", style: .secondary) {
                    authVM.clearMessages(); screen = .choice
                }
            }

            if let err = authVM.errorMessage { StatusLabel(text: err, isError: true) }
        }
    }
}

private struct PasswordRequirement: View {
    let label: String
    let met:   Bool

    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: met ? "checkmark.circle.fill" : "circle")
                .font(.caption)
                .foregroundColor(met ? .green : Color(UIColor.systemGray3))
            Text(label)
                .font(.caption)
                .foregroundColor(met ? .primary : .secondary)
        }
    }
}
struct RecoverScreen: View {
    @Binding var screen: AuthScreen
    @EnvironmentObject var authVM: AuthViewModel
    @State private var useGoogle    = false
    @State private var email        = ""
    @State private var password     = ""
    @State private var backupKeyEmail  = ""
    @State private var backupKeyGoogle = ""
    @State private var isLoading    = false

    var body: some View {
        VStack(spacing: 14) {
            AuthScreenTitle("Recover Account")

            HStack(spacing: 0) {
                toggleTab(label: "System", selected: !useGoogle) {
                    useGoogle = false
                    authVM.clearMessages()
                }
                toggleTab(label: "Google", selected: useGoogle) {
                    useGoogle = true
                    authVM.clearMessages()
                }
            }
            .background(Color(UIColor.systemGray6))
            .clipShape(RoundedRectangle(cornerRadius: 10))

            if useGoogle {
                Text("Enter a backup key, then sign in with Google")
                    .font(.footnote).foregroundColor(.secondary).multilineTextAlignment(.leading)

                BackupKeyField(value: $backupKeyGoogle)

            } else {
                Text("Enter your credentials and a backup keys to restore your account.")
                    .font(.footnote).foregroundColor(.secondary).multilineTextAlignment(.leading)
                AuthTextField(placeholder: "Email", text: $email, keyboard: .emailAddress)
                PasswordField(placeholder: "Password", text: $password)

                BackupKeyField(value: $backupKeyEmail)
            }

            if let err = authVM.errorMessage { StatusLabel(text: err, isError: true) }
            if let ok  = authVM.successMessage { StatusLabel(text: ok, isError: false) }

            if authVM.successMessage == nil {
                HStack(spacing: 10) {
                    if useGoogle {
                        GoogleButton(label: "Recover", isLoading: isLoading) {
                            Task {
                                isLoading = true
                                await authVM.recoverAccountGoogle(
                                    backupKey: formatBackupKey(backupKeyGoogle)
                                )
                                isLoading = false
                            }
                        }
                        .disabled(backupKeyGoogle.count < 12)
                    } else {
                        AuthButton(title: isLoading ? "Recovering..." : "Recover", style: .primary) {
                            Task {
                                isLoading = true
                                await authVM.recoverAccount(
                                    email: email, password: password,
                                    backupKey: formatBackupKey(backupKeyEmail)
                                )
                                isLoading = false
                            }
                        }
                        .disabled(isLoading || email.isEmpty || password.isEmpty || backupKeyEmail.count < 12)
                    }

                    AuthButton(title: "Back", style: .secondary) {
                        authVM.clearMessages(); screen = .choice
                    }
                }
            }
        }
        .onChange(of: authVM.successMessage) {
            guard authVM.successMessage != nil else { return }
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                authVM.clearMessages()
                screen = .choice
            }
        }
    }

    private func toggleTab(label: String, selected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(label)
                .font(.subheadline).fontWeight(.semibold)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
                .background(selected ? Color.white : Color.clear)
                .foregroundColor(selected ? .primary : .secondary)
                .clipShape(RoundedRectangle(cornerRadius: 8))
                .padding(2)
        }
    }
}

struct ForgotPasswordScreen: View {
    @Binding var screen: AuthScreen
    @EnvironmentObject var authVM: AuthViewModel
    @State private var email       = ""
    @State private var backupKey   = ""
    @State private var newPassword = ""
    @State private var confirmNew  = ""
    @State private var isLoading   = false

    private var passwordsMatch: Bool { !confirmNew.isEmpty && newPassword == confirmNew }

    var body: some View {
        VStack(spacing: 14) {
            AuthScreenTitle("Reset Password")

            AuthTextField(placeholder: "Email", text: $email, keyboard: .emailAddress)
            BackupKeyField(value: $backupKey)
            PasswordField(placeholder: "New Password", text: $newPassword)

            VStack(alignment: .leading, spacing: 4) {
                PasswordField(placeholder: "Confirm New Password", text: $confirmNew)
                if !confirmNew.isEmpty {
                    Text(passwordsMatch ? "Passwords match" : "Passwords do not match")
                        .font(.caption).foregroundColor(passwordsMatch ? .green : .red)
                }
            }

            if let err = authVM.errorMessage  { StatusLabel(text: err, isError: true)  }
            if let ok  = authVM.successMessage {
                StatusLabel(text: ok, isError: false)
                AuthButton(title: "Go to Login", style: .primary) {
                    authVM.clearMessages(); screen = .login
                }
            }

            if authVM.successMessage == nil {
                HStack(spacing: 10) {
                    AuthButton(title: isLoading ? "Resetting..." : "Reset Password", style: .primary) {
                        Task {
                            isLoading = true
                            await authVM.resetPassword(
                                email: email,
                                backupKey: formatBackupKey(backupKey),
                                newPassword: newPassword
                            )
                            isLoading = false
                        }
                    }
                    .disabled(isLoading || email.isEmpty || backupKey.count < 12 || !passwordsMatch)

                    AuthButton(title: "Back", style: .secondary) {
                        authVM.clearMessages(); screen = .login
                    }
                }
            }
        }
        .onChange(of: authVM.successMessage) {
            guard authVM.successMessage != nil else { return }
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                authVM.clearMessages()
                screen = .login
            }
        }
    }
}

struct VerificationSentScreen: View {
    let email: String
    @Binding var screen: AuthScreen
    @EnvironmentObject var authVM: AuthViewModel

    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "envelope.badge.fill")
                .font(.system(size: 48)).foregroundColor(.blue)
            Text("Verify Your Email").font(.title3).fontWeight(.bold)
            Text("A verification link has been sent to:")
                .font(.subheadline).foregroundColor(.secondary)
            Text(email).font(.subheadline).fontWeight(.bold).foregroundColor(.blue)
            Text("Please check your inbox and click the link before logging in.")
                .font(.subheadline).foregroundColor(.secondary).multilineTextAlignment(.center)
            AuthButton(title: "Go to Login", style: .primary) {
                authVM.clearMessages(); screen = .login
            }
        }
    }
}

struct AuthScreenTitle: View {
    let title: String
    init(_ title: String) { self.title = title }
    var body: some View {
        Text(title)
            .font(.title3).fontWeight(.bold)
            .frame(maxWidth: .infinity, alignment: .leading)
    }
}

private func formatBackupKey(_ raw: String) -> String {
    let r = raw.uppercased().filter { $0.isLetter || $0.isNumber }.prefix(12)
    guard r.count == 12 else { return String(r) }
    let s = String(r)
    return "\(s.prefix(4))-\(s.dropFirst(4).prefix(4))-\(s.dropFirst(8))"
}

struct BackupKeyField: View {
    @Binding var value: String
    @State private var displayed: String = ""
    @State private var isUpdating = false

    var body: some View {
        TextField("Backup Key", text: $displayed)
            .textFieldStyle(AuthTextFieldStyle())
            .autocorrectionDisabled()
            .textInputAutocapitalization(.characters)
            .keyboardType(.asciiCapable)
            .onChange(of: displayed) { _, newVal in
                guard !isUpdating else { return }
                isUpdating = true

                let raw = String(newVal
                    .uppercased()
                    .filter { $0.isLetter || $0.isNumber }
                    .prefix(12))

                var formatted = ""
                for (i, ch) in raw.enumerated() {
                    if i == 4 || i == 8 { formatted += "-" }
                    formatted += String(ch)
                }

                if displayed != formatted {
                    displayed = formatted
                }
                
                value = raw

                isUpdating = false
            }
    }
}

struct AuthTextField: View {
    let placeholder: String
    @Binding var text: String
    var keyboard: UIKeyboardType = .default

    var body: some View {
        TextField(placeholder, text: $text)
            .textFieldStyle(AuthTextFieldStyle())
            .keyboardType(keyboard)
            .autocapitalization(.none)
            .autocorrectionDisabled()
    }
}

struct PasswordField: View {
    let placeholder: String
    @Binding var text: String
    @State private var isVisible = false

    var body: some View {
        HStack {
            Group {
                if isVisible {
                    TextField(placeholder, text: $text)
                        .autocapitalization(.none).autocorrectionDisabled()
                } else {
                    SecureField(placeholder, text: $text)
                }
            }
            .padding(14)
            Button { isVisible.toggle() } label: {
                Image(systemName: isVisible ? "eye.slash" : "eye").foregroundColor(.secondary)
            }
            .padding(.trailing, 14)
        }
        .background(Color(UIColor.systemGray6))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

struct AuthTextFieldStyle: TextFieldStyle {
    func _body(configuration: TextField<_Label>) -> some View {
        configuration
            .padding(14)
            .background(Color(UIColor.systemGray6))
            .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

enum AuthButtonStyle { case primary, secondary }

struct AuthButton: View {
    let title: String
    let style: AuthButtonStyle
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .fontWeight(.semibold)
                .frame(maxWidth: .infinity)
                .padding(14)
                .background(style == .primary ? Color.blue : Color(UIColor.systemGray5))
                .foregroundColor(style == .primary ? .white : .primary)
                .clipShape(RoundedRectangle(cornerRadius: 14))
        }
    }
}

struct GoogleButton: View {
    let label: String
    let isLoading: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 10) {
                Text("G")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(.blue)
                    .frame(width: 20, height: 20)
                Text(isLoading ? "Processing..." : label).fontWeight(.semibold)
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color.white)
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color(UIColor.systemGray4)))
            .clipShape(RoundedRectangle(cornerRadius: 14))
        }
        .disabled(isLoading)
    }
}

struct StatusLabel: View {
    let text: String
    let isError: Bool

    var body: some View {
        Text(text)
            .font(.subheadline).fontWeight(.semibold)
            .foregroundColor(isError ? .red : .blue)
            .multilineTextAlignment(.center)
            .padding(.top, 4)
    }
}
