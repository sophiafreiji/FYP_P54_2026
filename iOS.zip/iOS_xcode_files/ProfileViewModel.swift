import Foundation
import FirebaseAuth

@MainActor
class ProfileViewModel: ObservableObject {
    @Published var profile:      UserProfile?
    @Published var isLoading     = false
    @Published var errorMessage: String?

    func fetchProfile() async {
        guard let user = Auth.auth().currentUser else { return }
        isLoading = true
        errorMessage = nil
        do {
            profile = try await APIService.shared.getProfile(token: try await user.getIDToken())
        } catch let e as APIError {
            errorMessage = e.message
        } catch {
            errorMessage = "Failed to load profile."
        }
        isLoading = false
    }
}
