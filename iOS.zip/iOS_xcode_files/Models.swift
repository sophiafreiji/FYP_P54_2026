import Foundation

struct UserProfile: Codable, Identifiable {
    let id:              Int
    let firebaseUid:     String
    let email:           String?
    let username:        String
    let provider:        String?
    let providerDisplay: String
    let avatarLetter:    String
    let displayName:     String?
    let isBlacklisted:   Bool
    let blacklistedAt:   String?
    let createdAt:       String

    enum CodingKeys: String, CodingKey {
        case id
        case firebaseUid     = "firebase_uid"
        case email, username, provider
        case providerDisplay = "provider_display"
        case avatarLetter    = "avatar_letter"
        case displayName     = "display_name"
        case isBlacklisted   = "is_blacklisted"
        case blacklistedAt   = "blacklisted_at"
        case createdAt       = "created_at"
    }
}

struct SigningRequest: Codable, Identifiable {
    let id:        Int
    let content:   String
    let summary:   String
    let status:    String
    let createdAt: String
    let updatedAt: String

    enum CodingKeys: String, CodingKey {
        case id, content, summary, status
        case createdAt = "created_at"
        case updatedAt = "updated_at"
    }

    var formattedDate:        String { Self.format(createdAt) }
    var formattedUpdatedDate: String { Self.format(updatedAt) }

    private static let displayFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "dd/MM/yyyy - HH:mm:ss"
        f.locale = Locale(identifier: "en_GB")
        return f
    }()

    private static let isoParserFractional: ISO8601DateFormatter = {
        let f = ISO8601DateFormatter()
        f.timeZone = TimeZone(identifier: "Asia/Beirut")
        f.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return f
    }()
    private static let isoParserPlain: ISO8601DateFormatter = {
        let f = ISO8601DateFormatter()
        f.timeZone = TimeZone(identifier: "Asia/Beirut")
        f.formatOptions = [.withInternetDateTime]
        return f
    }()
    private static let isoParserManual: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSSSS"
        f.locale = Locale(identifier: "en_US_POSIX")
        f.timeZone = TimeZone(identifier: "Asia/Beirut")
        return f
    }()
    private static let isoParserManualNoFrac: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        f.locale = Locale(identifier: "en_US_POSIX")
        f.timeZone = TimeZone(identifier: "Asia/Beirut")
        return f
    }()

    private static func format(_ raw: String) -> String {
        let date = isoParserFractional.date(from: raw)
            ?? isoParserPlain.date(from: raw)
            ?? isoParserManual.date(from: raw)
            ?? isoParserManualNoFrac.date(from: raw)
        if let date {
            return displayFormatter.string(from: date)
        }
        return raw
    }
}

struct ProfileResponse:  Codable { let status: String; let profile: UserProfile }
struct RequestsResponse: Codable { let status: String; let requests: [SigningRequest] }
struct GenericResponse:  Codable { let status: String; let message: String? }

struct RegisterResponse: Codable {
    let status:        String
    let sessionToken:  String
    let backupCodes:   [String]
    enum CodingKeys: String, CodingKey {
        case status
        case sessionToken = "session_token"
        case backupCodes  = "backup_codes"
    }
}

struct RecoverResponse: Codable {
    let status:       String
    let message:      String?
    let sessionToken: String?
    enum CodingKeys: String, CodingKey {
        case status, message
        case sessionToken = "session_token"
    }
}

struct CertificateResponse: Codable {
    let status:       String
    let certificate:  String?
    let serialNumber: String?
    let issuedAt:     String?
    let expiresAt:    String?
    enum CodingKeys: String, CodingKey {
        case status, certificate
        case serialNumber = "serial_number"
        case issuedAt     = "issued_at"
        case expiresAt    = "expires_at"
    }
}

struct SignatureResponse: Codable {
    let status:       String
    let pkcs7B64:     String?
    let contentHash:  String?
    let verified:     Bool?
    let signedAt:     String?
    let certificate:  String?
    let serialNumber: String?
    let expiresAt:    String?
    enum CodingKeys: String, CodingKey {
        case status, verified, certificate
        case pkcs7B64    = "pkcs7_b64"
        case contentHash = "content_hash"
        case signedAt    = "signed_at"
        case serialNumber = "serial_number"
        case expiresAt   = "expires_at"
    }
}

struct ImportCertResponse: Codable {
    let status:       String
    let serialNumber: String
    let expiresAt:    String
    enum CodingKeys: String, CodingKey {
        case status
        case serialNumber = "serial_number"
        case expiresAt    = "expires_at"
    }
}
