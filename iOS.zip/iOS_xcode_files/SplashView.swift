import SwiftUI

struct SplashView: View {
    let serverUnavailable: Bool
    var onRetry: (() -> Void)?
    @State private var isRetrying = false

    var body: some View {
        ZStack {
            Color(red: 0.07, green: 0.09, blue: 0.16).ignoresSafeArea()
            VStack(spacing: 24) {
                Image(systemName: "lock.shield.fill")
                    .font(.system(size: 56)).foregroundColor(.white)
                Text("Secure Signing Portal")
                    .font(.title2).fontWeight(.bold).foregroundColor(.white)

                if serverUnavailable {
                    serverUnavailableContent
                } else {
                    ProgressView().tint(.white).padding(.top, 8)
                    Text("Connecting...")
                        .font(.subheadline).foregroundColor(.white.opacity(0.5))
                }
            }
            .padding(32)
        }
    }

    private var serverUnavailableContent: some View {
        VStack(spacing: 16) {
            Image(systemName: "server.rack")
                .font(.system(size: 36)).foregroundColor(.red.opacity(0.8))
            Text("Servers Unavailable")
                .font(.headline).fontWeight(.bold).foregroundColor(.red.opacity(0.9))
            Text("The server is currently unreachable.\nPlease try again later.")
                .font(.subheadline).foregroundColor(.white.opacity(0.6))
                .multilineTextAlignment(.center)

            PulsingDotsView().padding(.top, 4)

            Button {
                guard !isRetrying else { return }
                isRetrying = true
                onRetry?()
                DispatchQueue.main.asyncAfter(deadline: .now() + 5.5) { isRetrying = false }
            } label: {
                HStack(spacing: 8) {
                    if isRetrying { ProgressView().tint(.white).scaleEffect(0.8) }
                    else { Image(systemName: "arrow.clockwise") }
                    Text(isRetrying ? "Connecting..." : "Retry Now").fontWeight(.semibold)
                }
                .foregroundColor(.white)
                .padding(.horizontal, 28).padding(.vertical, 12)
                .background(isRetrying ? Color.gray.opacity(0.5) : Color.red.opacity(0.7))
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            .disabled(isRetrying)
            .padding(.top, 8)
        }
    }
}

struct PulsingDotsView: View {
    @State private var animating = false

    var body: some View {
        HStack(spacing: 8) {
            ForEach(0..<3, id: \.self) { i in
                Circle()
                    .fill(Color.white.opacity(0.5))
                    .frame(width: 8, height: 8)
                    .scaleEffect(animating ? 1.0 : 0.4)
                    .animation(.easeInOut(duration: 0.6).repeatForever().delay(Double(i) * 0.2), value: animating)
            }
        }
        .onAppear { animating = true }
    }
}
