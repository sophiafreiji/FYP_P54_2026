import Foundation
import UIKit

struct APIError: Error {
    let message: String
}

class APIService {
    static let shared = APIService()

    // Change to your backend URL or IP or localhost (if running on the emulator)
    let baseURL = "https://<your backend IP>:8000"

    private(set) var sessionToken: String? = nil

    private init() {}

    func setSessionToken(_ token: String?) { sessionToken = token }

    func getProfile(token: String) async throws -> UserProfile {
        let data = try await request(path: "/profile", method: "GET", token: token)
        return try JSONDecoder().decode(ProfileResponse.self, from: data).profile
    }

    func getRequests(token: String) async throws -> [SigningRequest] {
        let data = try await request(path: "/requests", method: "GET", token: token)
        return try JSONDecoder().decode(RequestsResponse.self, from: data).requests
    }

    func updateRequestStatus(requestId: Int, status: String, token: String) async throws {
        _ = try await request(
            path: "/requests/\(requestId)/status",
            method: "PATCH",
            token: token,
            body: ["status": status]
        )
    }

    func requestCertificate(csrPEM: String, token: String, force: Bool = false) async throws -> String {
        let data = try await request(
            path: "/request-certificate",
            method: "POST",
            token: token,
            body: ["csr_pem": csrPEM, "force": force ? "true" : "false"]
        )
        struct Resp: Codable { let status: String; let certificate: String }
        return try JSONDecoder().decode(Resp.self, from: data).certificate
    }

    func getCertificate(token: String) async throws -> CertificateResponse {
        let data = try await request(path: "/certificate", method: "GET", token: token)
        return try JSONDecoder().decode(CertificateResponse.self, from: data)
    }

    func validateCertificate(token: String) async throws -> Bool {
        struct ValidateResponse: Codable {
            let valid: Bool
            let reason: String?
        }
        let data = try await request(path: "/validate-certificate", method: "GET", token: token)
        let resp = try JSONDecoder().decode(ValidateResponse.self, from: data)
        return resp.valid
    }

    func isCertificateRevoked(serial: String, token: String) async throws -> Bool {
        struct RevokedResponse: Codable { let revoked: Bool }
        let data = try await request(path: "/certificate/is-revoked?serial=\(serial)", method: "GET", token: token)
        let resp = try JSONDecoder().decode(RevokedResponse.self, from: data)
        return resp.revoked
    }

    func revokeMyCertificate(token: String) async throws {
        _ = try await request(path: "/revoke-my-certificate", method: "POST", token: token)
    }

    func importCertificate(certPEM: String, token: String) async throws -> ImportCertResponse {
        let data = try await request(
            path:   "/import-certificate",
            method: "POST",
            token:  token,
            body:   ["cert_pem": certPEM]
        )
        return try JSONDecoder().decode(ImportCertResponse.self, from: data)
    }

    func submitSignature(requestId: Int, pkcs7B64: String, contentHash: String, token: String, signatureFormat: String = "pkcs7") async throws -> Int {
        let data = try await request(
            path: "/submit-signature",
            method: "POST",
            token: token,
            body: [
                "request_id":       String(requestId),
                "pkcs7_b64":        pkcs7B64,
                "content_hash":     contentHash,
                "signature_format": signatureFormat
            ]
        )
        struct Resp: Codable { let status: String; let signature_id: Int }
        return try JSONDecoder().decode(Resp.self, from: data).signature_id
    }

    func registerUser(token: String) async throws -> RegisterResponse {
        let previous = sessionToken
        sessionToken = nil
        defer { sessionToken = previous }
        let data = try await request(path: "/register", method: "POST", token: token)
        return try JSONDecoder().decode(RegisterResponse.self, from: data)
    }

    func reportCompromised(token: String) async throws {
        _ = try await request(path: "/report-compromised", method: "POST", token: token)
    }

    func logout(token: String) async throws {
        _ = try await request(path: "/logout", method: "POST", token: token)
    }

    func recoverAccount(token: String, backupKey: String) async throws -> RecoverResponse {
        let data = try await request(
            path: "/recover-account",
            method: "POST",
            token: token,
            body: ["backup_key": backupKey]
        )
        return try JSONDecoder().decode(RecoverResponse.self, from: data)
    }

    func resetPassword(email: String, backupKey: String, newPassword: String) async throws -> String {
        let data = try await request(
            path: "/reset-password",
            method: "POST",
            token: "",
            body: ["email": email, "backup_key": backupKey, "new_password": newPassword]
        )
        return (try? JSONDecoder().decode(GenericResponse.self, from: data).message) ?? "Password reset successfully."
    }

    func checkConnectivity() async throws {
        _ = try await request(path: "/", method: "GET", token: "")
    }

    private func request(
        path: String,
        method: String,
        token: String,
        body: [String: String]? = nil
    ) async throws -> Data {
        guard let url = URL(string: baseURL + path) else {
            throw APIError(message: "Invalid URL.")
        }

        var req = URLRequest(url: url)
        req.httpMethod    = method
        req.timeoutInterval = 10
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("mobile", forHTTPHeaderField: "X-Platform")
        req.setValue(deviceInfo(), forHTTPHeaderField: "X-Device-Info")

        if !token.isEmpty {
            req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        if let session = sessionToken {
            req.setValue(session, forHTTPHeaderField: "X-Session-Token")
        }
        if let body {
            req.httpBody = try? JSONSerialization.data(withJSONObject: body)
        }

        let urlSession = URLSession(
            configuration: .default,
            delegate: SelfSignedCertDelegate(),
            delegateQueue: nil
        )

        do {
            let (data, response) = try await urlSession.data(for: req)
            guard let http = response as? HTTPURLResponse else { throw serverUnavailable() }

            if http.statusCode == 200 || http.statusCode == 201 { return data }

            if let detail = try? JSONDecoder().decode(FastAPIError.self, from: data) {
                if http.statusCode == 401 {
                    let msg = detail.detail.lowercased()
                    let isSessionError = msg.contains("session expired") ||
                                         msg.contains("session not found")
                    if isSessionError {
                        DispatchQueue.main.async {
                            NotificationCenter.default.post(name: .sessionExpired, object: nil)
                        }
                    } else {
                        DispatchQueue.main.async {
                            NotificationCenter.default.post(name: .sessionInvalidated, object: nil)
                        }
                    }
                }
                throw APIError(message: detail.detail)
            }
            throw APIError(message: "Server error (\(http.statusCode)).")

        } catch let e as APIError {
            throw e
        } catch {
            throw serverUnavailable()
        }
    }

    private func serverUnavailable() -> APIError {
        DispatchQueue.main.async {
            NotificationCenter.default.post(name: .serverUnavailable, object: nil)
        }
        return APIError(message: "Servers unavailable.")
    }

    private func deviceInfo() -> String {
        let device = UIDevice.current
        return "\(device.model) / iOS \(device.systemVersion)"
    }
}

extension Notification.Name {
    static let serverUnavailable = Notification.Name("serverUnavailable")
    static let sessionInvalidated = Notification.Name("sessionInvalidated")
    static let sessionExpired = Notification.Name("sessionExpired")
}

private struct FastAPIError: Codable { let detail: String }

class SelfSignedCertDelegate: NSObject, URLSessionDelegate {
    func urlSession(
        _ session: URLSession,
        didReceive challenge: URLAuthenticationChallenge,
        completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void
    ) {
        if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust,
           let trust = challenge.protectionSpace.serverTrust {
            completionHandler(.useCredential, URLCredential(trust: trust))
        } else {
            completionHandler(.performDefaultHandling, nil)
        }
    }
}
