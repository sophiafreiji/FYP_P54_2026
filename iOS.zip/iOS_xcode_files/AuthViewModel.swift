import Foundation
import FirebaseAuth
import GoogleSignIn
import FirebaseCore

enum KeySource: String {
    case secureEnclave = "se"
    case imported      = "imported"
}

@MainActor
class AuthViewModel: ObservableObject {
    @Published var currentUser:          FirebaseAuth.User?
    @Published var isConfirmedLoggedIn   = false
    @Published var isLoading             = true
    @Published var errorMessage:         String?
    @Published var successMessage:       String?
    @Published var sessionExpiredMessage: String?
    @Published var canSign               = true
    @Published var keySource: KeySource  = .secureEnclave
    @Published var importErrorMessage:   String?
    @Published var importSuccessMessage: String?

    private var authStateHandle: AuthStateDidChangeListenerHandle?

    init() {
        if UserDefaults.standard.string(forKey: "keySource") == "imported" {
            keySource = .imported
        }

        authStateHandle = Auth.auth().addStateDidChangeListener { [weak self] _, user in
            Task { @MainActor in
                self?.currentUser = user
                if user == nil { self?.isConfirmedLoggedIn = false }
                self?.isLoading = false
            }
        }
    }

    deinit {
        if let handle = authStateHandle {
            Auth.auth().removeStateDidChangeListener(handle)
        }
    }

    func signUp(email: String, password: String) async {
        clearMessages()
        if let pwError = validatePassword(password) {
            errorMessage = pwError
            return
        }
        do {
            let result = try await Auth.auth().createUser(withEmail: email, password: password)
            try await result.user.sendEmailVerification()
            try Auth.auth().signOut()
            successMessage = email
        } catch {
            try? await Auth.auth().currentUser?.delete()
            try? Auth.auth().signOut()
            errorMessage = errorString(error)
        }
    }

    private func validatePassword(_ password: String) -> String? {
        guard password.count >= 8 else {
            return "Password must be at least 8 characters."
        }
        guard password.contains(where: { $0.isUppercase }) else {
            return "Password must contain at least one uppercase letter."
        }
        guard password.contains(where: { $0.isLowercase }) else {
            return "Password must contain at least one lowercase letter."
        }
        guard password.contains(where: { $0.isNumber }) else {
            return "Password must contain at least one number."
        }
        let special = CharacterSet(charactersIn: "!@#$%^&*()_+-=[]{}|;':\",./<>?")
        guard password.unicodeScalars.contains(where: { special.contains($0) }) else {
            return "Password must contain at least one special character."
        }
        return nil
    }

    private var loginAttempts    = 0
    private var lockoutUntil:    Date? = nil
    private let maxAttempts      = 3
    private let cooldownSeconds: TimeInterval = 60

    func login(email: String, password: String) async -> [String]? {
        clearMessages()

        if let lockout = lockoutUntil, Date() < lockout {
            let remaining = Int(lockout.timeIntervalSince(Date())) + 1
            errorMessage = "Too many failed attempts. Please wait \(remaining) second\(remaining == 1 ? "" : "s")."
            return nil
        }

        do {
            let result = try await Auth.auth().signIn(withEmail: email, password: password)
            try await result.user.reload()
            guard let fresh = Auth.auth().currentUser, fresh.isEmailVerified else {
                try Auth.auth().signOut()
                errorMessage = "Please verify your email address before signing in."
                return nil
            }
            let token    = try await fresh.getIDToken()
            let response = try await APIService.shared.registerUser(token: token)
            APIService.shared.setSessionToken(response.sessionToken)
            currentUser = fresh
            loginAttempts = 0
            lockoutUntil  = nil
            if let profile = try? await APIService.shared.getProfile(token: token),
               profile.isBlacklisted {
                isConfirmedLoggedIn = true
                canSign = false
                return nil
            }
            if response.backupCodes.isEmpty {
                isConfirmedLoggedIn = true
                await verifyCertOwnership()
                return nil
            }
            return response.backupCodes
        } catch {
            loginAttempts += 1
            if loginAttempts >= maxAttempts {
                lockoutUntil  = Date().addingTimeInterval(cooldownSeconds)
                loginAttempts = 0
                errorMessage  = "Too many failed attempts. Please wait 60 seconds."
            } else {
                let remaining = maxAttempts - loginAttempts
                errorMessage  = "\(errorString(error)) \(remaining) attempt\(remaining == 1 ? "" : "s") remaining."
            }
            return nil
        }
    }

    func signInWithGoogle() async -> [String]? {
        clearMessages()
        guard let credential = await googleCredential() else { return nil }
        do {
            let result   = try await Auth.auth().signIn(with: credential)
            let token    = try await result.user.getIDToken()
            let response = try await APIService.shared.registerUser(token: token)
            APIService.shared.setSessionToken(response.sessionToken)
            currentUser = result.user
            if let profile = try? await APIService.shared.getProfile(token: token),
               profile.isBlacklisted {
                isConfirmedLoggedIn = true
                canSign = false
                return nil
            }
            if response.backupCodes.isEmpty {
                isConfirmedLoggedIn = true
                await verifyCertOwnership()
                return nil
            }
            return response.backupCodes
        } catch {
            errorMessage = errorString(error)
            return nil
        }
    }

    func requestCertificateIfNeeded() async {
        guard let user = currentUser else { return }
        let crypto = CryptoService.shared

        if crypto.loadPrivateKey() != nil {
            await verifyCertOwnership()
            return
        }

        do {
            let token    = try await user.getIDToken()
            let response = try await APIService.shared.getCertificate(token: token)
            if response.status == "success", response.serialNumber != nil {
                canSign = false
                print("[Crypto] Blocked cert generation, active cert exists on another device.")
                return
            }
        } catch {
            print("[Crypto] Active cert check failed (non-fatal): \(error). Proceeding with generation.")
        }

        do {
            let privateKey = try crypto.generateOrLoadKeyPair()

            let email  = user.email ?? ""
            let cn     = user.displayName ?? (user.email?.components(separatedBy: "@").first ?? "User")
            let csrPEM = try crypto.buildCSR(privateKey: privateKey, email: email, commonName: cn)

            let token   = try await user.getIDToken()
            let certPEM = try await APIService.shared.requestCertificate(csrPEM: csrPEM, token: token, force: true)

            try crypto.storeCertificate(certPEM)

            if let derData = crypto.pemToDER(certPEM),
               let cert = SecCertificateCreateWithData(nil, derData as CFData) {
                let subject = (SecCertificateCopySubjectSummary(cert) as String?) ?? email
                let issuer = "Fyp54-CA"
                let serial = crypto.storedCertSerialNumber() ?? "—"
                let notBefore = Date()
                let notAfter  = Date(timeIntervalSinceNow: 60 * 60 * 24 * 365)
                crypto.saveCertMetadata(subject: subject, issuer: issuer, serial: serial,
                                        notBefore: notBefore, notAfter: notAfter)
            }

            canSign = true
            print("[Crypto] Certificate issued and stored successfully.")

        } catch {
            print("[Crypto] Certificate request failed: \(error)")
            errorMessage = "Certificate setup failed. Please try again later."
        }
    }

    func ensureCertificateOnLaunch() async {
        guard let user = currentUser else { return }
        let crypto = CryptoService.shared

        if !canSign {
            if let token = try? await user.getIDToken(),
               let profile = try? await APIService.shared.getProfile(token: token),
               profile.isBlacklisted {
                return
            }
        }

        let hasSEKey       = crypto.loadPrivateKey() != nil && !crypto.isImported
        let hasImportedKey = crypto.hasImportedKey()
        let hasCert        = crypto.hasCertificate()

        if keySource == .imported {
            if hasImportedKey && hasCert {
                await verifyCertOwnership()
                return
            } else {
                print("[Crypto] Corrupt imported state on launch, cleaning and regenerating SE key.")
                crypto.deleteKeyPair()
                crypto.deleteCertificate()
                keySource = .secureEnclave
                await requestCertificateIfNeeded()
                await verifyCertOwnership()
                return
            }
        }

        if hasSEKey && hasCert {
            await verifyCertOwnership()
            if !canSign {
                if let deviceSerial = crypto.storedCertSerialNumber() {
                    do {
                        let token = try await user.getIDToken()
                        let isRevoked = try await APIService.shared.isCertificateRevoked(
                            serial: deviceSerial, token: token
                        )
                        if isRevoked {
                            print("[Crypto] Device cert is revoked, wiping for clean state.")
                            crypto.deleteCertificate()
                            crypto.deleteKeyPair()
                            await requestCertificateIfNeeded()
                            await verifyCertOwnership()
                        }
                    } catch {
                        print("[Crypto] isCertificateRevoked failed (non-fatal): \(error)")
                    }
                }
                return
            }
            let isValid = await validateCertificateWithBackend(user: user)
            if isValid {
                return
            } else {
                print("[Crypto] Certificate invalid on launch, deleting local key+cert and requesting new ones.")
                crypto.deleteCertificate()
                crypto.deleteKeyPair()
                await requestCertificateIfNeeded()
                await verifyCertOwnership()
            }
            return
        }

        if hasSEKey && !hasCert {
            print("[Crypto] Key exists but no cert, deleting key and requesting fresh pair.")
            crypto.deleteKeyPair()
            await requestCertificateIfNeeded()
            await verifyCertOwnership()
            return
        }

        await requestCertificateIfNeeded()
        await verifyCertOwnership()
    }

    private func validateCertificateWithBackend(user: FirebaseAuth.User) async -> Bool {
        do {
            let token = try await user.getIDToken()
            let result = try await APIService.shared.validateCertificate(token: token)
            return result
        } catch {
            print("[Crypto] validateCertificateWithBackend failed: \(error). Defaulting to valid.")
            return true
        }
    }

    func importPFX(data: Data, password: String) async {
        importErrorMessage  = nil
        importSuccessMessage = nil
        guard let user = currentUser else { return }
        let crypto = CryptoService.shared

        let importedCert: SecCertificate
        do {
            (_, importedCert) = try crypto.importPFX(data: data, password: password)
        } catch {
            importErrorMessage = "Something went wrong. Please try again."
            return
        }

        let certDER = SecCertificateCopyData(importedCert) as Data
        let certPEM = crypto.derToPEM(certDER)

        do {
            let token    = try await user.getIDToken()
            let response = try await APIService.shared.importCertificate(certPEM: certPEM, token: token)

            try? crypto.commitImport(importedCert: importedCert)

            keySource = .imported
            canSign   = true

            let subject = (SecCertificateCopySubjectSummary(importedCert) as String?) ?? "—"
            let serial  = crypto.storedCertSerialNumber() ?? "—"
            let isoParser = ISO8601DateFormatter()
            isoParser.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            let notAfter = isoParser.date(from: response.expiresAt)
                ?? ISO8601DateFormatter().date(from: response.expiresAt)
                ?? Date(timeIntervalSinceNow: 60 * 60 * 24 * 365)
            crypto.saveCertMetadata(
                subject:   subject,
                issuer:    "Actalis Client Authentication CA G3",
                serial:    serial,
                notBefore: Date(),
                notAfter:  notAfter
            )

            importSuccessMessage = "Certificate imported successfully."
            print("[Crypto] PFX imported. keySource = .imported, canSign = true.")

        } catch let e as APIError {
            await rollbackImport()
            importErrorMessage = e.message
        } catch {
            await rollbackImport()
            importErrorMessage = "Import failed. Please try again."
        }
    }

    private func rollbackImport() async {
        let crypto = CryptoService.shared
        crypto.deleteImportedKey()
        keySource = .secureEnclave
        await verifyCertOwnership()
    }

    func verifyCertOwnership() async {
        guard let user = currentUser else { return }
        let crypto = CryptoService.shared

        guard let deviceSerial = crypto.storedCertSerialNumber() else {
            do {
                let token    = try await user.getIDToken()
                let response = try await APIService.shared.getCertificate(token: token)
                if response.status == "success", response.serialNumber != nil {
                    canSign = false
                } else {
                    canSign = true
                }
            } catch {
                canSign = true
            }
            return
        }

        do {
            let token    = try await user.getIDToken()
            let response = try await APIService.shared.getCertificate(token: token)

            if response.status == "success", let backendSerial = response.serialNumber {
                canSign = deviceSerial.uppercased() == backendSerial.uppercased()
                if !canSign {
                    print("[Crypto] Cert mismatch, device serial: \(deviceSerial), backend serial: \(backendSerial). Signing disabled.")
                }
            } else {
                canSign = false
                print("[Crypto] Device has a cert but backend has none for this user, canSign = false.")
            }
        } catch {
            print("[Crypto] verifyCertOwnership failed: \(error). Defaulting canSign = true.")
            canSign = true
        }
    }

    func signOut() {
        if let user = currentUser {
            Task {
                if let token = try? await user.getIDToken() {
                    try? await APIService.shared.logout(token: token)
                }
            }
        }
        _clearLocalSession()
    }

    func resetSigningCertificate() async {
        guard let user = currentUser else { return }
        do {
            let token = try await user.getIDToken()
            try await APIService.shared.revokeMyCertificate(token: token)
        } catch {
            print("[Crypto] revokeMyCertificate backend call failed: \(error)")
        }
        CryptoService.shared.deleteCertificate()
        CryptoService.shared.deleteKeyPair()
        keySource = .secureEnclave
        canSign   = false
    }

    func reportCompromised() async -> Bool {
        guard let user = currentUser else { return false }
        do {
            let token = try await user.getIDToken()
            try await APIService.shared.reportCompromised(token: token)
            CryptoService.shared.deleteCertificate()
            CryptoService.shared.deleteKeyPair()
            keySource = .secureEnclave
            return true
        } catch {
            errorMessage = "Failed to report compromised device."
            return false
        }
    }

    func recoverAccount(email: String, password: String, backupKey: String) async {
        clearMessages()
        do {
            let result   = try await Auth.auth().signIn(withEmail: email, password: password)
            let token    = try await result.user.getIDToken()
            try Auth.auth().signOut()
            let response = try await APIService.shared.recoverAccount(token: token, backupKey: backupKey)
            successMessage = response.message ?? "Account recovered."
        } catch let e as APIError {
            errorMessage = e.message
        } catch {
            errorMessage = errorString(error)
        }
    }

    func recoverAccountGoogle(backupKey: String) async {
        clearMessages()
        guard let credential = await googleCredential() else { return }
        do {
            let result   = try await Auth.auth().signIn(with: credential)
            let token    = try await result.user.getIDToken()
            try Auth.auth().signOut()
            GIDSignIn.sharedInstance.signOut()
            let response = try await APIService.shared.recoverAccount(token: token, backupKey: backupKey)
            successMessage = response.message ?? "Account recovered."
        } catch let e as APIError {
            errorMessage = e.message
        } catch {
            errorMessage = errorString(error)
        }
    }

    func resetPassword(email: String, backupKey: String, newPassword: String) async {
        clearMessages()
        do {
            let msg = try await APIService.shared.resetPassword(
                email: email, backupKey: backupKey, newPassword: newPassword
            )
            successMessage = msg
        } catch {
            errorMessage = errorString(error)
        }
    }

    func forceLogout() {
        _clearLocalSession()
    }

    func sessionExpiredLogout() {
        sessionExpiredMessage = "Your session expired. Please log in again."
        _clearLocalSession()
    }

    func clearMessages() {
        errorMessage          = nil
        successMessage        = nil
        sessionExpiredMessage = nil
    }

    private func _clearLocalSession() {
        APIService.shared.setSessionToken(nil)
        try? Auth.auth().signOut()
        GIDSignIn.sharedInstance.signOut()
        currentUser          = nil
        isConfirmedLoggedIn  = false
        canSign              = true
    }

    private func googleCredential() async -> AuthCredential? {
        guard let clientID = FirebaseApp.app()?.options.clientID else {
            errorMessage = "Authentication service unavailable. Please try again."
            return nil
        }
        GIDSignIn.sharedInstance.configuration = GIDConfiguration(clientID: clientID)

        guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let root  = scene.windows.first?.rootViewController else {
            errorMessage = "Something went wrong. Please restart the app."
            return nil
        }

        do {
            let result = try await GIDSignIn.sharedInstance.signIn(withPresenting: root)
            guard let idToken = result.user.idToken?.tokenString else {
                errorMessage = "Google Sign-In failed. Please try again."
                return nil
            }
            return GoogleAuthProvider.credential(
                withIDToken: idToken,
                accessToken: result.user.accessToken.tokenString
            )
        } catch {
            errorMessage = errorString(error)
            return nil
        }
    }

    private func errorString(_ error: Error) -> String {
        if let api = error as? APIError { return api.message }
        let nsErr = error as NSError
        let code  = nsErr.code
        switch code {
        case AuthErrorCode.emailAlreadyInUse.rawValue:
            return "This email is already registered."
        case AuthErrorCode.accountExistsWithDifferentCredential.rawValue:
            return "Sign-in method not allowed for this account."
        case AuthErrorCode.invalidEmail.rawValue,
             AuthErrorCode.wrongPassword.rawValue,
             AuthErrorCode.userNotFound.rawValue,
             AuthErrorCode.invalidCredential.rawValue,
             17004, 17009, 17011, 17026:
            return "Invalid email or password."
        case AuthErrorCode.weakPassword.rawValue:
            return "Password does not meet requirements."
        case AuthErrorCode.networkError.rawValue:
            return "Unable to connect. Please check your connection."
        case AuthErrorCode.tooManyRequests.rawValue:
            return "Too many attempts. Please try again later."
        default:
            return "Something went wrong. Please try again."
        }
    }
}
